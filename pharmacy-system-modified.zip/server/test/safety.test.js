/**
 * اختبارات سلامة البيانات: ذرّية المعاملات (مكافئ انقطاع الكهرباء) ودورة النسخ الاحتياطي/الاستعادة.
 * Data-safety tests: transaction atomicity (power-cut equivalent) and backup/restore round-trip.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock } from './helpers/api.js';

let ctx;

before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'stock_movements', 'batches', 'products', 'customers']) {
    db.run(`DELETE FROM ${t}`);
  }
});

test('ذرّية: فشل بند داخل الفاتورة يُلغي الفاتورة كلها (لا كتابة جزئية)', async () => {
  const { db } = ctx;
  const a = makeProduct(db, { name: 'صنف-أ', purchase_price: 10, sale_price: 15 });
  const b = makeProduct(db, { name: 'صنف-ب', purchase_price: 10, sale_price: 15 });
  addStock(db, a, { qty: 100, cost: 10 });
  addStock(db, b, { qty: 1, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: {
      items: [
        { product_id: a, qty: 2, unit_price: 15 }, // صالح
        { product_id: b, qty: 5, unit_price: 15 }, // كمية غير كافية ⇒ يفشل
      ],
    },
  });
  assert.equal(res.status, 400);
  // لا فاتورة، ولا بنود، ولا حركات مخزون، ولا خصم من رصيد الصنف الأول
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 0);
  assert.equal(db.value('SELECT COUNT(*) FROM sale_items'), 0);
  assert.equal(db.value('SELECT COUNT(*) FROM stock_movements'), 0);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [a]), 100);
});

test('دورة كاملة: نسخة احتياطية ← مسح ← استعادة تُعيد البيانات', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'دواء-نسخة', purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 50, cost: 10 });
  const sale = await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: pid, qty: 3, unit_price: 15 }] } });
  assert.equal(sale.status, 201);

  // نسخة احتياطية كاملة (تتضمن كلمات المرور لتُستعاد الحسابات)
  const backup = await ctx.request('GET', '/api/settings/backup');
  assert.equal(backup.status, 200);
  assert.ok(backup.data && backup.data.tables && backup.data.tables.sales.length === 1);

  // مسح الحركات (مع تأكيد وكلمة مرور المدير)
  const wipe = await ctx.request('POST', '/api/settings/wipe', {
    body: { scope: 'transactions', confirm: 'مسح', password: 'admin123' },
  });
  assert.equal(wipe.status, 200);
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 0);

  // استعادة من النسخة
  const restore = await ctx.request('POST', '/api/settings/restore', {
    body: { data: backup.data, password: 'admin123' },
  });
  assert.equal(restore.status, 200);
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 1);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 47);
});

test('نسخة احتياطية ملف ذرّية (لا ملفات .tmp متبقية)', async () => {
  const res = await ctx.request('POST', '/api/settings/backups', { body: {} });
  assert.equal(res.status, 201);
  const list = await ctx.request('GET', '/api/settings/backups');
  const tmp = list.data.data.filter((f) => f.name.endsWith('.tmp'));
  assert.equal(tmp.length, 0, 'يجب ألا تبقى ملفات مؤقتة');
});

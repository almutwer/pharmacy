/**
 * اختبارات تحقّق الميزات: استيراد Excel/CSV بمطابقة الأسماء، الأدوار والصلاحيات،
 * المشتريات (تكلفة الدفعة)، التسويات المخزنية، والمصروفات.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock } from './helpers/api.js';

let ctx;

before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'purchase_items', 'purchases', 'stock_movements', 'batches', 'products', 'customers', 'suppliers',
    'expenses', 'activity_log']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("DELETE FROM users WHERE username != 'admin'");
});

const toB64 = (text) => Buffer.from(text, 'utf8').toString('base64');

/* ============================ استيراد Excel/CSV ============================ */

test('استيراد CSV ينشئ صنفاً جديداً مع رصيد افتتاحي', async () => {
  const { db } = ctx;
  const csv = [
    'اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,بيع بالتجزئة',
    'بنادول إكسترا,8,12,30,12,نعم',
  ].join('\n');

  const res = await ctx.request('POST', '/api/products/import-file', {
    body: { file: toB64(csv), filename: 'drugs.csv', mode: 'upsert' },
  });
  assert.equal(res.status, 200);
  assert.equal(res.data.created, 1);
  const prod = db.get("SELECT * FROM products WHERE name = 'بنادول إكسترا'");
  assert.ok(prod, 'يجب إنشاء الصنف');
  assert.equal(prod.sale_price, 12);
  assert.equal(prod.units_per_pack, 12);
  assert.equal(db.value('SELECT COALESCE(SUM(qty_available),0) FROM batches WHERE product_id = ?', [prod.id]), 30);
});

test('إعادة الاستيراد تطابق بالاسم فتحدّث ولا تُكرّر الصنف', async () => {
  const { db } = ctx;
  const first = 'اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي\nأموكسيل,5,9,20';
  await ctx.request('POST', '/api/products/import-file', { body: { file: toB64(first), filename: 'd.csv' } });

  const again = 'اسم الصنف,سعر الشراء,سعر البيع\nأموكسيل,5,11';
  const res = await ctx.request('POST', '/api/products/import-file', { body: { file: toB64(again), filename: 'd.csv' } });
  assert.equal(res.status, 200);
  assert.equal(res.data.updated, 1);
  assert.equal(res.data.created, 0);
  assert.equal(db.value("SELECT COUNT(*) FROM products WHERE name = 'أموكسيل'"), 1, 'لا تكرار');
  assert.equal(db.value("SELECT sale_price FROM products WHERE name = 'أموكسيل'"), 11, 'السعر محدَّث');
  // الرصيد الافتتاحي يُتجاهل عند التحديث (يبقى 20)
  assert.equal(db.value("SELECT COALESCE(SUM(qty_available),0) FROM batches b JOIN products p ON p.id=b.product_id WHERE p.name='أموكسيل'"), 20);
});

/* ============================ المشتريات ============================ */

test('المشتريات: التكلفة الفعلية للدفعة تشمل الكمية المجانية والخصم', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'صنف-شراء', purchase_price: 0, sale_price: 20 });
  const res = await ctx.request('POST', '/api/purchases', {
    body: {
      items: [{ product_id: pid, qty: 10, bonus_qty: 2, unit_cost: 10, sale_price: 20, discount: 20 }],
    },
  });
  assert.equal(res.status, 201);
  // الإجمالي = 10*10 - 20 = 80 ؛ الكمية الداخلة = 12 ؛ التكلفة الفعلية = 80/12 ≈ 6.6667
  const batch = db.get('SELECT * FROM batches WHERE product_id = ?', [pid]);
  assert.equal(batch.qty_available, 12);
  assert.ok(Math.abs(batch.cost_price - (80 / 12)) < 0.01, `cost ${batch.cost_price}`);
  assert.equal(db.value('SELECT total FROM purchases WHERE id = ?', [res.data.id]), 80);
});

/* ============================ المصروفات ============================ */

test('المصروفات: الإضافة والمجموع يعملان', async () => {
  const r1 = await ctx.request('POST', '/api/expenses', { body: { category: 'إيجار', amount: 500 } });
  const r2 = await ctx.request('POST', '/api/expenses', { body: { category: 'كهرباء', amount: 120 } });
  assert.equal(r1.status, 201);
  assert.equal(r2.status, 201);
  const list = await ctx.request('GET', '/api/expenses');
  assert.equal(list.data.sum, 620);
});

/* ============================ التسويات المخزنية ============================ */

test('تسوية إخراج تالف تخصم من المخزون وتُسجَّل كخسارة', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'صنف-تلف', purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 20, cost: 10 });
  const res = await ctx.request('POST', '/api/inventory/adjust', {
    body: { product_id: pid, type: 'damage', qty: 5 },
  });
  assert.equal(res.status, 200);
  assert.equal(db.value('SELECT COALESCE(SUM(qty_available),0) FROM batches WHERE product_id = ?', [pid]), 15);
  assert.equal(db.value("SELECT COUNT(*) FROM stock_movements WHERE type='damage' AND product_id = ?", [pid]), 1);
});

/* ============================ الأدوار والصلاحيات ============================ */

async function createUserAndLogin(role) {
  const username = `u_${role}`;
  await ctx.request('POST', '/api/users', {
    body: { username, full_name: role, password: 'pass1234', role },
  });
  const res = await ctx.request('POST', '/api/auth/login', { body: { username, password: 'pass1234' }, token: null });
  assert.equal(res.status, 200, `login ${role} failed`);
  return res.data.token;
}

test('الكاشير لا يملك صلاحية إدارة المستخدمين (403)', async () => {
  const token = await createUserAndLogin('cashier');
  const res = await ctx.request('GET', '/api/users', { token });
  assert.equal(res.status, 403);
});

test('الكاشير لا يملك صلاحية التقارير (403)', async () => {
  const token = await createUserAndLogin('cashier');
  const res = await ctx.request('GET', '/api/reports/profit', { token });
  assert.equal(res.status, 403);
});

test('الكاشير يرى مبالغ المبيعات لكن تُخفى عنه الأرباح', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'صنف-رؤية', purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 50, cost: 10 });
  const token = await createUserAndLogin('cashier');
  // الكاشير ينفّذ بيعاً (pos.use)
  const sale = await ctx.request('POST', '/api/sales', {
    token, body: { items: [{ product_id: pid, qty: 2, unit_price: 15 }] },
  });
  assert.equal(sale.status, 201);

  const list = await ctx.request('GET', '/api/sales', { token });
  const row = list.data.data[0];
  assert.notEqual(row.total, null, 'المبلغ ظاهر للكاشير');
  assert.equal(row.profit, null, 'الربح مخفي عن الكاشير');
});

test('المساعد تُخفى عنه المبالغ والأرباح معاً', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'صنف-مساعد', purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 50, cost: 10 });
  // بيع من المدير
  await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: pid, qty: 1, unit_price: 15 }] } });

  const token = await createUserAndLogin('assistant');
  const list = await ctx.request('GET', '/api/sales', { token });
  const row = list.data.data[0];
  assert.equal(row.total, null, 'المبلغ مخفي عن المساعد');
  assert.equal(row.profit, null, 'الربح مخفي عن المساعد');
});

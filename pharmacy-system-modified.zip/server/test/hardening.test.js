/**
 * اختبارات التحصين: حماية آخر مدير، حدود فاتورة الشراء، والضريبة الشاملة.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, round2 } from './helpers/api.js';

let ctx;

before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'purchase_items', 'purchases', 'stock_movements', 'batches', 'products', 'suppliers', 'activity_log']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("DELETE FROM users WHERE username != 'admin'");
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_included'");
});

/* ============================ حماية آخر مدير ============================ */

test('لا يمكن تنزيل رتبة آخر مدير نظام نشط', async () => {
  const me = ctx.db.get("SELECT id FROM users WHERE username = 'admin'");
  const res = await ctx.request('PUT', `/api/users/${me.id}`, { body: { role: 'cashier' } });
  assert.equal(res.status, 400);
  assert.equal(ctx.db.get('SELECT role FROM users WHERE id = ?', [me.id]).role, 'admin');
});

test('يمكن تنزيل رتبة مدير عند وجود مدير آخر', async () => {
  const { db } = ctx;
  await ctx.request('POST', '/api/users', { body: { username: 'admin2', full_name: 'مدير 2', password: 'pass1234', role: 'admin' } });
  const admin2 = db.get("SELECT id FROM users WHERE username = 'admin2'");
  const res = await ctx.request('PUT', `/api/users/${admin2.id}`, { body: { role: 'cashier' } });
  assert.equal(res.status, 200);
  assert.equal(db.get('SELECT role FROM users WHERE id = ?', [admin2.id]).role, 'cashier');
});

/* ============================ حدود فاتورة الشراء ============================ */

test('المشتريات: يُرفض خصم الفاتورة الأكبر من الإجمالي', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'ص-شراء', purchase_price: 0, sale_price: 10 });
  const res = await ctx.request('POST', '/api/purchases', {
    body: { items: [{ product_id: pid, qty: 5, unit_cost: 10 }], discount: 100 },
  });
  assert.equal(res.status, 400);
  assert.equal(db.value('SELECT COUNT(*) FROM purchases'), 0);
});

test('المشتريات: المدفوع لا يتجاوز الإجمالي', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { name: 'ص-دفع', purchase_price: 0, sale_price: 10 });
  const res = await ctx.request('POST', '/api/purchases', {
    body: { items: [{ product_id: pid, qty: 5, unit_cost: 10 }], paid: 999 },
  });
  assert.equal(res.status, 201);
  assert.equal(db.value('SELECT paid FROM purchases WHERE id = ?', [res.data.id]), 50);
});

/* ============================ الضريبة الشاملة ============================ */

test('ضريبة شاملة: السعر يشمل الضريبة فتُستخرج منه', async () => {
  const { db } = ctx;
  db.run("UPDATE settings SET value = '15' WHERE key = 'tax_rate'");
  db.run("UPDATE settings SET value = '1' WHERE key = 'tax_included'");
  const pid = makeProduct(db, { name: 'ص-ضريبة', purchase_price: 50, sale_price: 115 });
  addStock(db, pid, { qty: 10, cost: 50 });

  const res = await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: pid, qty: 1, unit_price: 115 }] } });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 115, 'الإجمالي يبقى 115 (الضريبة بداخله)');
  const saved = db.get('SELECT tax, profit FROM sales WHERE id = ?', [res.data.id]);
  assert.equal(round2(saved.tax), 15, 'حصة الضريبة = 115 − 115/1.15 = 15');
  assert.equal(round2(saved.profit), 50, 'الربح = 100 (بدون ضريبة) − تكلفة 50');
});

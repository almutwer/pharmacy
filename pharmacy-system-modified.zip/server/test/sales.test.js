/**
 * اختبارات منطق البيع: الحسابات، الخصومات، الضريبة، البيع بالتجزئة، FEFO، والتحقق من المدخلات.
 * Sales business-logic tests: totals, discounts, tax, retail units, FEFO, input validation.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, round2 } from './helpers/api.js';

let ctx;

before(async () => {
  ctx = await boot();
  await ctx.login();
});
after(async () => { await ctx.close(); });

/** تصفير الجداول الحركية قبل كل اختبار */
beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'purchase_items', 'purchases', 'stock_movements', 'batches', 'products', 'customers']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
  db.run("UPDATE settings SET value = '0' WHERE key = 'allow_negative_stock'");
});

test('بيع بالعبوة: الإجمالي والتكلفة والربح والمخزون', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10, sale: 15 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 3, unit_price: 15 }] },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.subtotal, 45);
  assert.equal(res.data.total, 45);
  assert.equal(res.data.cogs, 30);
  assert.equal(res.data.profit, 15);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 97);
});

test('خصم على البند يُطرح من الإجمالي والربح', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 2, unit_price: 15, discount: 5 }] },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 25); // 2*15 - 5
  assert.equal(res.data.cogs, 20);
  assert.equal(res.data.profit, 5);
});

test('خصم على الفاتورة يُطرح من الإجمالي', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 2, unit_price: 15 }], discount: 10 },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 20); // 30 - 10
  assert.equal(res.data.profit, 0); // 20 - cogs 20
});

test('الضريبة تُحسب من إعداد النظام لا من الواجهة', async () => {
  const { db } = ctx;
  db.run("UPDATE settings SET value = '10' WHERE key = 'tax_rate'");
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });

  // الواجهة أرسلت ضريبة خاطئة (999) — يجب أن يتجاهلها الخادم ويحسب 10% = 3
  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 2, unit_price: 15 }], tax: 999 },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 33); // 30 + 3
  assert.equal(res.data.profit, 10); // 30 - 20 (الربح لا يشمل الضريبة)
  const saved = db.get('SELECT tax FROM sales WHERE id = ?', [res.data.id]);
  assert.equal(saved.tax, 3);
});

test('بيع بالتجزئة (شريط/قرص) يخصم كسراً من العبوة', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, {
    purchase_price: 10, sale_price: 15, units_per_pack: 10, allow_sub_unit: 1, sub_unit: 'قرص',
  });
  addStock(db, pid, { qty: 10, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 3, unit_price: 2, unit_mode: 'sub' }] },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 6); // 3 أقراص * 2
  // خُصم 0.3 علبة من 10
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 9.7);
  assert.equal(res.data.cogs, 3); // 0.3 * 10
  assert.equal(res.data.profit, 3);
});

test('FEFO: يُصرف من الدفعة الأقرب انتهاءً أولاً', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  const later = addStock(db, pid, { qty: 5, cost: 10, expiry: '2030-01-01' });
  const sooner = addStock(db, pid, { qty: 5, cost: 10, expiry: '2026-01-01' });

  await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 3, unit_price: 15 }] },
  });
  assert.equal(db.value('SELECT qty_available FROM batches WHERE id = ?', [sooner]), 2);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE id = ?', [later]), 5);
});

test('نقص المخزون يرفض البيع (الوضع الافتراضي)', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 2, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 5, unit_price: 15 }] },
  });
  assert.equal(res.status, 400);
  // لا تُنشأ فاتورة، ولا يتغيّر المخزون (ذرّية المعاملة)
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 0);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 2);
});

/* ============ اختبارات أخطاء يجب أن يرفضها النظام (أموال سالبة) ============ */

test('يرفض خصم فاتورة أكبر من الإجمالي (لا إجمالي سالب)', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 2, unit_price: 15 }], discount: 100 },
  });
  assert.equal(res.status, 400, 'يجب رفض الخصم الذي يتجاوز الإجمالي');
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 0);
});

test('يرفض خصم بند أكبر من قيمة البند (لا بند سالب)', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 2, unit_price: 15, discount: 50 }] },
  });
  assert.equal(res.status, 400, 'يجب رفض خصم البند الذي يتجاوز قيمته');
  assert.equal(db.value('SELECT COUNT(*) FROM sales'), 0);
});

test('وضع السماح بالسالب: يُكمل البيع ويُصبح الرصيد سالباً', async () => {
  const { db } = ctx;
  db.run("UPDATE settings SET value = '1' WHERE key = 'allow_negative_stock'");
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 2, cost: 10 });

  const res = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: pid, qty: 5, unit_price: 15 }] },
  });
  assert.equal(res.status, 201, 'يسمح بالبيع رغم نقص المخزون');
  assert.equal(round2(db.value('SELECT COALESCE(SUM(qty_available),0) FROM batches WHERE product_id = ?', [pid])), -3);
});

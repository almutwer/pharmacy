/**
 * اختبارات انحدار لأخطاء اكتشفها فحص المتصفح:
 * تطابق التقارير مع سجل المبيعات، تعديل مستخدم بلا كلمة مرور، شراء نقدي مدفوع بالكامل،
 * وربح صافٍ في سجل المبيعات.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, localToday } from './helpers/api.js';

let ctx;
const DAY = localToday();

before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'purchase_items', 'purchases', 'stock_movements', 'batches', 'products', 'customers', 'activity_log']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("DELETE FROM users WHERE username != 'admin'");
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
});

test('التقارير تتطابق مع سجل المبيعات: الملغاة مستبعدة ومرتجعها لا يُحتسب', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { purchase_price: 10, sale_price: 20 });
  addStock(db, p, { qty: 100, cost: 10 });
  const A = (await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: p, qty: 2, unit_price: 20 }] } })).data; // 40
  const B = (await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: p, qty: 3, unit_price: 20 }] } })).data; // 60
  await ctx.request('POST', `/api/sales/${B.id}/cancel`, { body: {} }); // الغاء B
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [A.id]);
  await ctx.request('POST', `/api/sales/${A.id}/return`, { body: { items: [{ sale_item_id: si.id, qty: 1 }] } }); // ارجاع 1 من A

  const pnl = (await ctx.request('GET', `/api/reports/profit?from=${DAY}&to=${DAY}`)).data;
  const dash = (await ctx.request('GET', '/api/reports/dashboard')).data;
  const list = (await ctx.request('GET', '/api/sales')).data;

  assert.equal(pnl.summary.gross_sales, 40, 'الإجمالي = الفواتير المكتملة فقط');
  assert.equal(pnl.summary.returns, 20, 'المرتجعات = المرتجع الجزئي فقط (لا إلغاء B)');
  assert.equal(pnl.summary.net_sales, 20);
  assert.equal(pnl.summary.invoices, 1, 'فاتورة مكتملة واحدة');
  assert.equal(dash.month.invoices, 1, 'اللوحة تطابق التقرير في العدد');
  assert.equal(dash.month.sales, pnl.summary.net_sales, 'اللوحة = صافي التقرير');
  assert.equal(list.summary.total_amount, 40, 'سجل المبيعات = الإجمالي المكتمل');
  assert.equal(list.summary.total_profit, 10, 'ربح صافٍ بعد المرتجع');
});

test('سجل المبيعات: ربح الفاتورة صافٍ، والملغاة بصفر', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { purchase_price: 10, sale_price: 20 });
  addStock(db, p, { qty: 100, cost: 10 });
  const A = (await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: p, qty: 2, unit_price: 20 }] } })).data;
  const B = (await ctx.request('POST', '/api/sales', { body: { items: [{ product_id: p, qty: 3, unit_price: 20 }] } })).data;
  await ctx.request('POST', `/api/sales/${B.id}/cancel`, { body: {} });
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [A.id]);
  await ctx.request('POST', `/api/sales/${A.id}/return`, { body: { items: [{ sale_item_id: si.id, qty: 1 }] } });

  const list = (await ctx.request('GET', '/api/sales')).data;
  const rowA = list.data.find((s) => s.id === A.id);
  const rowB = list.data.find((s) => s.id === B.id);
  assert.equal(rowA.profit, 10, 'A: ربح 20 ناقص ربح المرتجع 10');
  assert.equal(rowB.profit, 0, 'B الملغاة: ربح صفر');
});

test('شراء نقدي يُسجَّل مدفوعاً بالكامل (لا يظهر ديناً)', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { purchase_price: 0, sale_price: 10 });
  const res = await ctx.request('POST', '/api/purchases', {
    body: { items: [{ product_id: p, qty: 5, unit_cost: 10 }], payment_method: 'cash' },
  });
  assert.equal(res.status, 201);
  const row = db.get('SELECT total, paid FROM purchases WHERE id = ?', [res.data.id]);
  assert.equal(row.paid, row.total, 'النقدي مدفوع بالكامل');
  assert.equal(row.paid, 50);
});

test('شراء آجل يبقى غير مدفوع افتراضياً', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { purchase_price: 0, sale_price: 10 });
  const res = await ctx.request('POST', '/api/purchases', {
    body: { items: [{ product_id: p, qty: 5, unit_cost: 10 }], payment_method: 'credit' },
  });
  assert.equal(db.value('SELECT paid FROM purchases WHERE id = ?', [res.data.id]), 0);
});

test('تعديل مستخدم بدون كلمة مرور ينجح (لا يغيّرها)', async () => {
  const { db } = ctx;
  await ctx.request('POST', '/api/users', { body: { username: 'moe', full_name: 'محمد', password: 'pass1234', role: 'cashier' } });
  const id = db.value("SELECT id FROM users WHERE username = 'moe'");

  // تعديل الاسم فقط، كلمة المرور فارغة
  const r = await ctx.request('PUT', `/api/users/${id}`, { body: { full_name: 'محمد علي', password: '' } });
  assert.equal(r.status, 200, 'يجب أن ينجح التعديل بكلمة مرور فارغة');
  // لا تزال كلمة المرور القديمة صالحة
  const login = await ctx.request('POST', '/api/auth/login', { body: { username: 'moe', password: 'pass1234' }, token: null });
  assert.equal(login.status, 200);
});

test('تغيير كلمة المرور قصيرة مرفوض، والصحيحة تعمل', async () => {
  const { db } = ctx;
  await ctx.request('POST', '/api/users', { body: { username: 'sara', full_name: 'سارة', password: 'pass1234', role: 'cashier' } });
  const id = db.value("SELECT id FROM users WHERE username = 'sara'");

  const short = await ctx.request('PUT', `/api/users/${id}`, { body: { password: 'ab' } });
  assert.equal(short.status, 422, 'كلمة مرور قصيرة مرفوضة');

  const ok = await ctx.request('PUT', `/api/users/${id}`, { body: { password: 'newpass9' } });
  assert.equal(ok.status, 200);
  const login = await ctx.request('POST', '/api/auth/login', { body: { username: 'sara', password: 'newpass9' }, token: null });
  assert.equal(login.status, 200);
});

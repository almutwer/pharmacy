/**
 * أداة اختبار: تشغيل الخادم الحقيقي على منفذ حر مع قاعدة بيانات معزولة مؤقتة.
 * توفّر طلبات HTTP حقيقية (اختبارات تكامل) ووصولاً مباشراً لقاعدة البيانات (للتهيئة والتحقق).
 *
 * Test harness: boots the real Express app on an ephemeral port with an isolated
 * temp SQLite database. Exposes real HTTP requests (integration) plus direct DB access.
 */
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

let counter = 0;

/**
 * Boot an isolated server instance. MUST be called before importing db.js anywhere,
 * so it sets env first and then dynamically imports the app and db singleton.
 */
export async function boot({ seedCatalog = false } = {}) {
  const dir = mkdtempSync(join(tmpdir(), `pharm-test-${process.pid}-${counter += 1}-`));
  process.env.DATA_DIR = dir;
  process.env.DB_FILE = join(dir, 'test.db');
  process.env.PORT = '0';
  process.env.HOST = '127.0.0.1';
  process.env.JWT_SECRET = 'test-secret-key';
  process.env.JWT_EXPIRES = '12h';
  process.env.NODE_ENV = 'test';
  // الدليل المرجعي بطيء وغير ضروري لأغلب الاختبارات
  process.env.SEED_CATALOG = seedCatalog ? '1' : '0';

  const appMod = await import('../../src/index.js');
  const { server } = appMod;
  await new Promise((resolve) => {
    if (server.listening) return resolve();
    return server.once('listening', resolve);
  });
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}`;

  const { default: db } = await import('../../src/lib/db.js');

  const ctx = {
    base,
    server,
    db,
    dir,
    token: null,
    async request(method, path, { body, token = ctx.token, raw = false } = {}) {
      const headers = {};
      if (body !== undefined) headers['Content-Type'] = 'application/json';
      if (token) headers.Authorization = `Bearer ${token}`;
      const res = await fetch(`${base}${path}`, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      if (raw) return res;
      let data = null;
      const text = await res.text();
      try { data = text ? JSON.parse(text) : null; } catch { data = text; }
      return { status: res.status, data };
    },
    async login(username = 'admin', password = 'admin123') {
      const res = await ctx.request('POST', '/api/auth/login', { body: { username, password }, token: null });
      if (res.status !== 200) throw new Error(`login failed (${res.status}): ${JSON.stringify(res.data)}`);
      ctx.token = res.data.token;
      return res.data;
    },
    async close() {
      await new Promise((resolve) => server.close(resolve));
      try { db.raw.close?.(); } catch { /* ignore */ }
      try { rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
    },
  };

  return ctx;
}

/** إعداد صنف واحد مع رصيد افتتاحي مباشرة في قاعدة البيانات (تهيئة سريعة) */
export function makeProduct(db, overrides = {}) {
  const p = {
    name: `منتج-${Math.round(db.value("SELECT COALESCE(MAX(id),0)+1 FROM products"))}`,
    unit: 'علبة',
    purchase_price: 10,
    sale_price: 15,
    units_per_pack: 1,
    allow_sub_unit: 0,
    sub_unit: null,
    sub_unit_price: 0,
    reorder_level: 10,
    active: 1,
    ...overrides,
  };
  const { lastInsertRowid: id } = db.insert('products', p);
  return id;
}

/** إضافة دفعة مخزون لصنف */
export function addStock(db, productId, { qty = 100, cost = 10, sale = 15, expiry = null, batchNo = null } = {}) {
  const { lastInsertRowid: id } = db.insert('batches', {
    product_id: productId,
    batch_no: batchNo,
    expiry_date: expiry,
    qty_in: qty,
    qty_available: qty,
    cost_price: cost,
    sale_price: sale,
  });
  return id;
}

export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

/** تاريخ اليوم المحلي — يطابق helpers.today() في الخادم */
export const localToday = () => {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

/**
 * اختبارات تصافي التقارير: لوحة المعلومات وتقرير الأرباح يجب أن يتطابقا مع
 * (إجمالي الفواتير − إجمالي المرتجعات)، والفاتورة الملغاة تساوي صفراً، والمرتجع الجزئي يخفّض الصافي.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, round2, localToday } from './helpers/api.js';

let ctx;
const DAY = localToday();

before(async () => {
  ctx = await boot();
  await ctx.login();
});
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'stock_movements', 'batches', 'products', 'customers', 'expenses']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
});

async function sell(body) {
  const res = await ctx.request('POST', '/api/sales', { body });
  assert.equal(res.status, 201, `sale failed: ${JSON.stringify(res.data)}`);
  return res.data;
}
const profit = () => ctx.request('GET', `/api/reports/profit?from=${DAY}&to=${DAY}`);
const dashboard = () => ctx.request('GET', '/api/reports/dashboard');

/** مجموع من قاعدة البيانات لإثبات التصافي */
function rawNetSales(db) {
  const s = db.value('SELECT COALESCE(SUM(total),0) FROM sales');
  const r = db.value('SELECT COALESCE(SUM(total),0) FROM sale_returns');
  return round2(s - r);
}

test('الأرباح: البيع البسيط يعطي صافي مبيعات وربح صحيحين', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });
  await sell({ items: [{ product_id: pid, qty: 4, unit_price: 15 }] });

  const r = await profit();
  assert.equal(r.status, 200);
  assert.equal(r.data.summary.net_sales, 60);
  assert.equal(r.data.summary.gross_profit, 20);
  assert.equal(r.data.summary.net_sales, rawNetSales(db));
});

test('الأرباح: الفاتورة الملغاة لا تساهم بشيء (صفر)', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50 });
  addStock(db, pid, { qty: 100, cost: 30 });
  const sale = await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }], discount: 20 });
  await ctx.request('POST', `/api/sales/${sale.id}/cancel`, { body: {} });

  const r = await profit();
  assert.equal(r.data.summary.net_sales, 0);
  assert.equal(r.data.summary.gross_profit, 0);
  assert.equal(r.data.summary.net_sales, rawNetSales(db));
});

test('الأرباح: المرتجع الجزئي يخفّض الصافي والربح', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50 });
  addStock(db, pid, { qty: 100, cost: 30 });
  const sale = await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }] });
  const saleItem = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);
  await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: saleItem.id, qty: 1 }] },
  });

  const r = await profit();
  assert.equal(r.data.summary.net_sales, 50); // 100 - 50
  assert.equal(r.data.summary.gross_profit, 20); // باع وحدة بـ50 تكلفتها 30
  assert.equal(r.data.summary.net_sales, rawNetSales(db));
});

test('الأرباح حسب التصنيف تحترم خصم الفاتورة', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50, category: 'مسكنات' });
  addStock(db, pid, { qty: 100, cost: 30 });
  await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }], discount: 20 });

  const r = await profit();
  const row = r.data.by_category.find((c) => c.category === 'مسكنات');
  assert.ok(row, 'يجب وجود تصنيف مسكنات');
  assert.equal(round2(row.revenue), 80, 'الإيراد بعد خصم الفاتورة = 80');
  assert.equal(round2(row.profit), 20, 'الربح = 80 - تكلفة 60');
});

test('الأرباح مع ضريبة: المرتجع يصافي حصة الضريبة (ربح صحيح)', async () => {
  const { db } = ctx;
  db.run("UPDATE settings SET value = '10' WHERE key = 'tax_rate'");
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50 });
  addStock(db, pid, { qty: 100, cost: 30 });
  const sale = await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }] }); // subtotal100 tax10 total110
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);
  await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: si.id, qty: 1 }] },
  }); // refund 55 (incl tax 5), cost 30

  const r = await profit();
  assert.equal(round2(r.data.summary.net_sales), 55); // 110 - 55 (شامل الضريبة)
  assert.equal(round2(r.data.summary.gross_profit), 20); // وحدة متبقية: 50 بدون ضريبة − تكلفة 30
  assert.equal(r.data.summary.net_sales, rawNetSales(db));
});

test('لوحة المعلومات تطابق تقرير الأرباح في صافي المبيعات', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });
  await sell({ items: [{ product_id: pid, qty: 5, unit_price: 15 }] });
  const sale2 = await sell({ items: [{ product_id: pid, qty: 3, unit_price: 15 }] });
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale2.id]);
  await ctx.request('POST', `/api/sales/${sale2.id}/return`, {
    body: { items: [{ sale_item_id: si.id, qty: 1 }] },
  });

  const d = await dashboard();
  const p = await profit();
  assert.equal(d.data.month.sales, p.data.summary.net_sales);
  assert.equal(d.data.month.sales, rawNetSales(db));
});

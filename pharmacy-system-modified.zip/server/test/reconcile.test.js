/**
 * فحص تدقيقي صارم: تطابق الأرقام بين التقارير وبعضها، ومع مجاميع قاعدة البيانات،
 * وحالات حدّية: دفعات متعددة، بيع بالتجزئة ومرتجعه، بند مجاني، واتجاه اللوحة.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, round2, localToday } from './helpers/api.js';

let ctx;
const DAY = localToday();

before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'stock_movements', 'batches', 'products', 'customers', 'expenses']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_included'");
});

const sell = async (body) => {
  const r = await ctx.request('POST', '/api/sales', { body });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data;
};
const profit = () => ctx.request('GET', `/api/reports/profit?from=${DAY}&to=${DAY}`);

test('تدقيق: مجموع أرباح التصنيفات = إجمالي الربح في الملخّص', async () => {
  const { db } = ctx;
  const a = makeProduct(db, { name: 'أ', category: 'مسكنات', purchase_price: 10, sale_price: 20 });
  const b = makeProduct(db, { name: 'ب', category: 'مضادات', purchase_price: 30, sale_price: 50 });
  addStock(db, a, { qty: 100, cost: 10 });
  addStock(db, b, { qty: 100, cost: 30 });

  await sell({ items: [{ product_id: a, qty: 3, unit_price: 20 }, { product_id: b, qty: 2, unit_price: 50 }], discount: 10 });
  const s2 = await sell({ items: [{ product_id: b, qty: 4, unit_price: 50 }] });
  // إرجاع وحدة من الفاتورة الثانية
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ? AND product_id = ?', [s2.id, b]);
  await ctx.request('POST', `/api/sales/${s2.id}/return`, { body: { items: [{ sale_item_id: si.id, qty: 1 }] } });

  const r = await profit();
  const catProfitSum = round2(r.data.by_category.reduce((s, c) => s + c.profit, 0));
  const catRevenueSum = round2(r.data.by_category.reduce((s, c) => s + c.revenue, 0));
  assert.equal(catProfitSum, r.data.summary.gross_profit, 'مجموع أرباح التصنيفات يجب أن يساوي إجمالي الربح');
  // الإيراد بدون ضريبة = صافي المبيعات (الضريبة صفر هنا)
  assert.equal(catRevenueSum, r.data.summary.net_sales);
});

test('تدقيق: مجموع بنود الفاتورة = إجمالي الأصناف المخزَّن', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { name: 'ج', purchase_price: 10, sale_price: 15 });
  addStock(db, p, { qty: 100, cost: 10 });
  const sale = await sell({ items: [{ product_id: p, qty: 7, unit_price: 15, discount: 4 }] });
  const sumItems = round2(db.value('SELECT COALESCE(SUM(total),0) FROM sale_items WHERE sale_id = ?', [sale.id]));
  assert.equal(sumItems, sale.subtotal);
});

test('حدّي: دفعات متعددة بتكاليف مختلفة — التكلفة والربح صحيحان (FEFO)', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { name: 'د', purchase_price: 10, sale_price: 20 });
  addStock(db, p, { qty: 2, cost: 10, expiry: '2026-01-01' }); // الأقرب انتهاءً
  addStock(db, p, { qty: 10, cost: 12, expiry: '2030-01-01' });

  const sale = await sell({ items: [{ product_id: p, qty: 5, unit_price: 20 }] });
  assert.equal(sale.subtotal, 100);
  assert.equal(sale.cogs, 2 * 10 + 3 * 12); // 56
  assert.equal(sale.profit, 44);
  // بندان (واحد لكل دفعة) ومجموعهما = 100
  assert.equal(db.value('SELECT COUNT(*) FROM sale_items WHERE sale_id = ?', [sale.id]), 2);
  assert.equal(round2(db.value('SELECT SUM(total) FROM sale_items WHERE sale_id = ?', [sale.id])), 100);
});

test('حدّي: مرتجع بيع بالتجزئة يسترد نسبياً ويعيد الكمية الصحيحة', async () => {
  const { db } = ctx;
  const p = makeProduct(db, {
    name: 'هـ', purchase_price: 10, sale_price: 20, units_per_pack: 10, allow_sub_unit: 1, sub_unit: 'قرص',
  });
  addStock(db, p, { qty: 10, cost: 10 });
  const sale = await sell({ items: [{ product_id: p, qty: 5, unit_price: 2, unit_mode: 'sub' }] }); // 5 أقراص = 10
  assert.equal(sale.total, 10);
  const si = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);

  const ret = await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: si.id, qty_units: 2 }] }, // إرجاع قرصين
  });
  assert.equal(ret.status, 201);
  assert.equal(round2(ret.data.total), 4, 'قرصان = 2×2'); // نسبي من 10
  // المخزون: خُصم 0.5 علبة ثم أُعيد 0.2 ⇒ 9.7
  assert.equal(round2(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [p])), 9.7);
});

test('حدّي: بند مجاني (خصم = قيمته) مسموح بإجمالي صفر', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { name: 'و', purchase_price: 10, sale_price: 15 });
  addStock(db, p, { qty: 100, cost: 10 });
  const r = await ctx.request('POST', '/api/sales', {
    body: { items: [{ product_id: p, qty: 2, unit_price: 15, discount: 30 }] },
  });
  assert.equal(r.status, 201);
  assert.equal(r.data.total, 0);
  assert.equal(r.data.profit, -20); // بضاعة بتكلفة 20 أُعطيت مجاناً (خسارة مقصودة مسموحة)
});

test('تدقيق: اتجاه اللوحة يطابق صافي اليوم (الفاتورة الملغاة = صفر)', async () => {
  const { db } = ctx;
  const p = makeProduct(db, { name: 'ز', purchase_price: 10, sale_price: 15 });
  addStock(db, p, { qty: 100, cost: 10 });
  await sell({ items: [{ product_id: p, qty: 4, unit_price: 15 }] });
  const s2 = await sell({ items: [{ product_id: p, qty: 2, unit_price: 15 }] });
  await ctx.request('POST', `/api/sales/${s2.id}/cancel`, { body: {} });

  const d = await ctx.request('GET', '/api/reports/dashboard');
  const todayRow = d.data.sales_trend.find((x) => x.date === DAY);
  assert.ok(todayRow, 'يجب وجود صف اليوم في الاتجاه');
  assert.equal(round2(todayRow.sales), d.data.today.sales, 'اتجاه اليوم = مؤشر اليوم');
  assert.equal(round2(todayRow.sales), 60, 'الملغاة لا تُحتسب: 60 فقط');
});

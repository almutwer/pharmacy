/**
 * اختبارات المرتجعات والإلغاء: استرجاع المخزون، صحة مبلغ الاسترداد مع خصم الفاتورة والضريبة.
 * Returns & cancellation tests: stock restoration, refund correctness with invoice discount & tax.
 */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { boot, makeProduct, addStock, round2 } from './helpers/api.js';

let ctx;

before(async () => {
  ctx = await boot();
  await ctx.login();
});
after(async () => { await ctx.close(); });

beforeEach(() => {
  const { db } = ctx;
  for (const t of ['sale_return_items', 'sale_returns', 'sale_items', 'sales',
    'stock_movements', 'batches', 'products', 'customers']) {
    db.run(`DELETE FROM ${t}`);
  }
  db.run("UPDATE settings SET value = '0' WHERE key = 'tax_rate'");
});

async function sell(body) {
  const res = await ctx.request('POST', '/api/sales', { body });
  assert.equal(res.status, 201, `sale failed: ${JSON.stringify(res.data)}`);
  return res.data;
}

test('مرتجع جزئي: يعيد المخزون ويسجل الكمية المرتجعة', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });
  const sale = await sell({ items: [{ product_id: pid, qty: 5, unit_price: 15 }] });
  const saleItem = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);

  const res = await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: saleItem.id, qty: 2 }] },
  });
  assert.equal(res.status, 201);
  assert.equal(res.data.total, 30); // 2 * 15
  assert.equal(res.data.cost_total, 20);
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 97); // 95 + 2
  assert.equal(db.value('SELECT returned_qty FROM sale_items WHERE id = ?', [saleItem.id]), 2);
});

test('المرتجع الكلي يحوّل حالة الفاتورة إلى ملغاة', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });
  const sale = await sell({ items: [{ product_id: pid, qty: 4, unit_price: 15 }] });
  const saleItem = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);

  const res = await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: saleItem.id, qty: 4 }] },
  });
  assert.equal(res.status, 201);
  assert.equal(db.get('SELECT status FROM sales WHERE id = ?', [sale.id]).status, 'cancelled');
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 100);
});

test('لا يسمح بإرجاع أكثر من المتبقي', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 10, sale_price: 15 });
  addStock(db, pid, { qty: 100, cost: 10 });
  const sale = await sell({ items: [{ product_id: pid, qty: 3, unit_price: 15 }] });
  const saleItem = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);

  const res = await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: saleItem.id, qty: 5 }] },
  });
  assert.equal(res.status, 400);
});

test('المرتجع مع خصم فاتورة يسترد ما دفعه العميل فعلاً (نسبي)', async () => {
  // باع صنفين بسعر 50 لكل منهما = 100، وخصم على الفاتورة 20 ⇒ دفع العميل 80 (40 للوحدة)
  // عند إرجاع وحدة واحدة يجب رد 40 لا 50.
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50 });
  addStock(db, pid, { qty: 100, cost: 30 });
  const sale = await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }], discount: 20 });
  assert.equal(sale.total, 80);
  const saleItem = db.get('SELECT id FROM sale_items WHERE sale_id = ?', [sale.id]);

  const res = await ctx.request('POST', `/api/sales/${sale.id}/return`, {
    body: { items: [{ sale_item_id: saleItem.id, qty: 1 }] },
  });
  assert.equal(res.status, 201);
  assert.equal(round2(res.data.total), 40, 'الاسترداد يجب أن يكون نصف ما دُفع فعلاً (80/2)');
});

test('إلغاء الفاتورة يعيد كل المخزون ويطابق صافي المبيعات صفراً', async () => {
  const { db } = ctx;
  const pid = makeProduct(db, { purchase_price: 30, sale_price: 50 });
  addStock(db, pid, { qty: 100, cost: 30 });
  const sale = await sell({ items: [{ product_id: pid, qty: 2, unit_price: 50 }], discount: 20 });

  const res = await ctx.request('POST', `/api/sales/${sale.id}/cancel`, { body: { reason: 'اختبار' } });
  assert.equal(res.status, 200);
  assert.equal(db.get('SELECT status FROM sales WHERE id = ?', [sale.id]).status, 'cancelled');
  assert.equal(db.value('SELECT qty_available FROM batches WHERE product_id = ?', [pid]), 100);

  // مبلغ الإلغاء يجب أن يساوي ما دفعه العميل (total الفاتورة) حتى يتصافى التقرير
  const ret = db.get('SELECT total FROM sale_returns WHERE sale_id = ?', [sale.id]);
  assert.equal(round2(ret.total), 80, 'إجمالي الإلغاء يجب أن يساوي إجمالي الفاتورة المدفوع');
});

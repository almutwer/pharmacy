/**
 * اختبارات إصلاحين لاحقين (ملف إضافي — لا يعدّل اختبارات المراجعة الأصلية):
 * 1) تفعيل البيع بالتجزئة تلقائياً عند وجود وحدة بيع صغرى في ملف الاستيراد.
 * 2) ثبات ترخيص الجهاز: المفتاح المحسوب لأي بصمة مرشحة لنفس الجهاز يبقى صالحاً.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { boot } from './helpers/api.js';

let ctx;
before(async () => { ctx = await boot(); await ctx.login(); });
after(async () => { await ctx.close(); });

const toB64 = (text) => Buffer.from(text, 'utf8').toString('base64');
async function importCsv(csv) {
  const res = await ctx.request('POST', '/api/products/import-file', {
    body: { file: toB64(csv), filename: 'd.csv', mode: 'upsert' },
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  return res.data;
}

test('استيراد: وجود «الوحدة الصغرى» يفعّل البيع بالتجزئة تلقائياً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,الوحدة الصغرى\nدواء تجزئة أ,8,12,20,10,شريط');
  const p = db.get("SELECT allow_sub_unit, sub_unit FROM products WHERE name = 'دواء تجزئة أ'");
  assert.equal(p.sub_unit, 'شريط');
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: وجود «سعر الوحدة الصغرى» وحده يفعّل البيع بالتجزئة أيضاً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,سعر الوحدة الصغرى\nدواء تجزئة ب,8,12,20,10,1.5');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء تجزئة ب'");
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: غياب الوحدة الصغرى يُبقي البيع بالتجزئة كما هو (غير مفعّل)', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي\nدواء عادي,8,12,20');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء عادي'");
  assert.equal(p.allow_sub_unit, 0);
});

test('الترخيص: مفتاح أي بصمة مرشحة لنفس الجهاز صالح (ثبات عند تبدّل كرت الشبكة)', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const lic = await import('../src/lib/license.js');
  const ids = lic.candidateDeviceIds();
  assert.ok(ids.length >= 1);
  assert.equal(lic.getDeviceId(), ids[0]);
  // مفتاح غريب مرفوض عند التفعيل
  assert.equal(lic.activate(lic.expectedKey('ZZZZ-ZZZZ-ZZZZ')), false);
  // تفعيل طبيعي بالمفتاح المعروض ينجح
  assert.equal(lic.activate(lic.expectedKey(ids[0])), true);
  assert.equal(lic.isLicensed(), true);
  // محاكاة تبدّل كرت الشبكة: ملف ترخيص قديم بمفتاح بصمة مرشحة أخرى لنفس الجهاز يبقى صالحاً
  fs.writeFileSync(
    path.join(ctx.dir, 'license.json'),
    JSON.stringify({ key: lic.expectedKey(ids[ids.length - 1]), device_id: ids[ids.length - 1] }),
  );
  assert.equal(lic.isLicensed(), true);
});

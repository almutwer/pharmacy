/**
 * اختبارات إصلاحين لاحقين (ملف إضافي — لا يعدّل اختبارات المراجعة الأصلية):
 * 1) تفعيل البيع بالتجزئة تلقائياً عند وجود وحدة بيع صغرى في ملف الاستيراد.
 * 2) ثبات ترخيص الجهاز: معرّف الجهاز يُجمَّد مرة واحدة فلا يتغيّر أبداً،
 *    والتفعيل يبقى صالحاً رغم تبدّل كرت الشبكة أو فقدان مجلد البيانات.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { boot } from './helpers/api.js';

// مجلد مستخدم وهمي + تمكين النسخ الاحتياطية للترخيص داخل هذه الاختبارات فقط،
// حتى لا تتأثر أي اختبارات أخرى (ولا تُكتب أي ملفات في مجلد المستخدم الحقيقي).
const FAKE_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'shifaa-test-home-'));
process.env.HOME = FAKE_HOME;
process.env.SHIFAA_LICENSE_STORES = 'all';

let ctx;
let LIC;
before(async () => {
  ctx = await boot();         // يضبط DATA_DIR المؤقت قبل تحميل وحدة الترخيص
  await ctx.login();
  LIC = await import('../src/lib/license.js');
});
after(async () => {
  await ctx.close();
  try { fs.rmSync(FAKE_HOME, { recursive: true, force: true }); } catch { /* ignore */ }
});

const toB64 = (text) => Buffer.from(text, 'utf8').toString('base64');
async function importCsv(csv) {
  const res = await ctx.request('POST', '/api/products/import-file', {
    body: { file: toB64(csv), filename: 'd.csv', mode: 'upsert' },
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  return res.data;
}

test('استيراد: وجود «الوحدة الصغرى» يفعّل البيع بالتجزئة تلقائياً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,الوحدة الصغرى\nدواء تجزئة أ,8,12,20,10,شريط');
  const p = db.get("SELECT allow_sub_unit, sub_unit FROM products WHERE name = 'دواء تجزئة أ'");
  assert.equal(p.sub_unit, 'شريط');
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: وجود «سعر الوحدة الصغرى» وحده يفعّل البيع بالتجزئة أيضاً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,سعر الوحدة الصغرى\nدواء تجزئة ب,8,12,20,10,1.5');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء تجزئة ب'");
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: غياب الوحدة الصغرى يُبقي البيع بالتجزئة كما هو (غير مفعّل)', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي\nدواء عادي,8,12,20');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء عادي'");
  assert.equal(p.allow_sub_unit, 0);
});

const licensePaths = () => [
  path.join(ctx.dir, 'license.json'),
  path.join(FAKE_HOME, '.shifaa', 'license.json'),
];
const seedPaths = () => [
  path.join(ctx.dir, 'device.json'),
  path.join(FAKE_HOME, '.shifaa', 'device.json'),
];
const resetLicenseFiles = () => {
  for (const f of [...licensePaths(), ...seedPaths()]) {
    try { fs.rmSync(f, { force: true }); } catch { /* ignore */ }
  }
  LIC.clearLicenseCache();
};

test('الترخيص: مفتاح جهاز آخر مرفوض', async () => {
  resetLicenseFiles();
  assert.equal(LIC.activate(LIC.expectedKey('ZZZZ-ZZZZ-ZZZZ')), false);
  assert.equal(LIC.isLicensed(), false);
});

test('الترخيص: التفعيل ينجح ويُحفظ في أكثر من موضع مستقل مع بذرة مجمّدة', async () => {
  resetLicenseFiles();
  const id = LIC.getDeviceId();
  assert.equal(LIC.activate(LIC.expectedKey(id)), true);
  assert.equal(LIC.isLicensed(), true);
  for (const f of licensePaths()) assert.ok(fs.existsSync(f), `لم يُحفظ الترخيص في ${f}`);
  for (const f of seedPaths()) assert.ok(fs.existsSync(f), `لم تُحفظ بذرة الجهاز في ${f}`);
  const rec = JSON.parse(fs.readFileSync(licensePaths()[0], 'utf8'));
  assert.equal(rec.version, 3, 'يجب أن يُحفظ سجل موقّع من الإصدار الثالث');
  assert.ok(rec.sig && rec.env && rec.env.host);
  assert.equal(rec.key, LIC.normalizeCode(LIC.expectedKey(id)), 'المفتاح المحفوظ يجب أن يكون مفتاح المعرّف الثابت');
});

test('الترخيص: حذف ملف مجلد البيانات لا يقفل النظام (بقاء نسخة احتياطية)', async () => {
  const id = LIC.getDeviceId();
  LIC.activate(LIC.expectedKey(id));
  fs.rmSync(licensePaths()[0], { force: true });
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), true, 'قُفل النظام رغم وجود نسخة ترخيص أخرى سليمة');
  assert.ok(fs.existsSync(licensePaths()[0]), 'لم تُستعد نسخة مجلد البيانات');
  assert.equal(LIC.getDeviceId(), id, 'تغيّر معرّف الجهاز بعد فقدان ملف');
});

test('الترخيص: حذف كل ملفات مجلد البيانات لا يغيّر المعرّف (البذرة في مجلد المستخدم)', async () => {
  const id = LIC.getDeviceId();
  LIC.activate(LIC.expectedKey(id));
  for (const f of [...licensePaths(), ...seedPaths()].filter((f) => f.startsWith(ctx.dir))) {
    try { fs.rmSync(f, { force: true }); } catch { /* ignore */ }
  }
  LIC.clearLicenseCache();
  assert.equal(LIC.getDeviceId(), id, 'المعرّف تغيّر رغم بقاء بذرة مجلد المستخدم');
  assert.equal(LIC.isLicensed(), true);
});

test('الترخيص: سجل قديم (بدون توقيع) يُقبل ويُرقّى تلقائياً', async () => {
  resetLicenseFiles();
  const id = LIC.getDeviceId();
  fs.writeFileSync(licensePaths()[0], JSON.stringify({
    key: LIC.expectedKey(id), device_id: id, activated_at: new Date().toISOString(),
  }));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), true);
  const rec = JSON.parse(fs.readFileSync(licensePaths()[0], 'utf8'));
  assert.equal(rec.version, 3);
});

test('الترخيص: ملف ترخيص معدّل يدوياً غير مقبول', async () => {
  resetLicenseFiles();
  fs.writeFileSync(licensePaths()[0], JSON.stringify({
    key: LIC.expectedKey('ZZZZ-ZZZZ-ZZZZ'), device_id: 'ZZZZ-ZZZZ-ZZZZ',
  }));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), false);
});

test('الترخيص: مطابقة البيئة تميّز نفس الجهاز عن جهاز غريب', async () => {
  const env = LIC.currentEnvironment();
  assert.ok(LIC.environmentMatchScore(env) >= 3, 'بصمة الجهاز الحالي يجب أن تطابق نفسها');
  const alien = { host: 'OTHER-PC', cpu: 'Alien CPU', platform: 'plan9', arch: 'mips', machine: 'x:y', macs: ['00:11:22:33:44:55'], user: 'nobodyelse' };
  assert.equal(LIC.environmentMatchScore(alien), 0);
});

test('الترخيص: تفعيل قديم (الإصدار الثاني) يُقبل رغم تغيّر معرّف العتاد ويُرقّى', async () => {
  const crypto = await import('node:crypto');
  resetLicenseFiles();
  // سجل بالشكل الذي كانت تكتبه النسخة السابقة: مفتاح لمعرّف عتاد قديم + بصمة بيئة + توقيع v2
  const secret = Buffer.from(
    ['U2hpZmFhLTIwMjYt', 'TGljZW5zZS1LZXkt', 'IXg3UXA5I3pSNCZ2', 'TjIkbUs4'].join(''), 'base64',
  ).toString('utf8');
  const oldId = 'AAAA-BBBB-CCCC'; // معرّف قديم لم يعد موجوداً (تبدّل كرت الشبكة)
  const rec = {
    version: 2,
    key: LIC.expectedKey(oldId).replace('-', ''),
    device_id: oldId,
    activated_at: new Date().toISOString(),
    instance: 'deadbeefdeadbeef',
    env: LIC.currentEnvironment(),
    last_seen: new Date().toISOString(),
  };
  rec.sig = crypto.createHmac('sha256', secret)
    .update(['SHIFAA-LIC-v2', rec.key, rec.device_id, rec.activated_at, rec.instance].join('|'))
    .digest('hex');
  fs.writeFileSync(licensePaths()[0], JSON.stringify(rec));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), true, 'قُفل تفعيل قديم رغم أن نفس الجهاز');
  const upgraded = JSON.parse(fs.readFileSync(licensePaths()[0], 'utf8'));
  assert.equal(upgraded.version, 3);
  assert.equal(upgraded.key, LIC.normalizeCode(LIC.expectedKey(LIC.getDeviceId())));
});

test('الترخيص: تفعيل قديم مُنتحل (توقيع خاطئ) مرفوض', async () => {
  resetLicenseFiles();
  const rec = {
    version: 2,
    key: LIC.expectedKey('AAAA-BBBB-CCCC').replace('-', ''),
    device_id: 'AAAA-BBBB-CCCC',
    activated_at: new Date().toISOString(),
    instance: 'deadbeefdeadbeef',
    env: LIC.currentEnvironment(),
    sig: 'f'.repeat(64),
  };
  fs.writeFileSync(licensePaths()[0], JSON.stringify(rec));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), false);
});

test('الترخيص: مفتاح بصمة عتاد قديمة لنفس الجهاز يبقى مقبولاً', async () => {
  resetLicenseFiles();
  const ids = LIC.candidateDeviceIds();
  assert.ok(ids.length >= 1);
  assert.equal(LIC.activate(LIC.expectedKey(ids[ids.length - 1])), true);
  assert.equal(LIC.isLicensed(), true);
});

/* ------------------------------------------------------------------
 * اختبارات «المعرّف لا يتغيّر» في عمليات مستقلة (تشغيل حقيقي، لا نفس
 * العملية الحالية) — هذه هي الثغرة التي كانت تُقفل النظام بعد يومين.
 * ------------------------------------------------------------------ */
const { execFileSync } = await import('node:child_process');
const SERVER_ROOT = path.resolve(import.meta.dirname, '..');
const ID_SCRIPT = 'import("./src/lib/license.js").then(m=>process.stdout.write(m.getDeviceId()))';

function deviceIdInFreshProcess({ dataDir, home, stubFile }) {
  const args = [];
  if (stubFile) args.push('--import', stubFile);
  args.push('-e', ID_SCRIPT);
  return execFileSync(process.execPath, args, {
    cwd: SERVER_ROOT,
    encoding: 'utf8',
    env: { ...process.env, DATA_DIR: dataDir, HOME: home, SHIFAA_LICENSE_STORES: 'all', NODE_ENV: 'production' },
  }).trim();
}

test('المعرّف: ثابت عبر عمليات تشغيل مستقلة', async () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'shifaa-id-'));
  const dataDir = path.join(base, 'data');
  const home = path.join(base, 'home');
  try {
    const a = deviceIdInFreshProcess({ dataDir, home });
    const b = deviceIdInFreshProcess({ dataDir, home });
    const c = deviceIdInFreshProcess({ dataDir, home });
    assert.match(a, /^[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/);
    assert.equal(b, a);
    assert.equal(c, a);
  } finally {
    fs.rmSync(base, { recursive: true, force: true });
  }
});

test('المعرّف: لا يتغيّر عند اختفاء كروت الشبكة', async () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'shifaa-net-'));
  const stub = path.join(base, 'no-net.mjs');
  fs.writeFileSync(stub, "import os from 'node:os';\nObject.defineProperty(os, 'networkInterfaces', { value: () => ({}) });\n");
  const dataDir = path.join(base, 'data');
  const home = path.join(base, 'home');
  try {
    const before = deviceIdInFreshProcess({ dataDir, home });
    const after = deviceIdInFreshProcess({ dataDir, home, stubFile: stub });
    assert.equal(after, before, 'تغيّر المعرّف بعد اختفاء كروت الشبكة');
  } finally {
    fs.rmSync(base, { recursive: true, force: true });
  }
});

test('المعرّف: لا يتغيّر بعد حذف مجلد البيانات (نسخة احتياطية في مجلد المستخدم)', async () => {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'shifaa-wipe-'));
  const home = path.join(base, 'home');
  let dataDir = path.join(base, 'data');
  try {
    const before = deviceIdInFreshProcess({ dataDir, home });
    fs.rmSync(dataDir, { recursive: true, force: true });
    dataDir = path.join(base, 'data-after-update'); // تحديث البرنامج يغيّر المجلد
    const after = deviceIdInFreshProcess({ dataDir, home });
    assert.equal(after, before, 'تغيّر المعرّف بعد تغيّر مجلد البيانات');
  } finally {
    fs.rmSync(base, { recursive: true, force: true });
  }
});

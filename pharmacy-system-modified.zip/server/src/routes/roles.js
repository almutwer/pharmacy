/**
 * إدارة الأدوار والصلاحيات (من الإعدادات)
 * - عرض كل الأدوار وصلاحياتها وعدد مستخدميها.
 * - إنشاء أدوار مخصصة جديدة (مثل «مساعد») بنسخ صلاحيات دور قائم وتعديلها.
 * - تعديل صلاحيات أي دور عدا مدير النظام (كامل دائماً).
 * - حذف الأدوار المخصصة غير المستخدمة فقط.
 */
import { Router } from 'express';
import { z } from 'zod';
import db from '../lib/db.js';
import { requireAuth, requirePermission } from '../lib/auth.js';
import { wrap, parse, notFound, HttpError, logActivity } from '../lib/helpers.js';
import { PERMISSIONS, sanitizePermissions } from '../lib/permissions.js';

const router = Router();
router.use(requireAuth);
const manageRoles = requirePermission('roles.manage');
const viewRoles = (req, res, next) => {
  const perms = req.user?.permissions || [];
  if (perms.includes('*') || perms.includes('roles.manage') || perms.includes('users.manage')) return next();
  return res.status(403).json({ error: 'ليس لديك صلاحية إدارة الأدوار أو المستخدمين' });
};

function parsePermissions(row) {
  try { return JSON.parse(row.permissions || '[]'); } catch { return []; }
}

function present(row) {
  const usersCount = db.value('SELECT COUNT(*) FROM users WHERE role = ?', [row.key]) || 0;
  return {
    ...row,
    permissions: row.key === 'admin' ? ['*'] : parsePermissions(row),
    is_system: !!row.is_system,
    active: !!row.active,
    users_count: usersCount,
  };
}

router.get(
  '/',
  viewRoles,
  wrap((req, res) => {
    const data = db.all('SELECT * FROM roles ORDER BY rank DESC, is_system DESC, label').map(present);
    res.json({ data, catalog: PERMISSIONS });
  }),
);

const createSchema = z.object({
  label: z.string().min(2, 'اسم الدور حرفان على الأقل').max(60),
  description: z.string().max(300).optional().nullable(),
  copy_from: z.string().optional().nullable(),
  permissions: z.array(z.string()).optional(),
  rank: z.coerce.number().int().min(1).max(4).default(1),
});

router.post(
  '/',
  manageRoles,
  wrap((req, res) => {
    const body = parse(createSchema, req.body);
    let permissions = body.permissions ? sanitizePermissions(body.permissions) : [];
    if (body.copy_from) {
      const source = db.get('SELECT * FROM roles WHERE key = ?', [body.copy_from]);
      if (!source) throw notFound('الدور المراد النسخ منه غير موجود');
      if (!body.permissions) permissions = parsePermissions(source);
      if (source.key === 'admin') permissions = permissions.filter((p) => p !== '*');
    }

    // مفتاح داخلي فريد (التسمية العربية للعرض فقط)
    let key = `role_${Date.now().toString(36)}`;
    while (db.get('SELECT key FROM roles WHERE key = ?', [key])) key = `${key}x`;

    db.insert('roles', {
      key,
      label: body.label.trim(),
      description: body.description || null,
      permissions: JSON.stringify(permissions),
      is_system: 0,
      rank: Math.min(3, body.rank),
      active: 1,
    });
    logActivity(req.user.id, 'create', 'roles', null, `دور جديد: ${body.label}`);
    res.status(201).json({ ok: true, data: present(db.get('SELECT * FROM roles WHERE key = ?', [key])) });
  }),
);

const updateSchema = z.object({
  label: z.string().min(2).max(60).optional(),
  description: z.string().max(300).optional().nullable(),
  permissions: z.array(z.string()).optional(),
  rank: z.coerce.number().int().min(1).max(4).optional(),
  active: z.coerce.number().int().min(0).max(1).optional(),
});

router.put(
  '/:key',
  manageRoles,
  wrap((req, res) => {
    const key = String(req.params.key);
    const role = db.get('SELECT * FROM roles WHERE key = ?', [key]);
    if (!role) throw notFound('الدور غير موجود');
    const body = parse(updateSchema, req.body);

    if (key === 'admin' && body.permissions) {
      throw new HttpError(400, 'دور مدير النظام (صاحب المحل) يملك كل الصلاحيات دائماً ولا يمكن تقليصها');
    }

    const payload = {};
    if (body.label !== undefined) payload.label = body.label.trim();
    if (body.description !== undefined) payload.description = body.description || null;
    if (body.permissions !== undefined) payload.permissions = JSON.stringify(sanitizePermissions(body.permissions));
    if (body.rank !== undefined) payload.rank = key === 'admin' ? 4 : Math.min(3, body.rank);
    if (body.active !== undefined) {
      if (key === 'admin' && body.active === 0) throw new HttpError(400, 'لا يمكن إيقاف دور مدير النظام');
      payload.active = body.active;
    }
    payload.updated_at = new Date().toISOString().slice(0, 19).replace('T', ' ');

    db.update('roles', payload, 'key = ?', [key]);
    logActivity(req.user.id, 'update', 'roles', null, `تعديل دور: ${role.label}`);
    res.json({ ok: true, data: present(db.get('SELECT * FROM roles WHERE key = ?', [key])) });
  }),
);

router.delete(
  '/:key',
  manageRoles,
  wrap((req, res) => {
    const key = String(req.params.key);
    const role = db.get('SELECT * FROM roles WHERE key = ?', [key]);
    if (!role) throw notFound('الدور غير موجود');
    if (role.is_system) throw new HttpError(400, 'أدوار النظام الأساسية لا تُحذف — يمكنك تعديل صلاحياتها أو إيقافها');
    const used = db.value('SELECT COUNT(*) FROM users WHERE role = ?', [key]) || 0;
    if (used) throw new HttpError(400, `لا يمكن حذف الدور: يوجد ${used} مستخدم مرتبط به. انقلهم لدور آخر أولاً`);
    db.run('DELETE FROM roles WHERE key = ?', [key]);
    logActivity(req.user.id, 'delete', 'roles', null, `حذف دور: ${role.label}`);
    res.json({ ok: true });
  }),
);

export default router;

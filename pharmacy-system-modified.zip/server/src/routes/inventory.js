/**
 * المخزون: التسويات، الدفعات، الحركات، الصلاحيات والتنبيهات
 */
import { Router } from 'express';
import { z } from 'zod';
import db from '../lib/db.js';
import { requireAuth, requirePermission } from '../lib/auth.js';
import { wrap, parse, notFound, HttpError, logActivity, getSettingNumber, round } from '../lib/helpers.js';
import { addBatch, recordMovement, allocateFEFO, deductBatch, restoreBatch } from '../lib/stock.js';

const router = Router();
router.use(requireAuth);

/* ================== تحديث الأسعار الجماعي ==================
 * لبيئات الأسعار سريعة التغيّر: تحديث أسعار البيع/الشراء دفعة واحدة
 * (نسبة % أو مبلغ ثابت أو هامش ربح مستهدف) مع معاينة قبل التطبيق،
 * وسجل تغييرات (price_changes) يتيح التراجع عن أي عملية كاملة.
 * ملاحظة محاسبية: تغيير «سعر شراء الصنف» يغيّر السعر المرجعي للمشتريات
 * القادمة والتسويات، ولا يغيّر تكلفة الدفعات الموجودة فعلياً (تكلفتها
 * التاريخية ثابتة)، بينما يغيّر سعر البيع أثره فوراً على البيع والتقييم.
 */

const priceUpdateSchema = z.object({
  scope: z.object({
    type: z.enum(['all', 'category', 'selected', 'search']),
    ids: z.array(z.coerce.number().int().positive()).max(1000).optional().default([]),
    category: z.string().optional().nullable(),
    q: z.string().optional().nullable(),
  }),
  target: z.enum(['sale', 'purchase', 'both']),
  method: z.enum(['percent', 'fixed', 'margin']),
  value: z.coerce.number().finite(),
  rounding: z.coerce.number().min(0).max(1000).default(0.01),
  reason: z.string().max(300).optional().nullable(),
  sync_catalog: z.coerce.boolean().default(false),
});

const ROUNDING_STEPS = [0, 0.01, 0.05, 0.1, 0.25, 0.5, 1, 5, 10, 50, 100];

function applyRounding(value, step) {
  const v = Math.max(0, Number(value) || 0);
  if (!step) return round(v);
  return round(Math.round(v / step) * step);
}

function priceScopeProducts(scope) {
  const where = ['p.active = 1'];
  const params = [];
  if (scope.type === 'category') {
    if (!scope.category) throw new HttpError(400, 'اختر التصنيف أولاً');
    where.push('p.category = ?'); params.push(scope.category);
  }
  if (scope.type === 'search') {
    if (!scope.q?.trim()) throw new HttpError(400, 'اكتب كلمة البحث أولاً');
    const like = `%${scope.q.trim()}%`;
    where.push('(p.name LIKE ? OR p.generic_name LIKE ? OR p.barcode LIKE ? OR p.manufacturer LIKE ?)');
    params.push(like, like, like, like);
  }
  if (scope.type === 'selected') {
    if (!scope.ids.length) throw new HttpError(400, 'لم يتم اختيار أي صنف');
    where.push(`p.id IN (${scope.ids.map(() => '?').join(',')})`);
    params.push(...scope.ids);
  }
  return db.all(`
    SELECT p.*, COALESCE(st.stock_qty, 0) AS stock_qty
    FROM products p
    LEFT JOIN (SELECT product_id, SUM(qty_available) AS stock_qty FROM batches GROUP BY product_id) st
      ON st.product_id = p.id
    WHERE ${where.join(' AND ')}
    ORDER BY p.name COLLATE NOCASE
  `, params);
}

/** حساب الأسعار الجديدة لصنف واحد — يعيد null إن لم يتغير أي سعر */
function computePriceChange(product, body) {
  if (body.method === 'margin' && body.target !== 'sale') {
    throw new HttpError(400, 'طريقة «هامش الربح» تُستخدم مع أسعار البيع فقط');
  }
  if (body.method === 'percent' && body.value <= -100) {
    throw new HttpError(400, 'نسبة التخفيض يجب أن تكون أكبر من ‎-100%');
  }
  const step = ROUNDING_STEPS.includes(body.rounding) ? body.rounding : 0.01;

  const oldPurchase = Number(product.purchase_price) || 0;
  const oldSale = Number(product.sale_price) || 0;

  let newPurchase = oldPurchase;
  if (body.target === 'purchase' || body.target === 'both') {
    newPurchase = body.method === 'percent'
      ? applyRounding(oldPurchase * (1 + body.value / 100), step)
      : applyRounding(oldPurchase + body.value, step);
  }

  let newSale = oldSale;
  if (body.target === 'sale' || body.target === 'both') {
    if (body.method === 'margin') newSale = applyRounding(newPurchase * (1 + body.value / 100), step);
    else if (body.method === 'percent') newSale = applyRounding(oldSale * (1 + body.value / 100), step);
    else newSale = applyRounding(oldSale + body.value, step);
  }

  // سعر الوحدة الصغرى اليدوي يتحرك بنفس نسبة تغيّر سعر بيع العبوة
  const oldSub = Number(product.sub_unit_price) || 0;
  let newSub = oldSub;
  if (oldSub > 0 && oldSale > 0 && newSale !== oldSale) {
    newSub = applyRounding(oldSub * (newSale / oldSale), step);
  }

  const changed = Math.abs(newPurchase - oldPurchase) > 0.0001
    || Math.abs(newSale - oldSale) > 0.0001
    || Math.abs(newSub - oldSub) > 0.0001;
  if (!changed) return null;

  const margin = (purchase, sale) => (purchase > 0 ? round(((sale - purchase) / purchase) * 100, 1) : null);
  return {
    product_id: product.id,
    name: product.name,
    category: product.category || '',
    unit: product.unit,
    stock_qty: round(product.stock_qty),
    catalog_id: product.catalog_id || null,
    old_purchase: oldPurchase, new_purchase: newPurchase,
    old_sale: oldSale, new_sale: newSale,
    old_sub_unit_price: oldSub, new_sub_unit_price: newSub,
    allow_sub_unit: product.allow_sub_unit,
    margin_before: margin(oldPurchase, oldSale),
    margin_after: margin(newPurchase, newSale),
  };
}

function buildPricePreview(body) {
  const products = priceScopeProducts(body.scope);
  const changes = [];
  let unchanged = 0;
  for (const p of products) {
    const change = computePriceChange(p, body);
    if (change) changes.push(change);
    else unchanged += 1;
  }
  const stockOf = (key) => changes.reduce((s, c) => s + c.stock_qty * c[key], 0);
  return {
    changes,
    summary: {
      matched: products.length,
      affected: changes.length,
      unchanged,
      stock_units: round(changes.reduce((s, c) => s + c.stock_qty, 0)),
      sale_value_before: round(stockOf('old_sale')),
      sale_value_after: round(stockOf('new_sale')),
      sale_value_diff: round(stockOf('new_sale') - stockOf('old_sale')),
    },
  };
}

/** معاينة تحديث الأسعار دون حفظ أي شيء */
router.post(
  '/price-update/preview',
  requirePermission('inventory.prices'),
  wrap((req, res) => {
    const body = parse(priceUpdateSchema, req.body);
    const { changes, summary } = buildPricePreview(body);
    res.json({ ok: true, summary, data: changes.slice(0, 200), truncated: changes.length > 200 });
  }),
);

/** تطبيق تحديث الأسعار (بعد المعاينة) مع تسجيله للتراجع لاحقاً */
router.post(
  '/price-update/apply',
  requirePermission('inventory.prices'),
  wrap((req, res) => {
    const body = parse(priceUpdateSchema, req.body);
    const { changes, summary } = buildPricePreview(body);
    if (!changes.length) throw new HttpError(400, 'لا توجد أصناف ستتغير أسعارها بهذه الإعدادات');

    const batchRef = `PC-${Date.now().toString(36).toUpperCase()}`;

    db.tx(() => {
      for (const c of changes) {
        db.update('products', {
          purchase_price: c.new_purchase,
          sale_price: c.new_sale,
          sub_unit_price: c.new_sub_unit_price,
          updated_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
        }, 'id = ?', [c.product_id]);

        // أسعار بيع الدفعات المسعّرة صراحة تتوحّد مع سعر البيع الجديد
        if (c.new_sale !== c.old_sale) {
          db.run('UPDATE batches SET sale_price = ? WHERE product_id = ? AND sale_price > 0', [c.new_sale, c.product_id]);
        }

        const record = (entity, itemId, field, oldValue, newValue) => {
          if (Math.abs(newValue - oldValue) <= 0.0001) return;
          db.insert('price_changes', {
            batch_ref: batchRef, entity, item_id: itemId, field,
            old_value: oldValue, new_value: newValue,
            reason: body.reason || null, user_id: req.user.id,
          });
        };
        record('product', c.product_id, 'purchase_price', c.old_purchase, c.new_purchase);
        record('product', c.product_id, 'sale_price', c.old_sale, c.new_sale);
        record('product', c.product_id, 'sub_unit_price', c.old_sub_unit_price, c.new_sub_unit_price);

        // مزامنة الأسعار الافتراضية للدواء المرتبط في الدليل (اختياري)
        if (body.sync_catalog && c.catalog_id) {
          const drug = db.get('SELECT default_purchase_price, default_sale_price FROM drug_catalog WHERE id = ?', [c.catalog_id]);
          if (drug) {
            db.update('drug_catalog', {
              default_purchase_price: c.new_purchase,
              default_sale_price: c.new_sale,
            }, 'id = ?', [c.catalog_id]);
            record('catalog', c.catalog_id, 'default_purchase_price', Number(drug.default_purchase_price) || 0, c.new_purchase);
            record('catalog', c.catalog_id, 'default_sale_price', Number(drug.default_sale_price) || 0, c.new_sale);
          }
        }
      }
    });

    logActivity(req.user.id, 'update', 'prices', null, `${batchRef}: تحديث أسعار ${changes.length} صنف — ${body.reason || 'بدون سبب'}`);
    res.json({ ok: true, batch_ref: batchRef, summary });
  }),
);

/** سجل عمليات تحديث الأسعار الجماعية */
router.get(
  '/price-updates/history',
  requirePermission('inventory.prices'),
  wrap((req, res) => {
    const limit = Math.min(50, Number(req.query.limit) || 20);
    const data = db.all(`
      SELECT pc.batch_ref,
             COUNT(*) AS records,
             COUNT(DISTINCT pc.item_id || '-' || pc.entity) AS items,
             MIN(pc.created_at) AS created_at,
             MAX(pc.reason) AS reason,
             SUM(CASE WHEN pc.reverted_at IS NOT NULL THEN 1 ELSE 0 END) AS reverted_records,
             u.full_name AS user_name
      FROM price_changes pc
      LEFT JOIN users u ON u.id = pc.user_id
      GROUP BY pc.batch_ref
      ORDER BY MAX(pc.id) DESC
      LIMIT ?
    `, [limit]);
    res.json({ data });
  }),
);

/** التراجع عن عملية تحديث أسعار كاملة (يعيد الأسعار القديمة إن لم تُعدَّل بعدها) */
router.post(
  '/price-updates/:ref/revert',
  requirePermission('inventory.prices'),
  wrap((req, res) => {
    const ref = String(req.params.ref || '');
    const records = db.all(
      'SELECT * FROM price_changes WHERE batch_ref = ? AND reverted_at IS NULL ORDER BY id DESC',
      [ref],
    );
    if (!records.length) throw new HttpError(404, 'لا توجد تغييرات قابلة للتراجع بهذا المرجع');

    let restored = 0;
    let skipped = 0;
    db.tx(() => {
      for (const r of records) {
        const table = r.entity === 'catalog' ? 'drug_catalog' : 'products';
        const current = db.get(`SELECT ${r.field} AS v FROM ${table} WHERE id = ?`, [r.item_id]);
        if (!current || Math.abs((Number(current.v) || 0) - r.new_value) > 0.0001) {
          skipped += 1; // تغيّر السعر بعد هذه العملية — لا نلمسه
          continue;
        }
        db.run(`UPDATE ${table} SET ${r.field} = ? WHERE id = ?`, [r.old_value, r.item_id]);
        if (r.entity === 'product' && r.field === 'sale_price') {
          db.run('UPDATE batches SET sale_price = ? WHERE product_id = ? AND sale_price > 0', [r.old_value, r.item_id]);
        }
        db.run("UPDATE price_changes SET reverted_at = datetime('now','localtime') WHERE id = ?", [r.id]);
        restored += 1;
      }
    });

    logActivity(req.user.id, 'update', 'prices', null, `تراجع عن ${ref}: أُعيد ${restored}، تُرك ${skipped}`);
    res.json({ ok: true, restored, skipped });
  }),
);

/** ملخص عام للمخزون */
router.get(
  '/summary',
  wrap((req, res) => {
    const lowLevel = getSettingNumber('low_stock_level', 10);
    const days = getSettingNumber('expiry_alert_days', 90);

    const totals = db.get(`
      SELECT COUNT(DISTINCT p.id) AS products,
             COALESCE(SUM(b.qty_available), 0) AS units,
             COALESCE(SUM(b.qty_available * b.cost_price), 0) AS cost_value,
             COALESCE(SUM(b.qty_available * CASE WHEN b.sale_price > 0 THEN b.sale_price ELSE p.sale_price END), 0) AS sale_value
      FROM products p LEFT JOIN batches b ON b.product_id = p.id
      WHERE p.active = 1
    `);

    const lowStock = db.value(`
      SELECT COUNT(*) FROM (
        SELECT p.id, COALESCE(SUM(b.qty_available),0) AS q, p.reorder_level
        FROM products p LEFT JOIN batches b ON b.product_id = p.id
        WHERE p.active = 1 GROUP BY p.id
      ) t WHERE t.q > 0 AND t.q <= CASE WHEN t.reorder_level > 0 THEN t.reorder_level ELSE ? END
    `, [lowLevel]);

    const outOfStock = db.value(`
      SELECT COUNT(*) FROM (
        SELECT p.id, COALESCE(SUM(b.qty_available),0) AS q FROM products p
        LEFT JOIN batches b ON b.product_id = p.id WHERE p.active = 1 GROUP BY p.id
      ) t WHERE t.q <= 0
    `);

    const expiringSoon = db.value(`
      SELECT COUNT(*) FROM batches b JOIN products p ON p.id = b.product_id
      WHERE b.qty_available > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <> ''
        AND date(b.expiry_date) BETWEEN date('now') AND date('now', '+' || ? || ' day')
    `, [days]);

    const expired = db.get(`
      SELECT COUNT(*) AS c, COALESCE(SUM(b.qty_available * b.cost_price),0) AS value
      FROM batches b WHERE b.qty_available > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <> ''
        AND date(b.expiry_date) < date('now')
    `);

    res.json({
      products: totals.products,
      units: round(totals.units),
      cost_value: round(totals.cost_value),
      sale_value: round(totals.sale_value),
      expected_profit: round(totals.sale_value - totals.cost_value),
      low_stock: lowStock,
      out_of_stock: outOfStock,
      expiring_soon: expiringSoon,
      expired: expired.c,
      expired_value: round(expired.value),
    });
  }),
);

/** الأصناف منخفضة المخزون */
router.get(
  '/low-stock',
  wrap((req, res) => {
    const lowLevel = getSettingNumber('low_stock_level', 10);
    const data = db.all(`
      SELECT p.id, p.name, p.unit, p.category, p.reorder_level, p.purchase_price, p.sale_price,
             COALESCE(SUM(b.qty_available),0) AS stock_qty
      FROM products p LEFT JOIN batches b ON b.product_id = p.id
      WHERE p.active = 1
      GROUP BY p.id
      HAVING stock_qty <= CASE WHEN p.reorder_level > 0 THEN p.reorder_level ELSE ? END
      ORDER BY stock_qty ASC, p.name LIMIT 200
    `, [lowLevel]);
    res.json({ data });
  }),
);

/**
 * الأدوية الراكدة (بطيئة الحركة)
 * صنف راكد = له رصيد متوفر، ولم يُبَع منه أكثر من `max_qty` خلال آخر `period_days` يوم.
 * القيم الافتراضية تُقرأ من الإعدادات (slow_moving_max_qty / slow_moving_period_days)
 * ويمكن تجاوزها من الواجهة عبر بارامترات الاستعلام.
 */
router.get(
  '/slow-moving',
  wrap((req, res) => {
    const maxQtyRaw = req.query.max_qty !== undefined && req.query.max_qty !== ''
      ? Number(req.query.max_qty) : getSettingNumber('slow_moving_max_qty', 5);
    const periodRaw = req.query.period_days !== undefined && req.query.period_days !== ''
      ? Number(req.query.period_days) : getSettingNumber('slow_moving_period_days', 30);
    const maxQty = Math.min(100000, Math.max(0, Number.isFinite(maxQtyRaw) ? maxQtyRaw : 5));
    const periodDays = Math.min(3650, Math.max(1, Math.round(Number.isFinite(periodRaw) ? periodRaw : 30)));

    const data = db.all(`
      SELECT p.id, p.name, p.generic_name, p.form, p.strength, p.unit, p.sub_unit,
             p.units_per_pack, p.allow_sub_unit, p.category, p.manufacturer, p.location,
             p.sale_price, p.purchase_price, p.reorder_level, p.created_at AS product_created_at,
             COALESCE(st.stock_qty, 0) AS stock_qty,
             COALESCE(st.stock_cost_value, 0) AS stock_cost_value,
             COALESCE(st.stock_sale_value, 0) AS stock_sale_value,
             COALESCE(s.sold_qty_period, 0) AS sold_qty,
             COALESCE(s.sold_qty_total, 0) AS sold_qty_total,
             s.last_sale_date,
             CASE WHEN s.last_sale_date IS NULL THEN NULL
                  ELSE CAST(julianday('now') - julianday(s.last_sale_date) AS INTEGER) END AS days_since_last_sale
      FROM products p
      LEFT JOIN (
        SELECT product_id,
               SUM(qty_available) AS stock_qty,
               SUM(qty_available * cost_price) AS stock_cost_value,
               SUM(qty_available * sale_price) AS stock_sale_value
        FROM batches GROUP BY product_id
      ) st ON st.product_id = p.id
      LEFT JOIN (
        SELECT si.product_id,
               SUM(CASE WHEN date(s.date) >= date('now', '-' || ? || ' day')
                        THEN si.qty - COALESCE(si.returned_qty, 0) ELSE 0 END) AS sold_qty_period,
               SUM(si.qty - COALESCE(si.returned_qty, 0)) AS sold_qty_total,
               MAX(date(s.date)) AS last_sale_date
        FROM sale_items si
        JOIN sales s ON s.id = si.sale_id
        WHERE s.status = 'completed'
        GROUP BY si.product_id
      ) s ON s.product_id = p.id
      WHERE p.active = 1 AND COALESCE(st.stock_qty, 0) > 0
        AND COALESCE(s.sold_qty_period, 0) <= ?
      ORDER BY sold_qty ASC, stock_cost_value DESC, p.name
      LIMIT 500
    `, [periodDays, maxQty]);

    const rows = data.map((r) => ({
      ...r,
      stock_qty: round(r.stock_qty),
      stock_cost_value: round(r.stock_cost_value),
      stock_sale_value: round(r.stock_sale_value),
      sold_qty: round(r.sold_qty),
      sold_qty_total: round(r.sold_qty_total),
      never_sold: !r.last_sale_date,
    }));

    res.json({
      data: rows,
      max_qty: maxQty,
      period_days: periodDays,
      summary: {
        count: rows.length,
        never_sold: rows.filter((r) => r.never_sold).length,
        tied_capital: round(rows.reduce((sum, r) => sum + r.stock_cost_value, 0)),
        tied_sale_value: round(rows.reduce((sum, r) => sum + r.stock_sale_value, 0)),
      },
    });
  }),
);

/** الدفعات القريبة من الانتهاء / المنتهية */
router.get(
  '/expiry',
  wrap((req, res) => {
    const days = Number(req.query.days) || getSettingNumber('expiry_alert_days', 90);
    const mode = req.query.mode || 'soon'; // soon | expired | all
    let cond = "date(b.expiry_date) BETWEEN date('now') AND date('now', '+' || ? || ' day')";
    const params = [days];
    if (mode === 'expired') { cond = "date(b.expiry_date) < date('now')"; params.length = 0; }
    if (mode === 'all') { cond = "date(b.expiry_date) <= date('now', '+' || ? || ' day')"; }

    const data = db.all(`
      SELECT b.*, p.name AS product_name, p.unit, p.category,
             ROUND(julianday(b.expiry_date) - julianday('now')) AS days_left,
             b.qty_available * b.cost_price AS value
      FROM batches b JOIN products p ON p.id = b.product_id
      WHERE b.qty_available > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <> '' AND ${cond}
      ORDER BY b.expiry_date ASC LIMIT 500
    `, params);
    res.json({ data });
  }),
);

/** حركات المخزون */
router.get(
  '/movements',
  wrap((req, res) => {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(200, Number(req.query.limit) || 50);
    const where = ['1=1'];
    const params = [];
    if (req.query.product_id) { where.push('m.product_id = ?'); params.push(Number(req.query.product_id)); }
    if (req.query.type) { where.push('m.type = ?'); params.push(req.query.type); }
    if (req.query.from) { where.push('date(m.date) >= date(?)'); params.push(req.query.from); }
    if (req.query.to) { where.push('date(m.date) <= date(?)'); params.push(req.query.to); }
    if (req.query.q) { where.push('p.name LIKE ?'); params.push(`%${req.query.q}%`); }

    const whereSql = where.join(' AND ');
    const total = db.value(`SELECT COUNT(*) FROM stock_movements m JOIN products p ON p.id = m.product_id WHERE ${whereSql}`, params);
    const data = db.all(`
      SELECT m.*, p.name AS product_name, p.unit, u.full_name AS user_name, b.batch_no
      FROM stock_movements m
      JOIN products p ON p.id = m.product_id
      LEFT JOIN users u ON u.id = m.user_id
      LEFT JOIN batches b ON b.id = m.batch_id
      WHERE ${whereSql} ORDER BY m.id DESC LIMIT ? OFFSET ?
    `, [...params, limit, (page - 1) * limit]);
    res.json({ data, total, page, limit, pages: Math.ceil(total / limit) || 1 });
  }),
);

/** تسوية مخزنية (إدخال / إخراج / تالف / منتهي) */
const adjustSchema = z.object({
  product_id: z.coerce.number().int().positive(),
  batch_id: z.coerce.number().int().positive().optional().nullable(),
  type: z.enum(['adjust_in', 'adjust_out', 'damage', 'expired']),
  qty: z.coerce.number().positive('الكمية يجب أن تكون أكبر من صفر'),
  cost_price: z.coerce.number().min(0).optional(),
  sale_price: z.coerce.number().min(0).optional(),
  batch_no: z.string().optional().nullable(),
  expiry_date: z.string().optional().nullable(),
  note: z.string().optional().nullable(),
});

router.post(
  '/adjust',
  requirePermission('inventory.adjust'),
  wrap((req, res) => {
    const data = parse(adjustSchema, req.body);
    const product = db.get('SELECT * FROM products WHERE id = ?', [data.product_id]);
    if (!product) throw notFound('الصنف غير موجود');

    const result = db.tx(() => {
      if (data.type === 'adjust_in') {
        let batchId = data.batch_id;
        if (batchId) {
          restoreBatch(batchId, data.qty);
          db.run('UPDATE batches SET qty_in = qty_in + ? WHERE id = ?', [data.qty, batchId]);
        } else {
          batchId = addBatch({
            productId: product.id,
            batchNo: data.batch_no || null,
            expiryDate: data.expiry_date || null,
            qty: data.qty,
            costPrice: data.cost_price ?? product.purchase_price,
            salePrice: data.sale_price ?? product.sale_price,
          });
        }
        recordMovement({
          productId: product.id, batchId, type: 'adjust_in', qty: data.qty,
          unitCost: data.cost_price ?? product.purchase_price, refType: 'adjustment',
          note: data.note, userId: req.user.id,
        });
        return { batchId };
      }

      // إخراج
      const allocations = data.batch_id
        ? [{ batchId: data.batch_id, qty: data.qty, costPrice: db.value('SELECT cost_price FROM batches WHERE id = ?', [data.batch_id]) || 0 }]
        : allocateFEFO(product.id, data.qty);

      if (data.batch_id) {
        const avail = db.value('SELECT qty_available FROM batches WHERE id = ?', [data.batch_id]) || 0;
        if (avail < data.qty) throw new HttpError(400, `الكمية المتاحة في الدفعة (${avail}) أقل من المطلوب`);
      }

      for (const a of allocations) {
        deductBatch(a.batchId, a.qty);
        recordMovement({
          productId: product.id, batchId: a.batchId, type: data.type, qty: -a.qty,
          unitCost: a.costPrice, refType: 'adjustment', note: data.note, userId: req.user.id,
        });
      }
      return { allocations: allocations.length };
    });

    logActivity(req.user.id, 'adjust', 'inventory', product.id, `${data.type} ${data.qty} ${product.name}`);
    res.json({ ok: true, ...result });
  }),
);

/** تعديل بيانات دفعة */
router.put(
  '/batches/:id',
  requirePermission('inventory.adjust'),
  wrap((req, res) => {
    const id = Number(req.params.id);
    const batch = db.get('SELECT * FROM batches WHERE id = ?', [id]);
    if (!batch) throw notFound('الدفعة غير موجودة');
    const data = parse(
      z.object({
        batch_no: z.string().optional().nullable(),
        expiry_date: z.string().optional().nullable(),
        cost_price: z.coerce.number().min(0).optional(),
        sale_price: z.coerce.number().min(0).optional(),
      }),
      req.body,
    );
    db.update('batches', data, 'id = ?', [id]);
    logActivity(req.user.id, 'update', 'batches', id, null);
    res.json({ ok: true });
  }),
);

/** إتلاف الدفعات المنتهية دفعة واحدة */
router.post(
  '/dispose-expired',
  requirePermission('inventory.adjust'),
  wrap((req, res) => {
    const expired = db.all(`
      SELECT b.*, p.name FROM batches b JOIN products p ON p.id = b.product_id
      WHERE b.qty_available > 0 AND b.expiry_date IS NOT NULL AND b.expiry_date <> '' AND date(b.expiry_date) < date('now')
    `);
    let count = 0;
    let value = 0;
    db.tx(() => {
      for (const b of expired) {
        recordMovement({
          productId: b.product_id, batchId: b.id, type: 'expired', qty: -b.qty_available,
          unitCost: b.cost_price, refType: 'disposal', note: 'إتلاف دفعة منتهية الصلاحية', userId: req.user.id,
        });
        value += b.qty_available * b.cost_price;
        db.run('UPDATE batches SET qty_available = 0 WHERE id = ?', [b.id]);
        count++;
      }
    });
    logActivity(req.user.id, 'dispose', 'inventory', null, `إتلاف ${count} دفعة`);
    res.json({ ok: true, count, value: round(value) });
  }),
);

export default router;

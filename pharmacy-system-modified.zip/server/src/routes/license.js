/**
 * مسارات تفعيل النظام (قفل الجهاز) + حارس يمنع استخدام الـAPI قبل التفعيل.
 * مستقلة عن بقية المسارات: /api/license/status و /api/license/activate
 */
import { Router } from 'express';
import { wrap, HttpError } from '../lib/helpers.js';
import { licenseStatus, activate, isLicensed } from '../lib/license.js';

const router = Router();

router.get('/status', wrap((req, res) => {
  res.json({ app: 'نظام شفاء', ...licenseStatus() });
}));

router.post('/activate', wrap((req, res) => {
  const key = req.body?.key;
  if (!key || typeof key !== 'string') throw new HttpError(400, 'أدخل مفتاح التفعيل');
  if (!activate(key)) throw new HttpError(400, 'مفتاح التفعيل غير صحيح لهذا الجهاز');
  res.json({ licensed: true, message: 'تم تفعيل النظام بنجاح' });
}));

/**
 * حارس الترخيص: يمنع أي استخدام للواجهة البرمجية قبل التفعيل (رد 423).
 * يُستثنى وضع الاختبارات حتى لا تتأثر اختبارات النظام الآلية.
 */
export function licenseGuard(req, res, next) {
  if (process.env.NODE_ENV === 'test') return next();
  // الحماية على الـAPI فقط — ملفات الواجهة وصفحة الدخول يجب أن تُخدَم دائماً
  // حتى تظهر شاشة التفعيل للمستخدم بدل صفحة JSON بيضاء.
  if (!req.path.startsWith('/api/')) return next();
  if (req.path.startsWith('/api/license') || req.path === '/api/health') return next();
  if (isLicensed()) return next();
  return res.status(423).json({
    error: 'هذه النسخة غير مفعّلة على هذا الجهاز',
    license_required: true,
    device_id: licenseStatus().device_id,
  });
}

export default router;

import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import db from '../lib/db.js';
import { requireAuth, requirePermission } from '../lib/auth.js';
import { wrap, parse, HttpError, notFound, logActivity } from '../lib/helpers.js';

const router = Router();
router.use(requireAuth, requirePermission('users.manage'));

const userSchema = z.object({
  username: z.string().min(3, 'اسم المستخدم 3 أحرف على الأقل'),
  full_name: z.string().min(2, 'الاسم مطلوب'),
  // حقل كلمة المرور الفارغ عند التعديل يعني «بدون تغيير» (يُعامَل كغير مُرسل)
  password: z.preprocess(
    (v) => (v === '' || v === null ? undefined : v),
    z.string().min(4, 'كلمة المرور 4 أحرف على الأقل').optional(),
  ),
  role: z.string().min(1, 'الدور مطلوب'),
  phone: z.string().optional().nullable(),
  active: z.coerce.number().int().min(0).max(1).default(1),
});

/** التأكد أن الدور موجود ومفعّل (أساسي أو مخصص) */
function ensureRoleExists(roleKey) {
  const role = db.get('SELECT key FROM roles WHERE key = ? AND active = 1', [roleKey]);
  if (!role) throw new HttpError(422, 'الدور المحدد غير موجود أو موقوف');
}

/** عدد مديري النظام النشطين */
function activeAdminCount() {
  return db.value("SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1") || 0;
}

/**
 * يمنع إزالة آخر مدير نظام نشط (سواء بالحذف أو الإيقاف أو تغيير الدور)
 * حتى لا يُغلق النظام على نفسه بلا أي مدير.
 */
function guardLastAdmin(user, { nextRole, nextActive } = {}) {
  const wasActiveAdmin = user.role === 'admin' && user.active === 1;
  if (!wasActiveAdmin) return;
  const stillActiveAdmin = (nextRole === undefined ? 'admin' : nextRole) === 'admin'
    && (nextActive === undefined ? 1 : nextActive) === 1;
  if (!stillActiveAdmin && activeAdminCount() <= 1) {
    throw new HttpError(400, 'لا يمكن إزالة آخر مدير نظام نشط — عيّن مديراً آخر أولاً');
  }
}

router.get(
  '/',
  wrap((req, res) => {
    res.json({
      data: db.all(
        `SELECT u.id, u.username, u.full_name, u.role, r.label AS role_label, u.phone, u.active, u.last_login, u.created_at
         FROM users u LEFT JOIN roles r ON r.key = u.role ORDER BY u.id`,
      ),
    });
  }),
);

router.post(
  '/',
  wrap((req, res) => {
    const data = parse(userSchema, req.body);
    if (!data.password) throw new HttpError(422, 'كلمة المرور مطلوبة');
    ensureRoleExists(data.role);
    const exists = db.get('SELECT id FROM users WHERE lower(username) = lower(?)', [data.username]);
    if (exists) throw new HttpError(409, 'اسم المستخدم مستخدم مسبقاً');
    const { lastInsertRowid } = db.insert('users', {
      username: data.username,
      full_name: data.full_name,
      password_hash: bcrypt.hashSync(data.password, 10),
      role: data.role,
      phone: data.phone || null,
      active: data.active,
    });
    logActivity(req.user.id, 'create', 'users', lastInsertRowid, data.username);
    res.status(201).json({ id: lastInsertRowid });
  }),
);

router.put(
  '/:id',
  wrap((req, res) => {
    const id = Number(req.params.id);
    const user = db.get('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) throw notFound('المستخدم غير موجود');
    const data = parse(userSchema.partial(), req.body);
    if (data.role !== undefined) ensureRoleExists(data.role);

    const payload = {};
    for (const key of ['username', 'full_name', 'role', 'phone', 'active']) {
      if (data[key] !== undefined) payload[key] = data[key];
    }
    if (data.password) payload.password_hash = bcrypt.hashSync(data.password, 10);
    if (id === req.user.id && payload.active === 0) throw new HttpError(400, 'لا يمكنك إيقاف حسابك الخاص');
    guardLastAdmin(user, { nextRole: payload.role, nextActive: payload.active });

    db.update('users', payload, 'id = ?', [id]);
    logActivity(req.user.id, 'update', 'users', id, payload.username || user.username);
    res.json({ ok: true });
  }),
);

router.delete(
  '/:id',
  wrap((req, res) => {
    const id = Number(req.params.id);
    if (id === req.user.id) throw new HttpError(400, 'لا يمكنك حذف حسابك الخاص');
    const user = db.get('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) throw notFound('المستخدم غير موجود');
    guardLastAdmin(user, { nextActive: 0 }); // الحذف أو الإيقاف يزيل المدير فعلياً
    const used = db.value('SELECT COUNT(*) FROM sales WHERE user_id = ?', [id]);
    if (used) {
      db.update('users', { active: 0 }, 'id = ?', [id]);
      return res.json({ ok: true, message: 'المستخدم مرتبط بفواتير، تم إيقافه بدل الحذف' });
    }
    db.run('DELETE FROM users WHERE id = ?', [id]);
    logActivity(req.user.id, 'delete', 'users', id, null);
    res.json({ ok: true });
  }),
);

export default router;

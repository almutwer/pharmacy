import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useApp } from './context/AppContext.jsx';
import Layout from './components/Layout.jsx';
import { Loading } from './components/ui.jsx';

import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import POS from './pages/POS.jsx';
import Sales from './pages/Sales.jsx';
import Purchases from './pages/Purchases.jsx';
import Inventory from './pages/Inventory.jsx';
import Catalog from './pages/Catalog.jsx';
import Expenses from './pages/Expenses.jsx';
import Reports from './pages/Reports.jsx';
import { Suppliers, Customers } from './pages/Parties.jsx';
import Settings from './pages/Settings.jsx';

function Guard({ perm, children }) {
  const { canDo } = useApp();
  if (perm && !canDo(perm)) {
    return (
      <div className="card p-10 text-center">
        <p className="text-lg font-extrabold text-ink-800">لا تملك صلاحية الوصول لهذه الصفحة</p>
        <p className="mt-1 text-sm text-ink-400">يرجى مراجعة مدير النظام لمنحك الصلاحية المناسبة</p>
      </div>
    );
  }
  return children;
}

export default function App() {
  const { user, booting } = useApp();

  if (booting) {
    return <div className="grid min-h-screen place-items-center bg-ink-50"><Loading label="جاري تهيئة النظام..." /></div>;
  }

  if (!user) return <Login />;

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/pos" element={<Guard perm="pos.use"><POS /></Guard>} />
        <Route path="/sales" element={<Guard perm="sales.view"><Sales /></Guard>} />
        <Route path="/purchases" element={<Guard perm="purchases.view"><Purchases /></Guard>} />
        <Route path="/inventory" element={<Guard perm="inventory.view"><Inventory /></Guard>} />
        <Route path="/catalog" element={<Guard perm="catalog.view"><Catalog /></Guard>} />
        <Route path="/expenses" element={<Guard perm="expenses.view"><Expenses /></Guard>} />
        <Route path="/reports" element={<Guard perm="reports.view"><Reports /></Guard>} />
        <Route path="/suppliers" element={<Guard perm="suppliers.view"><Suppliers /></Guard>} />
        <Route path="/customers" element={<Guard perm="customers.view"><Customers /></Guard>} />
        <Route path="/settings" element={<Guard perm="settings.view"><Settings /></Guard>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

import React, { useCallback, useEffect, useState } from 'react';
import {
  BookOpen, Plus, Search, Pencil, Trash2, PackagePlus, Info, Upload, CheckCircle2, Filter, FlaskConical,
  FileInput, ListPlus, X, CheckSquare, Loader2, FileSpreadsheet, AlertTriangle,
} from 'lucide-react';
import api, { fileToBase64 } from '../api.js';
import { useApp } from '../context/AppContext.jsx';
import {
  PageHeader, Card, Table, Pagination, Badge, Field, Input, Select, Textarea, Modal, useToast,
  StatCard, ConfirmDialog, EmptyState,
} from '../components/ui.jsx';
import ExcelIO from '../components/ExcelIO.jsx';
import { fmtNum, fmtInt, DOSAGE_FORMS, UNITS } from '../lib/format.js';

const emptyDrug = () => ({
  trade_name: '', generic_name: '', form: '', strength: '', unit: 'علبة', category: '',
  manufacturer: '', country: '', barcode: '', atc_code: '', default_purchase_price: 0,
  default_sale_price: 0, requires_prescription: 0, storage_conditions: '', notes: '', active: 1,
});

export default function Catalog() {
  const { currency, can } = useApp();
  const toast = useToast();

  const [filters, setFilters] = useState({ q: '', category: '', form: '', manufacturer: '', only_unlinked: '' });
  const [page, setPage] = useState(1);
  const [res, setRes] = useState({ data: [], total: 0, pages: 1 });
  const [meta, setMeta] = useState({ categories: [], forms: [], manufacturers: [], total: 0, linked: 0 });
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [addToStock, setAddToStock] = useState(null);
  const [importOpen, setImportOpen] = useState(false);
  const [inventoryImportOpen, setInventoryImportOpen] = useState(false);
  // تحديد جماعي: خريطة id ← بيانات الدواء
  const [selected, setSelected] = useState({});
  const [bulkOpen, setBulkOpen] = useState(false);
  const selectedDrugs = Object.values(selected);
  const selectedCount = selectedDrugs.length;

  const loadMeta = useCallback(() => api.get('/catalog/meta').then(setMeta), []);
  const load = useCallback(async () => {
    setLoading(true);
    try { setRes(await api.get('/catalog', { ...filters, page, limit: 20 })); } finally { setLoading(false); }
  }, [filters, page]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadMeta(); }, [loadMeta]);

  const save = async () => {
    try {
      if (form.id) { await api.put(`/catalog/${form.id}`, form); toast.success('تم تحديث بيانات الدواء'); }
      else { await api.post('/catalog', form); toast.success('تمت إضافة الدواء إلى الدليل'); }
      setForm(null); load(); loadMeta();
    } catch (err) { toast.error(err.message); }
  };

  const remove = async () => {
    try {
      await api.del(`/catalog/${deleteId}`);
      toast.success('تم حذف الدواء من الدليل');
      setDeleteId(null); load(); loadMeta();
    } catch (err) { toast.error(err.message); setDeleteId(null); }
  };

  const toggleSelect = (drug) => {
    if (drug.in_inventory) return;
    setSelected((prev) => {
      const next = { ...prev };
      if (next[drug.id]) delete next[drug.id];
      else next[drug.id] = drug;
      return next;
    });
  };

  const selectPage = () => {
    setSelected((prev) => {
      const next = { ...prev };
      res.data.filter((d) => !d.in_inventory).forEach((d) => { next[d.id] = d; });
      return next;
    });
  };

  const confirmAddToStock = async () => {
    try {
      await api.post(`/products/from-catalog/${addToStock.drug.id}`, {
        purchase_price: Number(addToStock.purchase_price) || 0,
        sale_price: Number(addToStock.sale_price) || 0,
        reorder_level: Number(addToStock.reorder_level) || 10,
        location: addToStock.location || null,
        opening_qty: Number(addToStock.opening_qty) || 0,
        opening_expiry: addToStock.opening_expiry || null,
      });
      toast.success(`تمت إضافة «${addToStock.drug.trade_name}» إلى المخزون`);
      setAddToStock(null); load(); loadMeta();
    } catch (err) { toast.error(err.message); }
  };

  return (
    <div>
      <PageHeader
        title="دليل الأدوية" subtitle="مرجع شامل للأدوية — لا يظهر في المخزون ويُستخدم لإدخال الأدوية بسرعة" icon={BookOpen}
        actions={(
          <>
            <ExcelIO
              entity="catalog"
              filters={filters}
              canImport={can('pharmacist')}
              onDone={() => { load(); loadMeta(); }}
            />
            {can('pharmacist') && (
              <>
                <button className="btn-outline" onClick={() => setInventoryImportOpen(true)} title="رفع ملف Excel مُصدَّر من قسم المخزون لتحويل أصنافه إلى أدوية في الدليل">
                  <FileInput className="h-4 w-4" /> استيراد من المخزون
                </button>
                <button className="btn-outline" onClick={() => setImportOpen(true)} title="لصق بيانات نصية بصيغة CSV">
                  <Upload className="h-4 w-4" /> لصق نصي
                </button>
                <button className="btn-primary" onClick={() => setForm(emptyDrug())}><Plus className="h-4 w-4" /> دواء جديد</button>
              </>
            )}
          </>
        )}
      />

      <div className="mb-4 flex items-start gap-3 rounded-2xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-900">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-sky-600" />
        <p className="leading-7">
          <strong>دليل الأدوية مرجعي فقط:</strong> لا يحتوي على أرصدة ولا يظهر ضمن تقارير المخزون.
          استخدمه لإدخال الأدوية بسرعة عند إنشاء <strong>فاتورة شراء</strong> أو عبر زر
          <Badge tone="brand" className="mx-1"><PackagePlus className="h-3 w-3" /> إضافة للمخزون</Badge>
          ليتحول الدواء إلى صنف فعلي يُدار رصيده ودفعاته.
        </p>
      </div>

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="إجمالي أدوية الدليل" value={fmtInt(meta.total)} icon={BookOpen} tone="violet" />
        <StatCard label="مضاف إلى المخزون" value={fmtInt(meta.linked)} sub="أصناف مرتبطة" icon={CheckCircle2} tone="brand" />
        <StatCard label="غير مضاف للمخزون" value={fmtInt(Math.max(0, meta.total - meta.linked))} sub="مرجع فقط" icon={FlaskConical} tone="amber" />
        <StatCard label="التصنيفات" value={fmtInt(meta.categories?.length)} sub={`${meta.manufacturers?.length || 0} شركة مصنعة`} icon={Filter} tone="blue" />
      </div>

      <Card className="mb-4 p-4">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="بحث" className="min-w-[220px] flex-1">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
              <Input className="pr-9" placeholder="الاسم التجاري / العلمي / الباركود / الشركة" value={filters.q}
                onChange={(e) => { setFilters({ ...filters, q: e.target.value }); setPage(1); }} />
            </div>
          </Field>
          <Field label="التصنيف">
            <Select value={filters.category} onChange={(e) => { setFilters({ ...filters, category: e.target.value }); setPage(1); }}>
              <option value="">الكل</option>
              {meta.categories?.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="الشكل">
            <Select value={filters.form} onChange={(e) => { setFilters({ ...filters, form: e.target.value }); setPage(1); }}>
              <option value="">الكل</option>
              {meta.forms?.map((f) => <option key={f} value={f}>{f}</option>)}
            </Select>
          </Field>
          <Field label="الشركة">
            <Select value={filters.manufacturer} onChange={(e) => { setFilters({ ...filters, manufacturer: e.target.value }); setPage(1); }}>
              <option value="">الكل</option>
              {meta.manufacturers?.map((m) => <option key={m} value={m}>{m}</option>)}
            </Select>
          </Field>
          <Field label="الحالة في المخزون">
            <Select value={filters.only_unlinked} onChange={(e) => { setFilters({ ...filters, only_unlinked: e.target.value }); setPage(1); }}>
              <option value="">الكل</option>
              <option value="1">غير مضاف للمخزون فقط</option>
            </Select>
          </Field>
        </div>
      </Card>

      {/* شريط التحديد الجماعي */}
      {can('pharmacist') && (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-brand-200 bg-brand-50/70 px-4 py-3">
          <span className="flex items-center gap-2 text-sm font-extrabold text-brand-900">
            <CheckSquare className="h-4 w-4" />
            {selectedCount ? `تم اختيار ${selectedCount} دواء للإضافة الجماعية` : 'اختر أدوية من عمود «اختيار» لإضافتها للمخزون دفعة واحدة'}
          </span>
          <div className="mr-auto flex flex-wrap gap-2">
            <button className="btn-outline btn-sm" onClick={selectPage}>تحديد غير المضافة في هذه الصفحة</button>
            {selectedCount > 0 && (
              <>
                <button className="btn-ghost btn-sm" onClick={() => setSelected({})}>إلغاء التحديد</button>
                <button className="btn-primary btn-sm" onClick={() => setBulkOpen(true)}>
                  <ListPlus className="h-4 w-4" /> إنهاء الاختيار وإضافة {selectedCount} للمخزون
                </button>
              </>
            )}
          </div>
        </div>
      )}

      <Table
        loading={loading}
        columns={['اختيار', 'الاسم التجاري', 'المادة الفعالة', 'الشكل / التركيز', 'التصنيف', 'الشركة', 'سعر الشراء', 'سعر البيع', 'وصفة', 'المخزون', '']}
        rows={res.data}
        empty={<EmptyState title="لا توجد أدوية في الدليل" hint="أضف دواءً جديداً أو استورد قائمة كاملة" icon={BookOpen} />}
        renderRow={(d) => (
          <tr key={d.id} className={selected[d.id] ? 'bg-brand-50/70' : ''}>
            <td>
              <input
                type="checkbox"
                className="h-4 w-4 cursor-pointer accent-emerald-600 disabled:cursor-not-allowed disabled:opacity-30"
                checked={!!selected[d.id]}
                disabled={!!d.in_inventory || !can('pharmacist')}
                onChange={() => toggleSelect(d)}
                title={d.in_inventory ? 'مضاف إلى المخزون مسبقاً' : 'اختيار للإضافة الجماعية'}
              />
            </td>
            <td>
              <p className="font-extrabold text-ink-900">{d.trade_name}</p>
              <p className="text-[11px] text-ink-400">{d.barcode || '—'}</p>
            </td>
            <td className="text-ink-600">{d.generic_name || '—'}</td>
            <td className="text-ink-500">{[d.form, d.strength].filter(Boolean).join(' · ') || '—'}</td>
            <td className="text-ink-500">{d.category || '—'}</td>
            <td className="text-ink-500">{d.manufacturer || '—'}<span className="block text-[11px] text-ink-400">{d.country || ''}</span></td>
            <td className="num">{fmtNum(d.default_purchase_price)}</td>
            <td className="num font-bold text-brand-700">{fmtNum(d.default_sale_price)} {currency}</td>
            <td>{d.requires_prescription ? <Badge tone="red">وصفة</Badge> : <Badge tone="gray">حر</Badge>}</td>
            <td>{d.in_inventory ? <Badge tone="green">مضاف</Badge> : <Badge tone="violet">غير مضاف</Badge>}</td>
            <td>
              <div className="flex items-center gap-1">
                {can('pharmacist') && !d.in_inventory && (
                  <button
                    className="btn-primary btn-sm"
                    onClick={() => setAddToStock({
                      drug: d,
                      purchase_price: d.default_purchase_price,
                      sale_price: d.default_sale_price,
                      reorder_level: 10, location: '', opening_qty: 0, opening_expiry: '',
                    })}
                  >
                    <PackagePlus className="h-3.5 w-3.5" /> للمخزون
                  </button>
                )}
                {can('pharmacist') && <button className="btn-outline btn-sm" onClick={() => setForm({ ...d })}><Pencil className="h-3.5 w-3.5" /></button>}
                {can('manager') && <button className="btn-outline btn-sm text-rose-600" onClick={() => setDeleteId(d.id)}><Trash2 className="h-3.5 w-3.5" /></button>}
              </div>
            </td>
          </tr>
        )}
      />
      <Pagination page={page} pages={res.pages} total={res.total} onChange={setPage} />

      {/* نموذج الدواء */}
      <Modal
        open={!!form} onClose={() => setForm(null)} size="lg"
        title={form?.id ? `تعديل: ${form.trade_name}` : 'إضافة دواء إلى الدليل'}
        subtitle="بيانات مرجعية تُستخدم لإدخال الأدوية بسرعة — لا تؤثر على أرصدة المخزون"
        footer={<><button className="btn-ghost" onClick={() => setForm(null)}>إلغاء</button>
          <button className="btn-primary" onClick={save}>حفظ</button></>}
      >
        {form && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="الاسم التجاري" required className="sm:col-span-2">
              <Input autoFocus value={form.trade_name} onChange={(e) => setForm({ ...form, trade_name: e.target.value })} />
            </Field>
            <Field label="المادة الفعالة">
              <Input value={form.generic_name || ''} onChange={(e) => setForm({ ...form, generic_name: e.target.value })} />
            </Field>
            <Field label="الشكل الصيدلاني">
              <Select value={form.form || ''} onChange={(e) => setForm({ ...form, form: e.target.value })}>
                <option value="">—</option>
                {DOSAGE_FORMS.map((f) => <option key={f} value={f}>{f}</option>)}
              </Select>
            </Field>
            <Field label="التركيز"><Input value={form.strength || ''} onChange={(e) => setForm({ ...form, strength: e.target.value })} placeholder="500 مجم" /></Field>
            <Field label="وحدة الصرف">
              <Select value={form.unit || ''} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
                {UNITS.map((u) => <option key={u} value={u}>{u}</option>)}
              </Select>
            </Field>
            <Field label="التصنيف الدوائي"><Input value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
            <Field label="الشركة المصنعة"><Input value={form.manufacturer || ''} onChange={(e) => setForm({ ...form, manufacturer: e.target.value })} /></Field>
            <Field label="بلد المنشأ"><Input value={form.country || ''} onChange={(e) => setForm({ ...form, country: e.target.value })} /></Field>
            <Field label="الباركود"><Input value={form.barcode || ''} onChange={(e) => setForm({ ...form, barcode: e.target.value })} /></Field>
            <Field label="كود ATC"><Input value={form.atc_code || ''} onChange={(e) => setForm({ ...form, atc_code: e.target.value })} /></Field>
            <Field label="سعر الشراء الافتراضي">
              <Input type="number" step="0.01" value={form.default_purchase_price} onChange={(e) => setForm({ ...form, default_purchase_price: e.target.value })} />
            </Field>
            <Field label="سعر البيع الافتراضي">
              <Input type="number" step="0.01" value={form.default_sale_price} onChange={(e) => setForm({ ...form, default_sale_price: e.target.value })} />
            </Field>
            <Field label="يصرف بوصفة طبية؟">
              <Select value={form.requires_prescription} onChange={(e) => setForm({ ...form, requires_prescription: Number(e.target.value) })}>
                <option value={0}>لا</option><option value={1}>نعم</option>
              </Select>
            </Field>
            <Field label="الحالة">
              <Select value={form.active} onChange={(e) => setForm({ ...form, active: Number(e.target.value) })}>
                <option value={1}>نشط</option><option value={0}>موقوف</option>
              </Select>
            </Field>
            <Field label="ظروف التخزين" className="sm:col-span-2">
              <Input value={form.storage_conditions || ''} onChange={(e) => setForm({ ...form, storage_conditions: e.target.value })} placeholder="يحفظ في درجة حرارة أقل من 30 مئوية" />
            </Field>
            <Field label="ملاحظات / إرشادات" className="sm:col-span-2 lg:col-span-3">
              <Textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
          </div>
        )}
      </Modal>

      {/* إضافة للمخزون */}
      <Modal
        open={!!addToStock} onClose={() => setAddToStock(null)} size="md"
        title={`إضافة «${addToStock?.drug?.trade_name || ''}» إلى المخزون`}
        subtitle="سيتم إنشاء صنف مخزني مرتبط بهذا الدواء مع إمكانية إدخال رصيد افتتاحي"
        footer={<><button className="btn-ghost" onClick={() => setAddToStock(null)}>إلغاء</button>
          <button className="btn-primary" onClick={confirmAddToStock}><PackagePlus className="h-4 w-4" /> إضافة للمخزون</button></>}
      >
        {addToStock && (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="سعر الشراء"><Input type="number" step="0.01" value={addToStock.purchase_price} onChange={(e) => setAddToStock({ ...addToStock, purchase_price: e.target.value })} /></Field>
            <Field label="سعر البيع"><Input type="number" step="0.01" value={addToStock.sale_price} onChange={(e) => setAddToStock({ ...addToStock, sale_price: e.target.value })} /></Field>
            <Field label="حد إعادة الطلب"><Input type="number" value={addToStock.reorder_level} onChange={(e) => setAddToStock({ ...addToStock, reorder_level: e.target.value })} /></Field>
            <Field label="موقع الرف"><Input value={addToStock.location} onChange={(e) => setAddToStock({ ...addToStock, location: e.target.value })} placeholder="رف A1" /></Field>
            <Field label="رصيد افتتاحي (اختياري)"><Input type="number" min="0" value={addToStock.opening_qty} onChange={(e) => setAddToStock({ ...addToStock, opening_qty: e.target.value })} /></Field>
            <Field label="تاريخ انتهاء الرصيد"><Input type="date" value={addToStock.opening_expiry} onChange={(e) => setAddToStock({ ...addToStock, opening_expiry: e.target.value })} /></Field>
          </div>
        )}
      </Modal>

      {importOpen && <ImportModal onClose={() => setImportOpen(false)} onDone={() => { setImportOpen(false); load(); loadMeta(); }} />}

      {inventoryImportOpen && (
        <InventoryImportModal
          onClose={() => setInventoryImportOpen(false)}
          onDone={() => { setInventoryImportOpen(false); load(); loadMeta(); }}
        />
      )}

      {bulkOpen && (
        <BulkAddToStockModal
          drugs={selectedDrugs}
          currency={currency}
          onClose={() => setBulkOpen(false)}
          onDone={() => { setBulkOpen(false); setSelected({}); load(); loadMeta(); }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={remove} danger
        title="حذف من الدليل" confirmLabel="حذف"
        message="سيتم حذف الدواء من الدليل المرجعي فقط، ولن يتأثر أي صنف موجود في المخزون."
      />
    </div>
  );
}

/* ================== استيراد الدليل من ملف المخزون ==================
 * يرفع المستخدم ملف Excel الذي صدّره من قسم «المخزون»، فيحوّله الخادم
 * إلى أدوية دليل بشكل صحيح (اسم الصنف ← الاسم التجاري، أسعار المخزون ←
 * الأسعار الافتراضية) ويتجاهل معرف الصنف والأرصدة والدفعات والموقع.
 */
function InventoryImportModal({ onClose, onDone }) {
  const toast = useToast();
  const inputRef = React.useRef(null);
  const [file, setFile] = useState(null);
  const [mode, setMode] = useState('upsert');
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);

  const pick = (f) => {
    if (!f) return;
    if (!/\.(xlsx|xls|csv)$/i.test(f.name)) { toast.error('الملف يجب أن يكون بصيغة Excel أو CSV'); return; }
    setFile(f); setPreview(null); setResult(null);
  };

  const send = async (dryRun) => {
    if (!file) { toast.error('اختر ملف المخزون أولاً'); return; }
    setBusy(true);
    try {
      const base64 = await fileToBase64(file);
      const res = await api.post('/catalog/import-from-inventory-file', {
        file: base64, filename: file.name, mode, dry_run: dryRun,
      });
      if (dryRun) setPreview(res);
      else { setResult(res); toast.success(`تم الاستيراد من المخزون: ${res.created} جديد و${res.updated} محدّث`); }
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  const summary = result || preview;

  return (
    <Modal
      open onClose={onClose} size="lg"
      title="استيراد دليل الأدوية من ملف المخزون"
      subtitle="ارفع ملف Excel الذي نزّلته من قسم «المخزون ← تصدير Excel» وسيتحول كل صنف فيه إلى دواء في الدليل"
      footer={(
        <>
          <button className="btn-ghost" onClick={onClose}>{result ? 'إغلاق' : 'إلغاء'}</button>
          {!result && (
            <>
              <button className="btn-outline" onClick={() => send(true)} disabled={!file || busy}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} فحص الملف
              </button>
              <button className="btn-primary" onClick={() => send(false)} disabled={!file || busy}>
                <Upload className="h-4 w-4" /> تنفيذ الاستيراد
              </button>
            </>
          )}
          {result && <button className="btn-primary" onClick={onDone}><CheckCircle2 className="h-4 w-4" /> تم</button>}
        </>
      )}
    >
      <div className="space-y-4">
        <div className="rounded-xl border border-sky-200 bg-sky-50 p-4 text-xs leading-7 text-sky-900">
          <p className="font-extrabold">كيف يعمل التحويل؟</p>
          <p>
            «اسم الصنف» ← الاسم التجاري · «المادة الفعالة» ← الاسم العلمي · الشكل والتركيز والوحدة والتصنيف والشركة والباركود تنتقل كما هي ·
            «سعر الشراء / سعر البيع» ← الأسعار الافتراضية للدواء في الدليل.
          </p>
          <p>
            <b>لا تنتقل</b> بيانات المخزون التشغيلية: معرف الصنف، الكمية المتوفرة، قيمة التكلفة، أقرب صلاحية،
            موقع التخزين، حد إعادة الطلب وبيانات البيع بالتجزئة — فالدليل مرجعي بلا أرصدة.
            والمطابقة عند التكرار تكون بالباركود ثم «الاسم + التركيز» فلا تتكرر الأدوية.
          </p>
        </div>

        <div
          role="button" tabIndex={0}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files?.[0]); }}
          className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed p-6 text-center transition ${
            drag ? 'border-brand-500 bg-brand-50' : 'border-ink-200 bg-ink-50/50 hover:border-brand-300'}`}
        >
          <FileSpreadsheet className={`h-8 w-8 ${file ? 'text-brand-600' : 'text-ink-300'}`} />
          {file ? (
            <>
              <p className="text-sm font-extrabold text-ink-800">{file.name}</p>
              <p className="text-[11px] text-ink-400">{(file.size / 1024).toFixed(1)} كيلوبايت — اضغط لاختيار ملف آخر</p>
            </>
          ) : (
            <>
              <p className="text-sm font-extrabold text-ink-700">اسحب ملف المخزون هنا أو اضغط للاختيار</p>
              <p className="text-[11px] text-ink-400">ملف «المخزون-….xlsx» المُصدَّر من قسم المخزون — أو CSV بنفس الأعمدة — بحد أقصى 5000 صنف</p>
            </>
          )}
          <input ref={inputRef} type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => pick(e.target.files?.[0])} />
        </div>

        {!result && (
          <Field label="عند وجود الدواء في الدليل مسبقاً" hint="المطابقة بالباركود، ثم الاسم التجاري + التركيز">
            <Select value={mode} onChange={(e) => { setMode(e.target.value); setPreview(null); }}>
              <option value="upsert">تحديث بيانات الدواء الموجود (موصى به)</option>
              <option value="insert">تجاهله وإضافة الجديد فقط</option>
            </Select>
          </Field>
        )}

        {summary && (
          <div className="space-y-3">
            <div className={`rounded-xl p-3 text-xs font-extrabold ${result ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
              {result
                ? <><CheckCircle2 className="ml-1 inline h-4 w-4" /> تم تنفيذ الاستيراد من المخزون بنجاح</>
                : <><AlertTriangle className="ml-1 inline h-4 w-4" /> نتيجة الفحص التجريبي — لم يُحفظ أي شيء بعد</>}
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <InvStat label="إجمالي الأصناف" value={summary.total} cls="bg-ink-50 text-ink-600" />
              <InvStat label="دواء جديد" value={summary.created} cls="bg-emerald-50 text-emerald-700" />
              <InvStat label="سيتم تحديثه" value={summary.updated} cls="bg-sky-50 text-sky-700" />
              <InvStat label="متجاهل" value={summary.skipped} cls="bg-amber-50 text-amber-700" />
            </div>
            {summary.ignored_columns?.length > 0 && (
              <p className="rounded-lg bg-ink-50 px-3 py-2 text-[11px] font-bold leading-6 text-ink-500">
                أعمدة مخزون تم تجاهلها عمداً لأنها لا تخص الدليل المرجعي: {summary.ignored_columns.join('، ')}
              </p>
            )}
            {summary.errors?.length > 0 && (
              <div className="max-h-48 overflow-auto rounded-xl border border-rose-200">
                <div className="bg-rose-50 px-3 py-2 text-xs font-extrabold text-rose-700">{summary.errors.length} صف به مشكلة</div>
                <table className="w-full text-[11px]">
                  <tbody>
                    {summary.errors.slice(0, 100).map((e, i) => (
                      <tr key={`${e.row}-${i}`} className="border-t border-ink-100">
                        <td className="num p-2 font-bold">{e.row}</td>
                        <td className="p-2">{e.name}</td>
                        <td className="p-2 text-rose-600">{e.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}

const InvStat = ({ label, value, cls }) => (
  <div className={`rounded-xl p-2.5 text-center ${cls}`}>
    <p className="num text-lg font-black">{value ?? 0}</p>
    <p className="text-[10px] font-bold opacity-80">{label}</p>
  </div>
);

/* ================== الإضافة الجماعية للمخزون ==================
 * بعد إنهاء اختيار الأدوية تظهر هذه النافذة بجدول مبسّط:
 * الدواء (الاسم + المادة + التركيز في عمود واحد) وأمامه خانات
 * سعر الشراء وسعر البيع والكمية الحالية وحد إعادة الطلب وتاريخ الانتهاء.
 */
function BulkAddToStockModal({ drugs, currency, onClose, onDone }) {
  const toast = useToast();
  const [rows, setRows] = useState(() => drugs.map((d) => ({
    catalog_id: d.id,
    drug: d,
    purchase_price: d.default_purchase_price ?? 0,
    sale_price: d.default_sale_price ?? 0,
    opening_qty: 0,
    reorder_level: 10,
    opening_expiry: '',
  })));
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [sharedExpiry, setSharedExpiry] = useState('');

  const setRow = (id, patch) => setRows((prev) => prev.map((r) => (r.catalog_id === id ? { ...r, ...patch } : r)));
  const removeRow = (id) => setRows((prev) => prev.filter((r) => r.catalog_id !== id));

  const submit = async () => {
    if (!rows.length) { toast.error('لم يتبق أي دواء في القائمة'); return; }
    setBusy(true);
    try {
      const res = await api.post('/products/from-catalog/bulk', {
        items: rows.map((r) => ({
          catalog_id: r.catalog_id,
          purchase_price: Number(r.purchase_price) || 0,
          sale_price: Number(r.sale_price) || 0,
          opening_qty: Number(r.opening_qty) || 0,
          reorder_level: Number(r.reorder_level) || 0,
          opening_expiry: r.opening_expiry || null,
        })),
      });
      setResult(res);
      if (res.created_count) toast.success(`تمت إضافة ${res.created_count} دواء إلى المخزون`);
      if (res.skipped_count) toast.error(`تم تخطي ${res.skipped_count} دواء — راجع الأسباب`);
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  return (
    <Modal
      open onClose={onClose} size="xl"
      title={`إضافة ${rows.length} دواء إلى المخزون`}
      subtitle="راجع الأسعار والكمية الحالية لكل دواء ثم أكّد — تُنشأ الأصناف ودفعات أرصدتها الافتتاحية دفعة واحدة"
      footer={(
        <>
          <button className="btn-ghost" onClick={onClose}>{result ? 'إغلاق' : 'إلغاء'}</button>
          {!result && (
            <button className="btn-primary" onClick={submit} disabled={busy || !rows.length}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <PackagePlus className="h-4 w-4" />}
              إضافة {rows.length} دواء للمخزون
            </button>
          )}
          {result && <button className="btn-primary" onClick={onDone}><CheckCircle2 className="h-4 w-4" /> تم</button>}
        </>
      )}
    >
      {result ? (
        <div className="space-y-3">
          <div className="rounded-xl bg-emerald-50 p-3 text-sm font-extrabold text-emerald-700">
            <CheckCircle2 className="ml-1 inline h-4 w-4" />
            أُضيف {result.created_count} دواء إلى المخزون
            {result.opening_units > 0 && <> — وسُجل رصيد افتتاحي بمقدار {result.opening_units} وحدة</>}
          </div>
          {result.skipped?.length > 0 && (
            <div className="rounded-xl border border-amber-200">
              <div className="bg-amber-50 px-3 py-2 text-xs font-extrabold text-amber-700">أدوية تم تخطيها ({result.skipped.length})</div>
              <table className="w-full text-xs">
                <tbody>
                  {result.skipped.map((s) => (
                    <tr key={s.catalog_id} className="border-t border-ink-100">
                      <td className="p-2 font-bold">{s.name}</td>
                      <td className="p-2 text-amber-700">{s.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap items-end gap-2 rounded-xl bg-ink-50 p-3">
            <Field label="تاريخ انتهاء موحّد (اختياري)" className="min-w-[200px]">
              <Input type="date" value={sharedExpiry} onChange={(e) => setSharedExpiry(e.target.value)} />
            </Field>
            <button
              className="btn-outline btn-sm"
              disabled={!sharedExpiry}
              onClick={() => { setRows((prev) => prev.map((r) => ({ ...r, opening_expiry: sharedExpiry }))); toast.success('تم تطبيق التاريخ على كل الأدوية'); }}
            >
              تطبيق على الكل
            </button>
            <p className="w-full text-[11px] font-bold text-ink-400">
              «الكمية الحالية» هي الرصيد الافتتاحي الذي سيُسجل في المخزون لكل دواء (اتركها صفراً إن أردت إنشاء الصنف دون رصيد وستدخله لاحقاً بفاتورة شراء).
            </p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-ink-100">
            <table className="tbl min-w-[860px]">
              <thead>
                <tr>
                  <th>الدواء</th>
                  <th>سعر الشراء ({currency})</th>
                  <th>سعر البيع ({currency})</th>
                  <th>الكمية الحالية في المخزون</th>
                  <th>حد إعادة الطلب</th>
                  <th>تاريخ الانتهاء</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.catalog_id}>
                    <td className="min-w-[220px] whitespace-normal">
                      <p className="font-extrabold leading-6 text-ink-900">
                        {r.drug.trade_name}
                        {r.drug.generic_name ? <span className="font-bold text-ink-500"> — {r.drug.generic_name}</span> : null}
                        {r.drug.strength ? <span className="font-bold text-brand-700"> · {r.drug.strength}</span> : null}
                      </p>
                      <p className="text-[11px] text-ink-400">
                        {[r.drug.form, r.drug.unit, r.drug.manufacturer].filter(Boolean).join(' · ') || '—'}
                      </p>
                    </td>
                    <td><Input type="number" min="0" step="0.01" className="num w-28 py-1.5 text-center" value={r.purchase_price} onChange={(e) => setRow(r.catalog_id, { purchase_price: e.target.value })} /></td>
                    <td><Input type="number" min="0" step="0.01" className="num w-28 py-1.5 text-center" value={r.sale_price} onChange={(e) => setRow(r.catalog_id, { sale_price: e.target.value })} /></td>
                    <td><Input type="number" min="0" step="1" className="num w-28 py-1.5 text-center" value={r.opening_qty} onChange={(e) => setRow(r.catalog_id, { opening_qty: e.target.value })} /></td>
                    <td><Input type="number" min="0" step="1" className="num w-24 py-1.5 text-center" value={r.reorder_level} onChange={(e) => setRow(r.catalog_id, { reorder_level: e.target.value })} /></td>
                    <td><Input type="date" className="w-40 py-1.5" value={r.opening_expiry} onChange={(e) => setRow(r.catalog_id, { opening_expiry: e.target.value })} /></td>
                    <td>
                      <button className="rounded-lg p-1.5 text-rose-500 hover:bg-rose-50" title="إزالة من القائمة" onClick={() => removeRow(r.catalog_id)}>
                        <X className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr><td colSpan={7}><EmptyState title="أزلت كل الأدوية" hint="أغلق النافذة واختر أدوية أخرى من الدليل" icon={BookOpen} /></td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ================== استيراد الدليل ================== */
function ImportModal({ onClose, onDone }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);

  const sample = `الاسم التجاري, المادة الفعالة, الشكل, التركيز, التصنيف, الشركة, سعر الشراء, سعر البيع
سيتال, باراسيتامول, أقراص, 500 مجم, مسكنات, EIPICO, 5, 9`;

  const run = async () => {
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
    if (!lines.length) { toast.error('أدخل البيانات أولاً'); return; }
    const rows = lines.slice(lines[0].includes('الاسم التجاري') ? 1 : 0).map((line) => {
      const [trade_name, generic_name, form, strength, category, manufacturer, buy, sell] = line.split(/[,\t;]/).map((s) => (s || '').trim());
      return {
        trade_name, generic_name, form, strength, category, manufacturer,
        default_purchase_price: Number(buy) || 0, default_sale_price: Number(sell) || 0,
      };
    }).filter((r) => r.trade_name);

    if (!rows.length) { toast.error('تعذر قراءة أي سطر صالح'); return; }
    setBusy(true);
    try {
      const res = await api.post('/catalog/import', { items: rows });
      toast.success(`تم استيراد ${res.inserted} دواء (تم تجاهل ${res.skipped} مكرر)`);
      onDone();
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  return (
    <Modal
      open onClose={onClose} size="md" title="استيراد أدوية إلى الدليل"
      subtitle="الصق البيانات بصيغة CSV — كل سطر يمثل دواءً"
      footer={<><button className="btn-ghost" onClick={onClose}>إلغاء</button>
        <button className="btn-primary" onClick={run} disabled={busy}><Upload className="h-4 w-4" /> استيراد</button></>}
    >
      <div className="space-y-3">
        <div className="rounded-xl bg-ink-50 p-3 text-xs leading-6 text-ink-600">
          <p className="font-extrabold">ترتيب الأعمدة:</p>
          <code className="block whitespace-pre-wrap text-[11px]">{sample}</code>
        </div>
        <Textarea className="min-h-[220px] font-mono text-xs" value={text} onChange={(e) => setText(e.target.value)} placeholder="الصق الأسطر هنا..." />
      </div>
    </Modal>
  );
}

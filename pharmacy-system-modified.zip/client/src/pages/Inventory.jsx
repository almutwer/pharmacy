import React, { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Boxes, Plus, Search, Eye, Pencil, Trash2, SlidersHorizontal, CalendarClock, Activity,
  AlertTriangle, PackageX, TrendingUp, Layers, Trash, BookOpen, Hourglass, Save,
  Percent, History, RotateCcw, CheckSquare, Loader2, CheckCircle2,
} from 'lucide-react';
import api from '../api.js';
import { useApp } from '../context/AppContext.jsx';
import {
  PageHeader, Card, Table, Pagination, Badge, Field, Input, Select, Textarea, Modal, useToast,
  StatCard, ConfirmDialog, Tabs, Loading, EmptyState,
} from '../components/ui.jsx';
import ExcelIO from '../components/ExcelIO.jsx';
import {
  fmtNum, fmtDate, fmtDateTime, expiryState, stockState, MOVEMENT_TYPES, DOSAGE_FORMS, UNITS,
  SUB_UNITS, canSellSub, subUnitPrice, fmtStock, cn,
} from '../lib/format.js';

const emptyProduct = () => ({
  name: '', generic_name: '', form: '', strength: '', unit: 'علبة', category: '', manufacturer: '',
  sub_unit: '', units_per_pack: 1, sub_unit_price: 0, allow_sub_unit: 0,
  barcode: '', purchase_price: 0, sale_price: 0, reorder_level: 10, location: '',
  requires_prescription: 0, notes: '', active: 1, opening_qty: 0, opening_expiry: '',
});

export default function Inventory() {
  const { currency, can, settings, reloadSettings } = useApp();
  const toast = useToast();
  const [params, setParams] = useSearchParams();

  const [tab, setTab] = useState(params.get('tab') || 'items');
  const [summary, setSummary] = useState(null);
  const [filters, setFilters] = useState({ q: '', category: '', status: params.get('status') || '' });
  const [page, setPage] = useState(1);
  const [res, setRes] = useState({ data: [], total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [meta, setMeta] = useState({ categories: [] });
  const [form, setForm] = useState(null);
  const [detail, setDetail] = useState(null);
  const [adjust, setAdjust] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [disposeOpen, setDisposeOpen] = useState(false);
  // تحديث الأسعار الجماعي: تحديد أصناف + نافذة التحديث
  const [selectedPrices, setSelectedPrices] = useState({});
  const [priceModal, setPriceModal] = useState(null); // { scopeType }
  const selectedPriceIds = Object.keys(selectedPrices).map(Number);

  const loadSummary = useCallback(() => api.get('/inventory/summary').then(setSummary), []);

  const load = useCallback(async () => {
    setLoading(true);
    try { setRes(await api.get('/products', { ...filters, page, limit: 20 })); } finally { setLoading(false); }
  }, [filters, page]);

  useEffect(() => { loadSummary(); api.get('/products/meta').then(setMeta); }, [loadSummary]);
  useEffect(() => { if (tab === 'items') load(); }, [load, tab]);
  useEffect(() => { setParams(tab === 'items' ? {} : { tab }, { replace: true }); }, [tab, setParams]);

  const saveProduct = async () => {
    try {
      if (form.id) {
        await api.put(`/products/${form.id}`, form);
        toast.success('تم تحديث الصنف');
      } else {
        await api.post('/products', form);
        toast.success('تمت إضافة الصنف للمخزون');
      }
      setForm(null); load(); loadSummary();
    } catch (err) { toast.error(err.message); }
  };

  const submitAdjust = async () => {
    try {
      await api.post('/inventory/adjust', adjust);
      toast.success('تم تنفيذ التسوية المخزنية');
      setAdjust(null); load(); loadSummary();
      if (detail) setDetail(await api.get(`/products/${detail.data.id}`));
    } catch (err) { toast.error(err.message); }
  };

  const removeProduct = async () => {
    try {
      const r = await api.del(`/products/${deleteId}`);
      toast.success(r.message || 'تم حذف الصنف');
      setDeleteId(null); load(); loadSummary();
    } catch (err) { toast.error(err.message); setDeleteId(null); }
  };

  const disposeExpired = async () => {
    try {
      const r = await api.post('/inventory/dispose-expired');
      toast.success(`تم إتلاف ${r.count} دفعة بقيمة ${fmtNum(r.value)} ${currency}`);
      setDisposeOpen(false); loadSummary();
    } catch (err) { toast.error(err.message); setDisposeOpen(false); }
  };

  return (
    <div>
      <PageHeader
        title="إدارة المخزون" subtitle="الأصناف والدفعات وتواريخ الصلاحية وحركات المخزون" icon={Boxes}
        actions={(
          <>
            <ExcelIO entity="products" filters={filters} canImport={can('pharmacist')} onDone={load} />
            {can('pharmacist') && (
              <>
                <button
                  className="btn-outline border-brand-300 text-brand-700"
                  onClick={() => setPriceModal({ scopeType: selectedPriceIds.length ? 'selected' : 'all' })}
                  title="تحديث أسعار البيع والشراء دفعة واحدة بالنسبة أو المبلغ أو هامش الربح"
                >
                  <Percent className="h-4 w-4" /> تحديث الأسعار
                </button>
                <button className="btn-outline" onClick={() => setAdjust({ product_id: '', type: 'adjust_in', qty: 1, note: '' })}>
                  <SlidersHorizontal className="h-4 w-4" /> تسوية مخزنية
                </button>
                <button className="btn-primary" onClick={() => setForm(emptyProduct())}><Plus className="h-4 w-4" /> صنف جديد</button>
              </>
            )}
          </>
        )}
      />

      {summary && (
        <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="قيمة المخزون (تكلفة)" value={`${fmtNum(summary.cost_value)} ${currency}`} sub={`${summary.products} صنف · ${fmtNum(summary.units, 0)} وحدة`} icon={Boxes} tone="brand" />
          <StatCard label="قيمة البيع المتوقعة" value={`${fmtNum(summary.sale_value)} ${currency}`} sub={`ربح متوقع ${fmtNum(summary.expected_profit)}`} icon={TrendingUp} tone="blue" />
          <StatCard label="أصناف منخفضة / نفدت" value={`${summary.low_stock} / ${summary.out_of_stock}`} sub="تحتاج إعادة طلب" icon={AlertTriangle} tone="amber" />
          <StatCard label="قاربت الانتهاء / منتهية" value={`${summary.expiring_soon} / ${summary.expired}`} sub={`قيمة المنتهي ${fmtNum(summary.expired_value)} ${currency}`} icon={CalendarClock} tone="rose" />
        </div>
      )}

      <Tabs
        value={tab} onChange={setTab}
        tabs={[
          { value: 'items', label: 'الأصناف', icon: Boxes },
          { value: 'expiry', label: 'الصلاحيات', icon: CalendarClock },
          { value: 'low', label: 'نواقص المخزون', icon: PackageX },
          { value: 'slow', label: 'الأدوية الراكدة', icon: Hourglass },
          { value: 'movements', label: 'حركات المخزون', icon: Activity },
        ]}
      />

      {tab === 'items' && (
        <>
          <Card className="mb-4 p-4">
            <div className="flex flex-wrap items-end gap-3">
              <Field label="بحث" className="min-w-[220px] flex-1">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                  <Input className="pr-9" placeholder="اسم الدواء / المادة الفعالة / الباركود" value={filters.q}
                    onChange={(e) => { setFilters({ ...filters, q: e.target.value }); setPage(1); }} />
                </div>
              </Field>
              <Field label="التصنيف">
                <Select value={filters.category} onChange={(e) => { setFilters({ ...filters, category: e.target.value }); setPage(1); }}>
                  <option value="">كل التصنيفات</option>
                  {meta.categories?.map((c) => <option key={c} value={c}>{c}</option>)}
                </Select>
              </Field>
              <Field label="الحالة">
                <Select value={filters.status} onChange={(e) => { setFilters({ ...filters, status: e.target.value }); setPage(1); }}>
                  <option value="">الكل</option>
                  <option value="low">منخفض</option>
                  <option value="out">نفد</option>
                  <option value="expiring">قارب الانتهاء</option>
                  <option value="expired">منتهي الصلاحية</option>
                </Select>
              </Field>
            </div>
          </Card>

          {can('pharmacist') && (
            <div className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-brand-200 bg-brand-50/70 px-4 py-3">
              <span className="flex items-center gap-2 text-sm font-extrabold text-brand-900">
                <CheckSquare className="h-4 w-4" />
                {selectedPriceIds.length ? `تم اختيار ${selectedPriceIds.length} صنف لتحديث الأسعار` : 'لتغيير سريع للأسعار: حدّد أصنافاً من عمود الاختيار أو افتح «تحديث الأسعار» لكل الأصناف/تصنيف/بحث'}
              </span>
              <div className="mr-auto flex flex-wrap gap-2">
                <button
                  className="btn-outline btn-sm"
                  onClick={() => setSelectedPrices((prev) => {
                    const next = { ...prev };
                    res.data.forEach((p) => { next[p.id] = true; });
                    return next;
                  })}
                >
                  تحديد هذه الصفحة
                </button>
                {selectedPriceIds.length > 0 && (
                  <>
                    <button className="btn-ghost btn-sm" onClick={() => setSelectedPrices({})}>إلغاء التحديد</button>
                    <button className="btn-primary btn-sm" onClick={() => setPriceModal({ scopeType: 'selected' })}>
                      <Percent className="h-4 w-4" /> تحديث أسعار المحدد ({selectedPriceIds.length})
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          <Table
            loading={loading}
            columns={['اختيار', 'الصنف', 'التصنيف', 'الشكل', 'الرصيد', 'الحالة', 'أقرب صلاحية', 'سعر الشراء', 'سعر البيع', 'الموقع', '']}
            rows={res.data}
            renderRow={(p) => {
              const st = stockState(p.stock_qty, p.reorder_level);
              const exp = expiryState(p.nearest_expiry);
              return (
                <tr key={p.id} className={selectedPrices[p.id] ? 'bg-brand-50/70' : ''}>
                  <td>
                    <input
                      type="checkbox"
                      className="h-4 w-4 accent-emerald-600 disabled:opacity-30"
                      checked={!!selectedPrices[p.id]}
                      disabled={!can('pharmacist')}
                      onChange={() => setSelectedPrices((prev) => {
                        const next = { ...prev };
                        if (next[p.id]) delete next[p.id]; else next[p.id] = true;
                        return next;
                      })}
                      title="اختيار لتحديث السعر جماعياً"
                    />
                  </td>
                  <td>
                    <p className="font-extrabold text-ink-900">{p.name} <span className="text-xs text-ink-400">{p.strength || ''}</span></p>
                    <p className="text-[11px] text-ink-400">{p.generic_name || '—'} {p.catalog_id ? '· مرتبط بالدليل' : ''}</p>
                  </td>
                  <td className="text-ink-500">{p.category || '—'}</td>
                  <td className="text-ink-500">{p.form || '—'}</td>
                  <td className="num font-extrabold">
                    {fmtStock(p.stock_qty, p)}
                    {canSellSub(p) && (
                      <span className="block text-[10px] font-normal text-brand-600">
                        تجزئة: {fmtNum(subUnitPrice(p))} / {p.sub_unit}
                      </span>
                    )}
                  </td>
                  <td><Badge className={st.cls}>{st.label}</Badge></td>
                  <td>{p.nearest_expiry ? <Badge className={exp.cls}>{fmtDate(p.nearest_expiry)}</Badge> : <span className="text-ink-300">—</span>}</td>
                  <td className="num">{fmtNum(p.purchase_price)}</td>
                  <td className="num font-bold text-brand-700">{fmtNum(p.sale_price)}</td>
                  <td className="text-xs text-ink-400">{p.location || '—'}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="btn-outline btn-sm" onClick={async () => setDetail(await api.get(`/products/${p.id}`))}><Eye className="h-3.5 w-3.5" /></button>
                      {can('pharmacist') && <button className="btn-outline btn-sm" onClick={() => setForm({ ...p })}><Pencil className="h-3.5 w-3.5" /></button>}
                      {can('manager') && <button className="btn-outline btn-sm text-rose-600" onClick={() => setDeleteId(p.id)}><Trash2 className="h-3.5 w-3.5" /></button>}
                    </div>
                  </td>
                </tr>
              );
            }}
          />
          <Pagination page={page} pages={res.pages} total={res.total} onChange={setPage} />
        </>
      )}

      {tab === 'expiry' && <ExpiryTab currency={currency} canManage={can('manager')} onDispose={() => setDisposeOpen(true)} />}
      {tab === 'low' && <LowStockTab currency={currency} />}
      {tab === 'slow' && (
        <SlowMovingTab
          currency={currency}
          settings={settings}
          canManage={can('manager')}
          onSettingsSaved={reloadSettings}
        />
      )}
      {tab === 'movements' && <MovementsTab currency={currency} />}

      {/* نموذج الصنف */}
      <Modal
        open={!!form} onClose={() => setForm(null)} size="lg"
        title={form?.id ? `تعديل الصنف: ${form.name}` : 'إضافة صنف جديد للمخزون'}
        subtitle="يمكنك أيضاً إضافة الأصناف مباشرة من دليل الأدوية أو عبر فاتورة شراء"
        footer={<><button className="btn-ghost" onClick={() => setForm(null)}>إلغاء</button>
          <button className="btn-primary" onClick={saveProduct}>حفظ</button></>}
      >
        {form && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="اسم الصنف" required className="sm:col-span-2">
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="المادة الفعالة">
              <Input value={form.generic_name || ''} onChange={(e) => setForm({ ...form, generic_name: e.target.value })} />
            </Field>
            <Field label="الشكل الصيدلاني">
              <Select value={form.form || ''} onChange={(e) => setForm({ ...form, form: e.target.value })}>
                <option value="">—</option>
                {DOSAGE_FORMS.map((f) => <option key={f} value={f}>{f}</option>)}
              </Select>
            </Field>
            <Field label="التركيز"><Input value={form.strength || ''} onChange={(e) => setForm({ ...form, strength: e.target.value })} /></Field>
            <Field label="وحدة الصرف">
              <Select value={form.unit || ''} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
                {UNITS.map((u) => <option key={u} value={u}>{u}</option>)}
              </Select>
            </Field>
            <Field label="التصنيف"><Input value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
            <Field label="الشركة المصنعة"><Input value={form.manufacturer || ''} onChange={(e) => setForm({ ...form, manufacturer: e.target.value })} /></Field>
            <Field label="الباركود"><Input value={form.barcode || ''} onChange={(e) => setForm({ ...form, barcode: e.target.value })} /></Field>
            <Field label="سعر الشراء"><Input type="number" step="0.01" value={form.purchase_price} onChange={(e) => setForm({ ...form, purchase_price: e.target.value })} /></Field>
            <Field label="سعر البيع"><Input type="number" step="0.01" value={form.sale_price} onChange={(e) => setForm({ ...form, sale_price: e.target.value })} /></Field>
            <Field label="حد إعادة الطلب"><Input type="number" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: e.target.value })} /></Field>
            <Field label="موقع الرف"><Input value={form.location || ''} onChange={(e) => setForm({ ...form, location: e.target.value })} /></Field>
            <Field label="البيع بالتجزئة" className="sm:col-span-2" hint="لبيع جزء من العبوة (شريط من علبة، قرص من شريط…)">
              <Select
                value={form.allow_sub_unit || 0}
                onChange={(e) => setForm({ ...form, allow_sub_unit: Number(e.target.value), sub_unit: form.sub_unit || 'شريط' })}
              >
                <option value={0}>غير مفعّل — البيع بالعبوة الكاملة فقط</option>
                <option value={1}>مفعّل — يمكن بيع وحدة أصغر من العبوة</option>
              </Select>
            </Field>

            {Number(form.allow_sub_unit) === 1 && (
              <>
                <Field label="اسم الوحدة الصغرى" required>
                  <Select value={form.sub_unit || ''} onChange={(e) => setForm({ ...form, sub_unit: e.target.value })}>
                    <option value="">—</option>
                    {SUB_UNITS.map((u) => <option key={u} value={u}>{u}</option>)}
                  </Select>
                </Field>
                <Field label={`عدد الـ${form.sub_unit || 'وحدات'} في ${form.unit || 'العبوة'}`} required>
                  <Input
                    type="number" min="1" step="1" value={form.units_per_pack}
                    onChange={(e) => setForm({ ...form, units_per_pack: Number(e.target.value) || 1 })}
                  />
                </Field>
                <Field
                  label={`سعر بيع الـ${form.sub_unit || 'وحدة'}`}
                  className="sm:col-span-2"
                  hint={`اتركه صفراً ليُحسب تلقائياً = ${fmtNum(
                    (Number(form.sale_price) || 0) / (Number(form.units_per_pack) || 1),
                  )} ${currency}. عادة يكون سعر التجزئة أعلى.`}
                >
                  <Input
                    type="number" step="0.01" value={form.sub_unit_price}
                    onChange={(e) => setForm({ ...form, sub_unit_price: Number(e.target.value) || 0 })}
                  />
                </Field>
              </>
            )}

            <Field label="يصرف بوصفة؟">
              <Select value={form.requires_prescription} onChange={(e) => setForm({ ...form, requires_prescription: Number(e.target.value) })}>
                <option value={0}>لا</option><option value={1}>نعم</option>
              </Select>
            </Field>
            <Field label="الحالة">
              <Select value={form.active} onChange={(e) => setForm({ ...form, active: Number(e.target.value) })}>
                <option value={1}>نشط</option><option value={0}>موقوف</option>
              </Select>
            </Field>
            {!form.id && (
              <>
                <Field label="رصيد افتتاحي (اختياري)">
                  <Input type="number" min="0" value={form.opening_qty} onChange={(e) => setForm({ ...form, opening_qty: e.target.value })} />
                </Field>
                <Field label="صلاحية الرصيد الافتتاحي">
                  <Input type="date" value={form.opening_expiry} onChange={(e) => setForm({ ...form, opening_expiry: e.target.value })} />
                </Field>
              </>
            )}
            <Field label="ملاحظات" className="sm:col-span-2 lg:col-span-3">
              <Textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </Field>
          </div>
        )}
      </Modal>

      {/* بطاقة الصنف */}
      <Modal
        open={!!detail} onClose={() => setDetail(null)} size="lg"
        title={detail ? detail.data.name : ''} subtitle={detail ? `${detail.data.generic_name || ''} · ${detail.data.form || ''} ${detail.data.strength || ''}` : ''}
        footer={<button className="btn-ghost" onClick={() => setDetail(null)}>إغلاق</button>}
      >
        {!detail ? <Loading /> : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Info label="الرصيد" value={fmtStock(detail.data.stock_qty, detail.data)} />
              {canSellSub(detail.data) && (
                <Info
                  label="البيع بالتجزئة"
                  value={`${fmtNum(subUnitPrice(detail.data))} ${currency} / ${detail.data.sub_unit} — العبوة ${fmtNum(detail.data.units_per_pack, 0)} ${detail.data.sub_unit}`}
                />
              )}
              <Info label="قيمة المخزون" value={`${fmtNum(detail.data.stock_cost_value)} ${currency}`} />
              <Info label="سعر البيع" value={`${fmtNum(detail.data.sale_price)} ${currency}`} />
              <Info label="الموقع" value={detail.data.location || '—'} />
            </div>

            <div>
              <p className="mb-2 flex items-center gap-2 font-extrabold text-ink-800"><Layers className="h-4 w-4 text-brand-600" /> الدفعات</p>
              <div className="table-wrap">
                <table className="tbl">
                  <thead><tr><th>رقم الدفعة</th><th>الصلاحية</th><th>الوارد</th><th>المتاح</th><th>التكلفة</th><th>المورد</th></tr></thead>
                  <tbody>
                    {detail.batches.length === 0 && <tr><td colSpan={6}><EmptyState title="لا توجد دفعات" /></td></tr>}
                    {detail.batches.map((b) => {
                      const exp = expiryState(b.expiry_date);
                      return (
                        <tr key={b.id} className={cn(b.qty_available <= 0 && 'opacity-50')}>
                          <td className="font-bold">{b.batch_no || '—'}</td>
                          <td><Badge className={exp.cls}>{b.expiry_date ? fmtDate(b.expiry_date) : 'غير محدد'}</Badge></td>
                          <td className="num">{fmtNum(b.qty_in, 0)}</td>
                          <td className="num font-extrabold">{fmtNum(b.qty_available, 0)}</td>
                          <td className="num">{fmtNum(b.cost_price)}</td>
                          <td className="text-xs text-ink-400">{b.supplier_name || '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <p className="mb-2 flex items-center gap-2 font-extrabold text-ink-800"><Activity className="h-4 w-4 text-brand-600" /> آخر الحركات</p>
              <div className="max-h-64 overflow-y-auto">
                <div className="table-wrap">
                  <table className="tbl">
                    <thead><tr><th>التاريخ</th><th>الحركة</th><th>الكمية</th><th>الدفعة</th><th>المستخدم</th><th>ملاحظة</th></tr></thead>
                    <tbody>
                      {detail.movements.map((m) => (
                        <tr key={m.id}>
                          <td className="text-xs text-ink-500">{fmtDateTime(m.created_at)}</td>
                          <td><Badge tone={m.qty > 0 ? 'green' : 'red'}>{MOVEMENT_TYPES[m.type] || m.type}</Badge></td>
                          <td className={cn('num font-bold', m.qty > 0 ? 'text-emerald-600' : 'text-rose-600')}>{m.qty > 0 ? '+' : ''}{fmtNum(m.qty, 0)}</td>
                          <td className="text-xs">{m.batch_no || '—'}</td>
                          <td className="text-xs text-ink-400">{m.user_name || '—'}</td>
                          <td className="text-xs text-ink-400">{m.note || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* تسوية */}
      <AdjustModal adjust={adjust} setAdjust={setAdjust} onSubmit={submitAdjust} />

      {/* تحديث الأسعار الجماعي */}
      {priceModal && (
        <PriceUpdateModal
          initialScopeType={priceModal.scopeType}
          selectedIds={selectedPriceIds}
          categories={meta.categories || []}
          currency={currency}
          canRevert={can('manager')}
          onClose={() => setPriceModal(null)}
          onApplied={() => { load(); loadSummary(); setSelectedPrices({}); }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={removeProduct} danger
        title="حذف الصنف" confirmLabel="حذف"
        message="سيتم حذف الصنف نهائياً إن لم يكن مرتبطاً بحركات، وإلا سيتم إيقافه فقط."
      />
      <ConfirmDialog
        open={disposeOpen} onClose={() => setDisposeOpen(false)} onConfirm={disposeExpired} danger
        title="إتلاف الدفعات المنتهية" confirmLabel="تنفيذ الإتلاف"
        message="سيتم تصفير جميع الدفعات منتهية الصلاحية وتسجيلها كخسائر إتلاف في التقارير."
      />
    </div>
  );
}

/* ================== تبويب الصلاحيات ================== */
function ExpiryTab({ currency, canManage, onDispose }) {
  const [mode, setMode] = useState('soon');
  const [days, setDays] = useState(90);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get('/inventory/expiry', { mode, days }).then((r) => setRows(r.data)).finally(() => setLoading(false));
  }, [mode, days]);

  return (
    <>
      <Card className="mb-4 flex flex-wrap items-end justify-between gap-3 p-4">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="العرض">
            <Select value={mode} onChange={(e) => setMode(e.target.value)}>
              <option value="soon">قاربت الانتهاء</option>
              <option value="expired">منتهية الصلاحية</option>
              <option value="all">الكل</option>
            </Select>
          </Field>
          {mode !== 'expired' && (
            <Field label="خلال (يوم)"><Input type="number" className="w-28" value={days} onChange={(e) => setDays(e.target.value)} /></Field>
          )}
        </div>
        {canManage && <button className="btn-danger" onClick={onDispose}><Trash className="h-4 w-4" /> إتلاف المنتهي</button>}
      </Card>

      <Table
        loading={loading}
        columns={['الصنف', 'التصنيف', 'رقم الدفعة', 'تاريخ الانتهاء', 'المتبقي', 'الكمية', 'التكلفة', 'القيمة']}
        rows={rows}
        empty={<EmptyState title="لا توجد دفعات في هذا النطاق" icon={CalendarClock} />}
        renderRow={(b) => {
          const exp = expiryState(b.expiry_date);
          return (
            <tr key={b.id}>
              <td className="font-bold">{b.product_name}</td>
              <td className="text-ink-500">{b.category || '—'}</td>
              <td>{b.batch_no || '—'}</td>
              <td><Badge className={exp.cls}>{fmtDate(b.expiry_date)}</Badge></td>
              <td className={cn('num font-bold', b.days_left < 0 ? 'text-rose-600' : 'text-amber-600')}>
                {b.days_left < 0 ? `منتهٍ منذ ${Math.abs(b.days_left)} يوم` : `${b.days_left} يوم`}
              </td>
              <td className="num font-extrabold">{fmtNum(b.qty_available, 0)} {b.unit}</td>
              <td className="num">{fmtNum(b.cost_price)}</td>
              <td className="num font-bold text-rose-600">{fmtNum(b.value)} {currency}</td>
            </tr>
          );
        }}
      />
    </>
  );
}

/* ================== تبويب النواقص ================== */
function LowStockTab({ currency }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get('/inventory/low-stock').then((r) => setRows(r.data)).finally(() => setLoading(false)); }, []);

  return (
    <Table
      loading={loading}
      columns={['الصنف', 'التصنيف', 'الرصيد الحالي', 'حد إعادة الطلب', 'الكمية المقترحة', 'سعر الشراء', 'تكلفة التوريد المقترحة']}
      rows={rows}
      empty={<EmptyState title="لا توجد نواقص — المخزون بحالة جيدة" icon={PackageX} />}
      renderRow={(p) => {
        const suggest = Math.max(0, (p.reorder_level > 0 ? p.reorder_level : 10) * 3 - p.stock_qty);
        return (
          <tr key={p.id}>
            <td className="font-bold">{p.name}</td>
            <td className="text-ink-500">{p.category || '—'}</td>
            <td className="num"><Badge tone={p.stock_qty <= 0 ? 'red' : 'amber'}>{fmtNum(p.stock_qty, 0)} {p.unit}</Badge></td>
            <td className="num">{fmtNum(p.reorder_level, 0)}</td>
            <td className="num font-extrabold text-brand-700">{fmtNum(suggest, 0)}</td>
            <td className="num">{fmtNum(p.purchase_price)}</td>
            <td className="num font-bold">{fmtNum(suggest * p.purchase_price)} {currency}</td>
          </tr>
        );
      }}
    />
  );
}

/* ================== تبويب الأدوية الراكدة ==================
 * أدوية متوفرة في المخزون لكن مبيعاتها ضعيفة:
 * لم يُبَع منها أكثر من (حد المبيعات) خلال (فترة الركود) السابقة.
 * الحد والفترة قابلان للضبط من هنا، ويمكن حفظهما كإعداد افتراضي
 * للنظام من زر «حفظ كإعداد افتراضي» (للمدير) أو من الإعدادات.
 */
function SlowMovingTab({ currency, settings, canManage, onSettingsSaved }) {
  const toast = useToast();
  const [maxQty, setMaxQty] = useState(() => settings?.slow_moving_max_qty ?? 5);
  const [periodDays, setPeriodDays] = useState(() => settings?.slow_moving_period_days ?? 30);
  const [rows, setRows] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [savingDefault, setSavingDefault] = useState(false);

  // مزامنة القيم الافتراضية القادمة من إعدادات النظام (عند تحميلها أول مرة)
  const appliedDefaults = React.useRef(false);
  useEffect(() => {
    if (appliedDefaults.current) return;
    if (settings?.slow_moving_max_qty !== undefined || settings?.slow_moving_period_days !== undefined) {
      if (settings.slow_moving_max_qty !== undefined) setMaxQty(settings.slow_moving_max_qty);
      if (settings.slow_moving_period_days !== undefined) setPeriodDays(settings.slow_moving_period_days);
      appliedDefaults.current = true;
    }
  }, [settings]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/inventory/slow-moving', {
        max_qty: maxQty === '' ? undefined : maxQty,
        period_days: periodDays === '' ? undefined : periodDays,
      });
      setRows(r.data || []);
      setSummary(r.summary || null);
    } catch (err) { toast.error(err.message); } finally { setLoading(false); }
  }, [maxQty, periodDays]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { load(); }, [load]);

  const saveAsDefault = async () => {
    setSavingDefault(true);
    try {
      await api.put('/settings', {
        slow_moving_max_qty: String(Number(maxQty) || 0),
        slow_moving_period_days: String(Number(periodDays) || 30),
      });
      await onSettingsSaved?.();
      appliedDefaults.current = true;
      toast.success('تم حفظ إعدادات الأدوية الراكدة كإعداد افتراضي للنظام');
    } catch (err) { toast.error(err.message); } finally { setSavingDefault(false); }
  };

  return (
    <>
      <Card className="mb-4 p-4">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="لم يُبَع منها أكثر من (كمية)" hint="مثال: 5 = صفر إلى 5 وحدات مباعة">
            <Input
              type="number" min="0" step="1" className="w-36"
              value={maxQty} onChange={(e) => setMaxQty(e.target.value)}
            />
          </Field>
          <Field label="خلال الفترة السابقة (يوم)" hint="30 = الشهر السابق">
            <div className="flex gap-2">
              <Input
                type="number" min="1" step="1" className="w-28"
                value={periodDays} onChange={(e) => setPeriodDays(e.target.value)}
              />
              <Select
                value={[7, 30, 60, 90, 180, 365].includes(Number(periodDays)) ? String(periodDays) : ''}
                onChange={(e) => setPeriodDays(e.target.value)}
              >
                <option value="" disabled>مخصص</option>
                <option value="7">أسبوع</option>
                <option value="30">الشهر السابق (30 يوماً)</option>
                <option value="60">شهران</option>
                <option value="90">3 أشهر</option>
                <option value="180">6 أشهر</option>
                <option value="365">سنة</option>
              </Select>
            </div>
          </Field>
          {canManage && (
            <button className="btn-outline" onClick={saveAsDefault} disabled={savingDefault}>
              <Save className="h-4 w-4" /> حفظ كإعداد افتراضي للنظام
            </button>
          )}
          <p className="w-full text-xs leading-6 text-ink-400">
            يُعرض هنا كل دواء <b className="text-ink-600">متوفر في المخزون</b> ولم تتجاوز مبيعاته
            {' '}<b className="text-ink-600">{fmtNum(maxQty || 0, 0)}</b> وحدة خلال آخر
            {' '}<b className="text-ink-600">{fmtNum(periodDays || 0, 0)}</b> يوم — بما فيها الأدوية التي لم تُبَع أبداً.
          </p>
        </div>
      </Card>

      {summary && !loading && (
        <div className="mb-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <StatCard label="أصناف راكدة" value={fmtNum(summary.count, 0)} sub={`بحد أقصى ${fmtNum(maxQty || 0, 0)} مباعة / ${fmtNum(periodDays || 0, 0)} يوم`} icon={Hourglass} tone="amber" />
          <StatCard label="رأس المال المحبوس (تكلفة)" value={`${fmtNum(summary.tied_capital)} ${currency}`} sub={`قيمة بيع متوقعة ${fmtNum(summary.tied_sale_value)} ${currency}`} icon={TrendingUp} tone="rose" />
          <StatCard label="لم تُبَع أبداً" value={fmtNum(summary.never_sold, 0)} sub="أصناف بلا أي عملية بيع مسجلة" icon={PackageX} tone="blue" />
        </div>
      )}

      <Table
        loading={loading}
        columns={['الصنف', 'التصنيف', 'المخزون الحالي', 'قيمة المخزون الراكد', `المباعة آخر ${fmtNum(periodDays || 0, 0)} يوم`, 'إجمالي المبيعات', 'آخر عملية بيع', 'منذ آخر بيع', 'الحالة', 'إجراء مقترح']}
        rows={rows}
        empty={<EmptyState title="لا توجد أدوية راكدة بهذه المعايير" hint="كل الأصناف المتوفرة تجاوزت حد المبيعات المحدد خلال الفترة" icon={Hourglass} />}
        renderRow={(p) => (
          <tr key={p.id}>
            <td>
              <p className="font-extrabold text-ink-900">{p.name} <span className="text-xs text-ink-400">{p.strength || ''}</span></p>
              <p className="text-[11px] text-ink-400">{p.generic_name || '—'}{p.location ? ` · الرف: ${p.location}` : ''}</p>
            </td>
            <td className="text-ink-500">{p.category || '—'}</td>
            <td className="num font-extrabold">{fmtStock(p.stock_qty, p)}</td>
            <td className="num font-bold text-rose-600">{fmtNum(p.stock_cost_value)} {currency}</td>
            <td className="num"><Badge tone={Number(p.sold_qty) === 0 ? 'red' : 'amber'}>{fmtNum(p.sold_qty, 0)} {p.unit}</Badge></td>
            <td className="num text-ink-500">{fmtNum(p.sold_qty_total, 0)} {p.unit}</td>
            <td className="text-xs text-ink-500">{p.last_sale_date ? fmtDate(p.last_sale_date) : '—'}</td>
            <td className="num text-ink-500">{p.never_sold ? '—' : `${fmtNum(p.days_since_last_sale, 0)} يوم`}</td>
            <td>{p.never_sold ? <Badge tone="red">لم يُبَع أبداً</Badge> : <Badge tone="amber">راكد / بطيء الحركة</Badge>}</td>
            <td className="max-w-[220px] text-xs leading-5 text-ink-500">
              {p.never_sold
                ? 'مراجعة الحاجة للصنف، الترويج له، أو إرجاعه للمورد إن أمكن'
                : 'تخفيض الطلب منه، عمل عرض ترويجي، أو نقله لموقع أوضح على الرف'}
            </td>
          </tr>
        )}
      />
    </>
  );
}

/* ================== تبويب الحركات ================== */
function MovementsTab({ currency }) {
  const [filters, setFilters] = useState({ q: '', type: '' });
  const [page, setPage] = useState(1);
  const [res, setRes] = useState({ data: [], pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get('/inventory/movements', { ...filters, page, limit: 25 }).then(setRes).finally(() => setLoading(false));
  }, [filters, page]);

  return (
    <>
      <Card className="mb-4 p-4">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="بحث بالصنف" className="min-w-[200px] flex-1">
            <Input value={filters.q} onChange={(e) => { setFilters({ ...filters, q: e.target.value }); setPage(1); }} placeholder="اسم الصنف" />
          </Field>
          <Field label="نوع الحركة">
            <Select value={filters.type} onChange={(e) => { setFilters({ ...filters, type: e.target.value }); setPage(1); }}>
              <option value="">الكل</option>
              {Object.entries(MOVEMENT_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </Select>
          </Field>
        </div>
      </Card>
      <Table
        loading={loading}
        columns={['التاريخ', 'الصنف', 'الحركة', 'الكمية', 'التكلفة', 'الدفعة', 'المرجع', 'المستخدم', 'ملاحظة']}
        rows={res.data}
        renderRow={(m) => (
          <tr key={m.id}>
            <td className="text-xs text-ink-500">{fmtDateTime(m.created_at)}</td>
            <td className="font-bold">{m.product_name}</td>
            <td><Badge tone={m.qty > 0 ? 'green' : 'red'}>{MOVEMENT_TYPES[m.type] || m.type}</Badge></td>
            <td className={cn('num font-extrabold', m.qty > 0 ? 'text-emerald-600' : 'text-rose-600')}>{m.qty > 0 ? '+' : ''}{fmtNum(m.qty, 0)}</td>
            <td className="num">{fmtNum(m.unit_cost)} {currency}</td>
            <td className="text-xs">{m.batch_no || '—'}</td>
            <td className="text-xs text-ink-400">{m.ref_type || '—'}{m.ref_id ? `#${m.ref_id}` : ''}</td>
            <td className="text-xs text-ink-400">{m.user_name || '—'}</td>
            <td className="max-w-[220px] truncate text-xs text-ink-400">{m.note || '—'}</td>
          </tr>
        )}
      />
      <Pagination page={page} pages={res.pages} total={res.total} onChange={setPage} />
    </>
  );
}

/* ================== تحديث الأسعار الجماعي ==================
 * الحل العملي لتغيّر الأسعار السريع: اختر النطاق (محدد/الكل/تصنيف/بحث)
 * والطريقة (نسبة % / مبلغ ثابت / هامش ربح من سعر الشراء) والتقريب،
 * راجع المعاينة قبل/بعد، ثم طبّق — مع سجل يتيح التراجع الكامل للمدير.
 */
function PriceUpdateModal({ initialScopeType, selectedIds, categories, currency, canRevert, onClose, onApplied }) {
  const toast = useToast();
  const [form, setForm] = useState({
    scopeType: initialScopeType || 'all',
    category: categories[0] || '',
    q: '',
    target: 'sale',
    method: 'percent',
    value: 10,
    rounding: '1',
    reason: '',
    syncCatalog: false,
  });
  const [preview, setPreview] = useState(null);
  const [previewKey, setPreviewKey] = useState('');
  const [applied, setApplied] = useState(null);
  const [history, setHistory] = useState([]);
  const [busy, setBusy] = useState(false);

  const payload = () => ({
    scope: {
      type: form.scopeType,
      ids: form.scopeType === 'selected' ? selectedIds : [],
      category: form.scopeType === 'category' ? form.category : null,
      q: form.scopeType === 'search' ? form.q : null,
    },
    target: form.method === 'margin' ? 'sale' : form.target,
    method: form.method,
    value: Number(form.value) || 0,
    rounding: Number(form.rounding),
    reason: form.reason || null,
    sync_catalog: !!form.syncCatalog,
  });
  const payloadKey = JSON.stringify(payload());
  const previewStale = preview && previewKey !== payloadKey;

  const loadHistory = useCallback(() => {
    api.get('/inventory/price-updates/history', { limit: 15 }).then((r) => setHistory(r.data || [])).catch(() => {});
  }, []);
  useEffect(() => { loadHistory(); }, [loadHistory]);

  const runPreview = async () => {
    setBusy(true);
    try {
      const res = await api.post('/inventory/price-update/preview', payload());
      setPreview(res); setPreviewKey(payloadKey); setApplied(null);
      if (!res.summary.affected) toast.error('لا توجد أصناف ستتغير بهذه الإعدادات');
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  const runApply = async () => {
    setBusy(true);
    try {
      const res = await api.post('/inventory/price-update/apply', payload());
      setApplied(res);
      toast.success(`تم تحديث أسعار ${res.summary.affected} صنف (${res.batch_ref})`);
      loadHistory();
      onApplied?.();
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  const revert = async (ref) => {
    setBusy(true);
    try {
      const res = await api.post(`/inventory/price-updates/${encodeURIComponent(ref)}/revert`, {});
      toast.success(`تم التراجع: أُعيد ${res.restored} سعر، وتُرك ${res.skipped} تغيّر لاحقاً`);
      loadHistory(); setPreview(null); onApplied?.();
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  const set = (patch) => { setForm((f) => ({ ...f, ...patch })); };
  const presets = [5, 10, 15, 20, 25, 50, -5, -10];

  return (
    <Modal
      open onClose={onClose} size="xl"
      title="تحديث الأسعار الجماعي"
      subtitle="لرفع أو خفض أسعار أدوية كثيرة بضغطة واحدة عند تغيّر الأسعار — راجع المعاينة دائماً قبل التطبيق"
      footer={(
        <>
          <button className="btn-ghost" onClick={onClose}>{applied ? 'إغلاق' : 'إلغاء'}</button>
          {!applied && (
            <>
              <button className="btn-outline" onClick={runPreview} disabled={busy}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />} معاينة التغيير
              </button>
              <button className="btn-primary" onClick={runApply} disabled={busy || !preview || previewStale || !preview.summary.affected}>
                <Percent className="h-4 w-4" /> تطبيق على {preview && !previewStale ? preview.summary.affected : '…'} صنف
              </button>
            </>
          )}
          {applied && <button className="btn-primary" onClick={onClose}><CheckCircle2 className="h-4 w-4" /> تم</button>}
        </>
      )}
    >
      <div className="space-y-4">
        {applied ? (
          <div className="rounded-xl bg-emerald-50 p-4 text-sm font-extrabold text-emerald-700">
            <CheckCircle2 className="ml-1 inline h-4 w-4" />
            تم تطبيق العملية <span className="num">{applied.batch_ref}</span> على {applied.summary.affected} صنف.
            يمكنك التراجع عنها من «سجل تحديثات الأسعار» بالأسفل (للمدير) إن لزم.
          </div>
        ) : (
          <>
            {/* اختصارات سريعة */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-extrabold text-ink-500">رفع/خفض سريع لأسعار البيع:</span>
              {presets.map((v) => (
                <button
                  key={v}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] font-extrabold ${form.method === 'percent' && form.target === 'sale' && Number(form.value) === v ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-ink-200 text-ink-500 hover:bg-ink-50'}`}
                  onClick={() => set({ method: 'percent', target: 'sale', value: v })}
                >
                  {v > 0 ? `+${v}%` : `${v}%`}
                </button>
              ))}
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="نطاق التحديث">
                <Select value={form.scopeType} onChange={(e) => set({ scopeType: e.target.value })}>
                  <option value="selected" disabled={!selectedIds.length}>الأصناف المحددة ({selectedIds.length})</option>
                  <option value="all">كل الأصناف النشطة</option>
                  <option value="category">تصنيف كامل</option>
                  <option value="search">نتيجة بحث</option>
                </Select>
              </Field>
              {form.scopeType === 'category' && (
                <Field label="التصنيف">
                  <Select value={form.category} onChange={(e) => set({ category: e.target.value })}>
                    <option value="">اختر التصنيف</option>
                    {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                  </Select>
                </Field>
              )}
              {form.scopeType === 'search' && (
                <Field label="كلمة البحث" hint="الاسم / المادة / الباركود / الشركة">
                  <Input value={form.q} onChange={(e) => set({ q: e.target.value })} placeholder="مثال: باراسيتامول" />
                </Field>
              )}
              <Field label="الأسعار المراد تحديثها">
                <Select value={form.method === 'margin' ? 'sale' : form.target} onChange={(e) => set({ target: e.target.value })} disabled={form.method === 'margin'}>
                  <option value="sale">أسعار البيع فقط</option>
                  <option value="purchase">أسعار الشراء فقط</option>
                  <option value="both">الشراء والبيع معاً بنفس القيمة</option>
                </Select>
              </Field>
              <Field label="طريقة التحديث">
                <Select value={form.method} onChange={(e) => set({ method: e.target.value })}>
                  <option value="percent">نسبة مئوية (+/-)</option>
                  <option value="fixed">مبلغ ثابت (+/-)</option>
                  <option value="margin">سعر بيع بهامش ربح من سعر الشراء</option>
                </Select>
              </Field>
              <Field
                label={form.method === 'percent' ? 'النسبة % (سالب = تخفيض)' : form.method === 'margin' ? 'هامش الربح المستهدف %' : `المبلغ (${currency}) — سالب = تخفيض`}
              >
                <Input type="number" step="0.01" value={form.value} onChange={(e) => set({ value: e.target.value })} />
              </Field>
              <Field label="تقريب السعر الجديد" hint="مهم مع الأسعار سريعة التغيّر">
                <Select value={form.rounding} onChange={(e) => set({ rounding: e.target.value })}>
                  <option value="0">بدون تقريب (قرشين عشريين)</option>
                  <option value="0.05">لأقرب 0.05</option>
                  <option value="0.1">لأقرب 0.1</option>
                  <option value="0.25">لأقرب 0.25</option>
                  <option value="0.5">لأقرب 0.5</option>
                  <option value="1">لأقرب 1 صحيح</option>
                  <option value="5">لأقرب 5</option>
                  <option value="10">لأقرب 10</option>
                  <option value="50">لأقرب 50</option>
                  <option value="100">لأقرب 100</option>
                </Select>
              </Field>
              <Field label="سبب التحديث (يُحفظ في السجل)" className="sm:col-span-2">
                <Input value={form.reason} onChange={(e) => set({ reason: e.target.value })} placeholder="مثال: قائمة أسعار المورد الجديدة — أكتوبر" />
              </Field>
              <label className="flex cursor-pointer items-center gap-2 self-end rounded-xl border border-ink-200 px-3 py-2.5 text-xs font-bold text-ink-600">
                <input type="checkbox" className="h-4 w-4 accent-emerald-600" checked={form.syncCatalog} onChange={(e) => set({ syncCatalog: e.target.checked })} />
                مزامنة أسعار الدليل الافتراضية للأصناف المرتبطة
              </label>
            </div>

            <div className="rounded-xl bg-sky-50 px-4 py-3 text-[11px] font-bold leading-6 text-sky-800">
              تغيير «سعر الشراء» يعدّل السعر المرجعي للمشتريات القادمة ولا يغيّر تكلفة الدفعات الموجودة فعلياً،
              وسعر الوحدة الصغرى (شريط/قرص) اليدوي يتحرك بنفس نسبة سعر العبوة. أي تغيير في الإعدادات بعد المعاينة يتطلب معاينة جديدة قبل التطبيق.
            </div>

            {/* المعاينة */}
            {preview && (
              <div className="space-y-3">
                {previewStale && (
                  <p className="rounded-xl bg-amber-50 px-4 py-2.5 text-xs font-extrabold text-amber-700">
                    غيّرت الإعدادات بعد المعاينة — اضغط «معاينة التغيير» من جديد قبل التطبيق.
                  </p>
                )}
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                  <PriceStat label="أصناف مطابقة" value={preview.summary.matched} />
                  <PriceStat label="ستتغير" value={preview.summary.affected} />
                  <PriceStat label="دون تغيير" value={preview.summary.unchanged} />
                  <PriceStat label={`قيمة البيع للرصيد قبل`} value={`${fmtNum(preview.summary.sale_value_before)} ${currency}`} />
                  <PriceStat
                    label={`بعد (فرق ${preview.summary.sale_value_diff >= 0 ? '+' : ''}${fmtNum(preview.summary.sale_value_diff)})`}
                    value={`${fmtNum(preview.summary.sale_value_after)} ${currency}`}
                  />
                </div>
                <div className="max-h-80 overflow-auto rounded-2xl border border-ink-100">
                  <table className="tbl min-w-[760px]">
                    <thead><tr><th>الصنف</th><th>الرصيد</th><th>شراء قبل ← بعد</th><th>بيع قبل ← بعد</th><th>هامش قبل ← بعد</th></tr></thead>
                    <tbody>
                      {preview.data.map((c) => (
                        <tr key={c.product_id}>
                          <td>
                            <p className="font-bold">{c.name}</p>
                            <p className="text-[11px] text-ink-400">{c.category || '—'}</p>
                          </td>
                          <td className="num">{fmtNum(c.stock_qty, 0)} {c.unit}</td>
                          <td className="num">
                            {fmtNum(c.old_purchase)} ← <b className={c.new_purchase !== c.old_purchase ? 'text-brand-700' : ''}>{fmtNum(c.new_purchase)}</b>
                          </td>
                          <td className="num">
                            {fmtNum(c.old_sale)} ← <b className={c.new_sale !== c.old_sale ? 'text-brand-700' : ''}>{fmtNum(c.new_sale)}</b>
                          </td>
                          <td className="num text-ink-500">
                            {c.margin_before == null ? '—' : `${fmtNum(c.margin_before, 1)}%`} ← {c.margin_after == null ? '—' : `${fmtNum(c.margin_after, 1)}%`}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {preview.truncated && (
                  <p className="text-[11px] font-bold text-ink-400">تُعرض أول 200 صنف في المعاينة فقط — التطبيق يشمل كل الـ{preview.summary.affected} صنفاً المتغيرة.</p>
                )}
              </div>
            )}
          </>
        )}

        {/* سجل التحديثات والتراجع */}
        <div className="rounded-2xl border border-ink-100">
          <p className="flex items-center gap-2 border-b border-ink-100 px-4 py-3 text-sm font-extrabold text-ink-800">
            <History className="h-4 w-4 text-brand-600" /> سجل تحديثات الأسعار
          </p>
          {history.length === 0 ? (
            <p className="px-4 py-3 text-xs font-bold text-ink-400">لا توجد عمليات تحديث جماعية بعد.</p>
          ) : (
            <div className="max-h-56 divide-y divide-ink-50 overflow-auto">
              {history.map((h) => {
                const fullyReverted = h.records > 0 && h.reverted_records >= h.records;
                return (
                  <div key={h.batch_ref} className="flex flex-wrap items-center gap-2 px-4 py-2.5 text-xs">
                    <span className="num font-extrabold text-ink-800">{h.batch_ref}</span>
                    <span className="text-ink-500">{h.items} صنف · {h.records} سعر</span>
                    <span className="text-ink-400">{fmtDateTime(h.created_at)} · {h.user_name || '—'}</span>
                    {h.reason && <span className="max-w-[240px] truncate text-ink-400" title={h.reason}>{h.reason}</span>}
                    {fullyReverted
                      ? <Badge tone="gray">تم التراجع عنها</Badge>
                      : h.reverted_records > 0
                        ? <Badge tone="amber">تراجع جزئي ({h.reverted_records}/{h.records})</Badge>
                        : <Badge tone="green">مطبقة</Badge>}
                    {canRevert && !fullyReverted && (
                      <button className="btn-outline btn-sm mr-auto text-rose-600" disabled={busy} onClick={() => revert(h.batch_ref)}>
                        <RotateCcw className="h-3.5 w-3.5" /> تراجع عن العملية
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

const PriceStat = ({ label, value }) => (
  <div className="rounded-xl bg-ink-50 p-3 text-center">
    <p className="num text-base font-black text-ink-900">{value}</p>
    <p className="mt-0.5 text-[10px] font-bold text-ink-400">{label}</p>
  </div>
);

/* ================== نافذة التسوية ================== */
function AdjustModal({ adjust, setAdjust, onSubmit }) {
  const [q, setQ] = useState('');
  const [options, setOptions] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (!adjust) { setQ(''); setSelected(null); setOptions([]); }
  }, [adjust]);

  useEffect(() => {
    if (!q.trim()) { setOptions([]); return undefined; }
    const t = setTimeout(() => api.get('/products/search', { q }).then((r) => setOptions(r.data)), 220);
    return () => clearTimeout(t);
  }, [q]);

  if (!adjust) return null;

  return (
    <Modal
      open onClose={() => setAdjust(null)} size="md" title="تسوية مخزنية"
      subtitle="إدخال أو إخراج كميات مع تسجيل الحركة في سجل المخزون"
      footer={<><button className="btn-ghost" onClick={() => setAdjust(null)}>إلغاء</button>
        <button className="btn-primary" onClick={onSubmit} disabled={!adjust.product_id}>تنفيذ التسوية</button></>}
    >
      <div className="space-y-3">
        <Field label="الصنف" required>
          {selected ? (
            <div className="flex items-center justify-between rounded-xl border border-brand-300 bg-brand-50 px-3 py-2.5">
              <div>
                <p className="font-extrabold text-ink-900">{selected.name}</p>
                <p className="text-[11px] text-ink-500">المتاح: {fmtNum(selected.stock_qty, 0)} {selected.unit}</p>
              </div>
              <button className="btn-ghost btn-sm" onClick={() => { setSelected(null); setAdjust({ ...adjust, product_id: '' }); }}>تغيير</button>
            </div>
          ) : (
            <>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                <Input className="pr-9" autoFocus placeholder="ابحث عن الصنف..." value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              {options.length > 0 && (
                <div className="mt-1.5 max-h-48 space-y-1 overflow-y-auto rounded-xl border border-ink-100 p-1">
                  {options.map((o) => (
                    <button key={o.id} className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-right text-sm hover:bg-brand-50"
                      onClick={() => { setSelected(o); setAdjust({ ...adjust, product_id: o.id }); }}>
                      <span className="font-bold">{o.name}</span>
                      <span className="num text-xs text-ink-400">{fmtNum(o.stock_qty, 0)} {o.unit}</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="نوع التسوية">
            <Select value={adjust.type} onChange={(e) => setAdjust({ ...adjust, type: e.target.value })}>
              <option value="adjust_in">إدخال (زيادة)</option>
              <option value="adjust_out">إخراج (نقص)</option>
              <option value="damage">تالف</option>
              <option value="expired">منتهي الصلاحية</option>
            </Select>
          </Field>
          <Field label="الكمية" required>
            <Input type="number" min="0.01" step="0.01" value={adjust.qty} onChange={(e) => setAdjust({ ...adjust, qty: e.target.value })} />
          </Field>
        </div>

        {adjust.type === 'adjust_in' && (
          <div className="grid grid-cols-3 gap-3">
            <Field label="رقم الدفعة"><Input value={adjust.batch_no || ''} onChange={(e) => setAdjust({ ...adjust, batch_no: e.target.value })} /></Field>
            <Field label="تاريخ الانتهاء"><Input type="date" value={adjust.expiry_date || ''} onChange={(e) => setAdjust({ ...adjust, expiry_date: e.target.value })} /></Field>
            <Field label="تكلفة الوحدة"><Input type="number" step="0.01" value={adjust.cost_price || ''} onChange={(e) => setAdjust({ ...adjust, cost_price: e.target.value })} /></Field>
          </div>
        )}

        <Field label="سبب / ملاحظة">
          <Input value={adjust.note || ''} onChange={(e) => setAdjust({ ...adjust, note: e.target.value })} placeholder="مثال: جرد فعلي، كسر، هدية..." />
        </Field>
      </div>
    </Modal>
  );
}

const Info = ({ label, value }) => (
  <div className="rounded-xl bg-ink-50 px-3 py-2">
    <p className="text-[11px] font-bold text-ink-400">{label}</p>
    <p className="num font-extrabold text-ink-800">{value}</p>
  </div>
);

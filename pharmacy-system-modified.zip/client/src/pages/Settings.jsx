import React, { useCallback, useEffect, useState } from 'react';
import {
  Settings as SettingsIcon, Save, Users, Plus, Pencil, Trash2, Activity, Download,
  Building2, KeyRound, ShieldCheck, DatabaseBackup, Info, Pill, Copyright, Copy,
} from 'lucide-react';
import { SYSTEM_INFO, COPYRIGHT_TEXT } from '../lib/system.js';
import api, { getToken } from '../api.js';
import { useApp } from '../context/AppContext.jsx';
import {
  PageHeader, Card, CardHeader, Tabs, Field, Input, Select, Table, Badge, Modal,
  useToast, ConfirmDialog, Loading, EmptyState,
} from '../components/ui.jsx';
import Maintenance from './settings/Maintenance.jsx';
import { fmtDateTime, ROLE_LABELS } from '../lib/format.js';

export default function Settings() {
  const [tab, setTab] = useState('general');
  const { can, canDo } = useApp();

  return (
    <div>
      <PageHeader title="الإعدادات" subtitle="بيانات الصيدلية، المستخدمون، الأمان والنسخ الاحتياطي" icon={SettingsIcon} />
      <Tabs
        value={tab} onChange={setTab}
        tabs={[
          { value: 'general', label: 'بيانات الصيدلية', icon: Building2 },
          ...(canDo('users.manage') ? [{ value: 'users', label: 'المستخدمون', icon: Users }] : []),
          ...(canDo('roles.manage') ? [{ value: 'roles', label: 'الأدوار والصلاحيات', icon: ShieldCheck }] : []),
          { value: 'security', label: 'الحساب والأمان', icon: KeyRound },
          ...(canDo('backup.manage') ? [{ value: 'maintenance', label: 'النسخ والصيانة', icon: DatabaseBackup }] : []),
          ...(canDo('activity.view') ? [{ value: 'activity', label: 'سجل النشاط', icon: Activity }] : []),
          { value: 'about', label: 'حول النظام', icon: Info },
        ]}
      />
      {tab === 'general' && <GeneralSettings />}
      {tab === 'users' && <UsersSettings />}
      {tab === 'roles' && <RolesSettings />}
      {tab === 'security' && <SecuritySettings />}
      {tab === 'maintenance' && canDo('backup.manage') && <Maintenance />}
      {tab === 'activity' && canDo('activity.view') && <ActivityLog />}
      {tab === 'about' && <AboutSettings />}
    </div>
  );
}

/* ================== بيانات الصيدلية ================== */
function GeneralSettings() {
  const { settings, reloadSettings, canDo } = useApp();
  const toast = useToast();
  const [form, setForm] = useState(settings);
  const [busy, setBusy] = useState(false);

  useEffect(() => { setForm(settings); }, [settings]);

  const save = async () => {
    setBusy(true);
    try {
      await api.put('/settings', form);
      await reloadSettings();
      toast.success('تم حفظ الإعدادات');
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  const backup = async () => {
    try {
      const res = await fetch('/api/settings/backup', { headers: { Authorization: `Bearer ${getToken()}` } });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `pharmacy-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
      URL.revokeObjectURL(url);
      toast.success('تم تنزيل النسخة الاحتياطية');
    } catch { toast.error('تعذر إنشاء النسخة الاحتياطية'); }
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="بيانات الصيدلية" subtitle="تظهر في الفواتير والتقارير" icon={Building2} />
        <div className="grid gap-3 p-5 sm:grid-cols-2">
          <Field label="اسم الصيدلية" className="sm:col-span-2"><Input value={form.pharmacy_name || ''} onChange={set('pharmacy_name')} /></Field>
          <Field label="رقم الهاتف"><Input value={form.pharmacy_phone || ''} onChange={set('pharmacy_phone')} /></Field>
          <Field label="البريد الإلكتروني"><Input value={form.pharmacy_email || ''} onChange={set('pharmacy_email')} /></Field>
          <Field label="العنوان" className="sm:col-span-2"><Input value={form.pharmacy_address || ''} onChange={set('pharmacy_address')} /></Field>
          <Field label="الرقم الضريبي"><Input value={form.tax_number || ''} onChange={set('tax_number')} /></Field>
          <Field label="رمز العملة"><Input value={form.currency || ''} onChange={set('currency')} placeholder="ر.س / ر.ي / ج.م" /></Field>
          <Field label="تذييل الفاتورة" className="sm:col-span-2"><Input value={form.invoice_footer || ''} onChange={set('invoice_footer')} /></Field>
        </div>
      </Card>

      <div className="space-y-4">
        <Card>
          <CardHeader title="إعدادات التشغيل" subtitle="الضريبة والتنبيهات" icon={SettingsIcon} />
          <div className="grid gap-3 p-5 sm:grid-cols-2">
            <Field label="نسبة الضريبة %" hint="0 لتعطيل الضريبة"><Input type="number" step="0.01" value={form.tax_rate || '0'} onChange={set('tax_rate')} /></Field>
            <Field label="حد المخزون المنخفض" hint="يُستخدم عند عدم تحديد حد للصنف"><Input type="number" value={form.low_stock_level || '10'} onChange={set('low_stock_level')} /></Field>
            <Field label="تنبيه الصلاحية (يوم)"><Input type="number" value={form.expiry_alert_days || '90'} onChange={set('expiry_alert_days')} /></Field>
            <Field label="حد الأدوية الراكدة (كمية مباعة)" hint="صنف راكد إذا لم يُبَع منه أكثر من هذه الكمية">
              <Input type="number" min="0" step="1" value={form.slow_moving_max_qty ?? '5'} onChange={set('slow_moving_max_qty')} />
            </Field>
            <Field label="فترة الأدوية الراكدة (يوم)" hint="30 = الشهر السابق — تُستخدم في تبويب «الأدوية الراكدة» بالمخزون">
              <Input type="number" min="1" step="1" value={form.slow_moving_period_days ?? '30'} onChange={set('slow_moving_period_days')} />
            </Field>
            <Field label="السماح بالبيع بالسالب">
              <Select value={form.allow_negative_stock || '0'} onChange={set('allow_negative_stock')}>
                <option value="0">لا (موصى به)</option><option value="1">نعم</option>
              </Select>
            </Field>
          </div>
          {canDo('settings.manage') && (
            <div className="flex justify-end gap-2 border-t border-ink-100 px-5 py-3.5">
              <button className="btn-primary" onClick={save} disabled={busy}><Save className="h-4 w-4" /> حفظ الإعدادات</button>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="النسخ الاحتياطي" subtitle="تنزيل نسخة كاملة من البيانات بصيغة JSON" icon={Download} />
          <div className="flex items-center justify-between gap-3 p-5">
            <p className="text-sm text-ink-500">
              يُنصح بأخذ نسخة احتياطية دورية وحفظها خارج الجهاز.
              <br />
              <span className="text-xs text-ink-400">للاستعادة أو مسح البيانات افتح تبويب «النسخ والصيانة».</span>
            </p>
            {canDo('backup.manage') && <button className="btn-outline shrink-0" onClick={backup}><Download className="h-4 w-4" /> تنزيل نسخة</button>}
          </div>
        </Card>
      </div>
    </div>
  );
}


/* ================== الأدوار والصلاحيات ================== */
function RolesSettings() {
  const toast = useToast();
  const [roles, setRoles] = useState([]);
  const [catalog, setCatalog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get('/roles');
      setRoles(res.data || []);
      setCatalog(res.catalog || []);
    } catch (err) { toast.error(err.message); }
    finally { setLoading(false); }
  }, [toast]);
  useEffect(() => { load(); }, [load]);

  const groups = [];
  for (const item of catalog) {
    let group = groups.find((g) => g.name === item.group);
    if (!group) { group = { name: item.group, items: [] }; groups.push(group); }
    group.items.push(item);
  }

  const selected = new Set(form?.permissions || []);
  const isAdmin = form?.key === 'admin';
  const setPerms = (permissions) => setForm((f) => ({ ...f, permissions }));
  const toggle = (key, checked) => {
    const next = new Set(form.permissions || []);
    if (checked) next.add(key); else next.delete(key);
    setPerms([...next]);
  };
  const toggleGroup = (items, checked) => {
    const next = new Set(form.permissions || []);
    items.forEach((item) => (checked ? next.add(item.key) : next.delete(item.key)));
    setPerms([...next]);
  };
  const openNew = (copy = null) => setForm({
    _mode: 'create',
    key: '',
    label: copy ? `${copy.label} — نسخة` : '',
    description: copy?.description || '',
    permissions: copy
      ? (copy.key === 'admin' || copy.permissions?.includes('*') ? catalog.map((item) => item.key) : [...(copy.permissions || [])])
      : ['dashboard.view'],
    rank: copy?.rank || 1,
    active: 1,
    is_system: 0,
    users_count: 0,
  });
  // الأدوار تُعرَّف بالمفتاح النصي key (لا يوجد id رقمي)، لذلك نميّز التعديل بوضع صريح
  // حتى لا يتحول حفظ التعديل إلى إنشاء دور مخصص جديد.
  const openEdit = (role) => setForm({ ...role, _mode: 'edit', permissions: [...(role.permissions || [])] });

  const save = async () => {
    if (!form.label.trim()) return toast.error('اسم الدور مطلوب');
    if (!isAdmin && form.permissions.length === 0) return toast.error('اختر صلاحية واحدة على الأقل');
    setBusy(true);
    try {
      const payload = {
        label: form.label.trim(),
        description: form.description || '',
        permissions: isAdmin ? ['*'] : form.permissions,
        rank: Number(form.rank) || 1,
        active: form.active ? 1 : 0,
      };
      const isEditing = form._mode === 'edit' && !!form.key;
      if (isEditing) await api.put(`/roles/${encodeURIComponent(form.key)}`, payload);
      else await api.post('/roles', payload);
      toast.success(isEditing ? 'تم حفظ تعديلات الدور' : 'تم إنشاء الدور — يمكنك الآن ربطه بالمستخدمين من تبويب المستخدمون');
      setForm(null);
      load();
    } catch (err) { toast.error(err.message); }
    finally { setBusy(false); }
  };

  const remove = async () => {
    try {
      await api.del(`/roles/${del.key}`);
      toast.success('تم حذف الدور');
      setDel(null);
      load();
    } catch (err) { toast.error(err.message); }
  };

  if (loading) return <Loading label="جاري تحميل الأدوار والصلاحيات..." />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3 rounded-2xl border border-brand-100 bg-brand-50 p-4">
        <div className="flex max-w-3xl gap-3">
          <ShieldCheck className="mt-0.5 h-6 w-6 shrink-0 text-brand-700" />
          <div>
            <p className="font-extrabold text-ink-900">تحكم كامل في ما يراه ويفعله كل دور</p>
            <p className="mt-1 text-sm leading-6 text-ink-600">
              الصلاحية <b>«الأرقام المالية في لوحة التحكم»</b> هي التي تُظهر مبيعات وأرباح الشهر وقيمة المخزون والديون.
              بدونها يرى المستخدم اللوحة التشغيلية والتنبيهات فقط، ولا تُرسل الأرقام المالية من الخادم أصلاً.
              دور «مدير النظام» يملك كل الصلاحيات دائماً ولا يمكن تقليصها.
            </p>
          </div>
        </div>
        <button className="btn-primary shrink-0" onClick={() => openNew()}><Plus className="h-4 w-4" /> إضافة دور</button>
      </div>

      {roles.length === 0 ? <EmptyState title="لا توجد أدوار" /> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {roles.map((role) => (
            <div key={role.key} className="card flex flex-col p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-extrabold text-ink-900">{role.label}</h3>
                    {role.is_system ? <Badge tone="violet">أساسي</Badge> : <Badge tone="blue">مخصص</Badge>}
                    {!role.active && <Badge tone="red">معطّل</Badge>}
                  </div>
                  <p className="mt-1 text-xs leading-5 text-ink-500">{role.description || 'بدون وصف'}</p>
                </div>
                <span className="num rounded-lg bg-ink-50 px-2 py-1 text-[11px] font-bold text-ink-500">{role.key}</span>
              </div>
              <div className="mt-4 flex gap-4 border-t border-ink-100 pt-3 text-xs font-bold text-ink-500">
                <span>{role.key === 'admin' ? 'كل الصلاحيات' : `${role.permissions?.length || 0} صلاحية`}</span>
                <span>{role.users_count || 0} مستخدم مرتبط</span>
                <span>الرتبة {role.rank}</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button className="btn-outline btn-sm" onClick={() => openEdit(role)}><Pencil className="h-3.5 w-3.5" /> تعديل الصلاحيات</button>
                <button className="btn-ghost btn-sm" onClick={() => openNew(role)}><Copy className="h-3.5 w-3.5" /> نسخ</button>
                <button
                  className="btn-ghost btn-sm text-rose-600 disabled:cursor-not-allowed disabled:opacity-40"
                  disabled={!!role.is_system || (role.users_count || 0) > 0}
                  title={role.is_system ? 'لا يمكن حذف دور أساسي' : (role.users_count > 0 ? 'انقل المستخدمين المرتبطين أولاً' : 'حذف الدور')}
                  onClick={() => setDel(role)}
                >
                  <Trash2 className="h-3.5 w-3.5" /> حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!form} onClose={() => setForm(null)} size="xl"
        title={form?._mode === 'edit' ? `تعديل دور: ${form.label}` : 'إضافة دور جديد'}
        subtitle="اختر الصفحات والإجراءات المسموحة لهذا الدور — تُطبق فوراً على المستخدمين المرتبطين به"
        footer={(
          <>
            <button className="btn-ghost" onClick={() => setForm(null)} disabled={busy}>إلغاء</button>
            <button className="btn-primary" onClick={save} disabled={busy}><Save className="h-4 w-4" /> حفظ الدور</button>
          </>
        )}
      >
        {form && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="اسم الدور *"><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="مثال: مساعد صيدلي" /></Field>
              <Field label="مستوى الدور (للتوافق والترتيب)" hint="١ كاشير · ٢ صيدلي · ٣ مدير · ٤ مدير نظام">
                <Select value={form.rank} onChange={(e) => setForm({ ...form, rank: Number(e.target.value) })} disabled={isAdmin}>
                  <option value={1}>١ — أساسي</option>
                  <option value={2}>٢ — متقدم</option>
                  <option value={3}>٣ — مدير</option>
                  <option value={4}>٤ — مدير نظام</option>
                </Select>
              </Field>
              <Field label="وصف الدور" className="sm:col-span-2"><Input value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="وصف مختصر لمهام هذا الدور" /></Field>
            </div>

            {isAdmin ? (
              <div className="rounded-xl bg-violet-50 p-4 text-sm font-bold text-violet-800">
                دور مدير النظام يملك كل الصلاحيات الحالية والمستقبلية دائماً، لذلك لا يمكن إلغاء أي صلاحية منه.
              </div>
            ) : (
              <>
                <label className="flex items-center gap-2 text-sm font-bold text-ink-700">
                  <input type="checkbox" checked={!!form.active} disabled={!!form.is_system && form.key === 'admin'} onChange={(e) => setForm({ ...form, active: e.target.checked ? 1 : 0 })} />
                  الدور مفعّل (يمكن ربط مستخدمين به)
                </label>
                <div className="space-y-3">
                  {groups.map((group) => {
                    const all = group.items.every((item) => selected.has(item.key));
                    return (
                      <div key={group.name} className="rounded-xl border border-ink-100">
                        <div className="flex items-center justify-between gap-2 border-b border-ink-100 bg-ink-50 px-4 py-2.5">
                          <p className="text-sm font-extrabold text-ink-800">{group.name}</p>
                          <button type="button" className="text-xs font-bold text-brand-700 hover:underline" onClick={() => toggleGroup(group.items, !all)}>
                            {all ? 'إلغاء الكل' : 'تحديد الكل'}
                          </button>
                        </div>
                        <div className="grid gap-2 p-4 sm:grid-cols-2">
                          {group.items.map((item) => (
                            <label key={item.key} className="flex cursor-pointer items-start gap-2 rounded-lg p-2 transition hover:bg-brand-50">
                              <input type="checkbox" className="mt-1" checked={selected.has(item.key)} onChange={(e) => toggle(item.key, e.target.checked)} />
                              <span>
                                <span className="block text-sm font-bold text-ink-800">{item.label}</span>
                                <span className="block text-[11px] leading-5 text-ink-400">{item.description}</span>
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!del} onClose={() => setDel(null)} onConfirm={remove} danger
        title="حذف الدور" confirmLabel="حذف الدور"
        message={`سيتم حذف دور «${del?.label || ''}» نهائياً. لا يمكن حذف دور مرتبط بمستخدمين.`}
      />
    </div>
  );
}


/* ================== المستخدمون ================== */
function UsersSettings() {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [availableRoles, setAvailableRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [deleteId, setDeleteId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [usersRes, rolesRes] = await Promise.all([
        api.get('/users'),
        api.get('/roles').catch(() => ({ data: [] })),
      ]);
      setRows(usersRes.data || []);
      setAvailableRoles((rolesRes.data || []).filter((r) => r.active));
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    try {
      if (form.id) { await api.put(`/users/${form.id}`, form); toast.success('تم تحديث المستخدم'); }
      else { await api.post('/users', form); toast.success('تمت إضافة المستخدم'); }
      setForm(null); load();
    } catch (err) { toast.error(err.message); }
  };

  const remove = async () => {
    try { const r = await api.del(`/users/${deleteId}`); toast.success(r.message || 'تم الحذف'); setDeleteId(null); load(); }
    catch (err) { toast.error(err.message); setDeleteId(null); }
  };

  return (
    <Card>
      <CardHeader
        title="مستخدمو النظام" subtitle="إدارة الحسابات والصلاحيات" icon={Users}
        action={<button className="btn-primary btn-sm" onClick={() => setForm({ username: '', full_name: '', password: '', role: availableRoles.find((r) => r.key === 'assistant')?.key || availableRoles.find((r) => r.key === 'cashier')?.key || availableRoles[0]?.key || 'cashier', phone: '', active: 1 })}>
          <Plus className="h-4 w-4" /> مستخدم جديد
        </button>}
      />
      <Table
        loading={loading}
        columns={['المستخدم', 'الاسم', 'الصلاحية', 'الجوال', 'آخر دخول', 'الحالة', '']}
        rows={rows}
        renderRow={(u) => (
          <tr key={u.id}>
            <td className="font-extrabold">{u.username}</td>
            <td>{u.full_name}</td>
            <td><Badge tone={u.role === 'admin' ? 'red' : u.role === 'manager' ? 'violet' : 'brand'}>{u.role_label || ROLE_LABELS[u.role] || u.role}</Badge></td>
            <td className="num text-ink-500">{u.phone || '—'}</td>
            <td className="text-xs text-ink-400">{u.last_login ? fmtDateTime(u.last_login) : 'لم يسجل بعد'}</td>
            <td>{u.active ? <Badge tone="green">نشط</Badge> : <Badge tone="gray">موقوف</Badge>}</td>
            <td>
              <div className="flex gap-1">
                <button className="btn-outline btn-sm" onClick={() => setForm({ ...u, password: '' })}><Pencil className="h-3.5 w-3.5" /></button>
                <button className="btn-outline btn-sm text-rose-600" onClick={() => setDeleteId(u.id)}><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </td>
          </tr>
        )}
      />

      <Modal
        open={!!form} onClose={() => setForm(null)} size="sm"
        title={form?.id ? `تعديل: ${form.username}` : 'إضافة مستخدم'}
        footer={<><button className="btn-ghost" onClick={() => setForm(null)}>إلغاء</button>
          <button className="btn-primary" onClick={save}>حفظ</button></>}
      >
        {form && (
          <div className="space-y-3">
            <Field label="اسم المستخدم" required><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></Field>
            <Field label="الاسم الكامل" required><Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></Field>
            <Field label={form.id ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء)' : 'كلمة المرور'} required={!form.id}>
              <Input type="password" value={form.password || ''} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </Field>
            <Field label="الدور" required hint="تُدار صلاحيات كل دور من تبويب «الأدوار والصلاحيات»">
              <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {availableRoles.length === 0 && Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                {availableRoles.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}
                {form.role && !availableRoles.some((r) => r.key === form.role) && (
                  <option value={form.role}>{form.role_label || ROLE_LABELS[form.role] || form.role} (دور معطّل حالياً)</option>
                )}
              </Select>
            </Field>
            <Field label="رقم الجوال"><Input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="الحالة">
              <Select value={form.active} onChange={(e) => setForm({ ...form, active: Number(e.target.value) })}>
                <option value={1}>نشط</option><option value={0}>موقوف</option>
              </Select>
            </Field>
            <div className="rounded-xl bg-ink-50 p-3 text-[11px] leading-6 text-ink-500">
              <p className="font-extrabold text-ink-700"><ShieldCheck className="ml-1 inline h-3.5 w-3.5" /> صلاحيات الأدوار:</p>
              <p>• كاشير: البيع والمرتجعات وعرض المخزون والعملاء.</p>
              <p>• صيدلي: إضافة الأصناف والأدوية والمشتريات والمصروفات.</p>
              <p>• مدير الصيدلية: كل ما سبق + التقارير والحذف والإعدادات.</p>
              <p>• مدير النظام: صلاحيات كاملة + إدارة المستخدمين.</p>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={remove} danger
        title="حذف المستخدم" confirmLabel="حذف"
        message="سيتم حذف المستخدم نهائياً إن لم تكن له عمليات مسجلة، وإلا سيتم إيقافه."
      />
    </Card>
  );
}

/* ================== الأمان ================== */
function SecuritySettings() {
  const { user } = useApp();
  const toast = useToast();
  const [form, setForm] = useState({ current_password: '', new_password: '', confirm: '' });
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (form.new_password !== form.confirm) { toast.error('كلمتا المرور غير متطابقتين'); return; }
    setBusy(true);
    try {
      await api.post('/auth/change-password', { current_password: form.current_password, new_password: form.new_password });
      toast.success('تم تغيير كلمة المرور');
      setForm({ current_password: '', new_password: '', confirm: '' });
    } catch (err) { toast.error(err.message); } finally { setBusy(false); }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="بيانات الحساب" icon={Users} />
        <div className="space-y-3 p-5 text-sm">
          <Row label="الاسم" value={user.full_name} />
          <Row label="اسم المستخدم" value={user.username} />
          <Row label="الصلاحية" value={ROLE_LABELS[user.role]} />
        </div>
      </Card>
      <Card>
        <CardHeader title="تغيير كلمة المرور" icon={KeyRound} />
        <form onSubmit={submit} className="space-y-3 p-5">
          <Field label="كلمة المرور الحالية" required>
            <Input type="password" value={form.current_password} onChange={(e) => setForm({ ...form, current_password: e.target.value })} />
          </Field>
          <Field label="كلمة المرور الجديدة" required>
            <Input type="password" value={form.new_password} onChange={(e) => setForm({ ...form, new_password: e.target.value })} />
          </Field>
          <Field label="تأكيد كلمة المرور" required>
            <Input type="password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} />
          </Field>
          <button className="btn-primary w-full" disabled={busy}><Save className="h-4 w-4" /> حفظ كلمة المرور</button>
        </form>
      </Card>
    </div>
  );
}

const Row = ({ label, value }) => (
  <div className="flex items-center justify-between border-b border-dashed border-ink-100 pb-2">
    <span className="text-ink-500">{label}</span>
    <span className="font-extrabold text-ink-800">{value}</span>
  </div>
);

/* ================== حول النظام ================== */
function AboutSettings() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <div className="flex flex-col items-center gap-3 px-5 pb-2 pt-8 text-center">
          <div className="rounded-3xl bg-brand-600 p-4 text-white shadow-pop">
            <Pill className="h-10 w-10" />
          </div>
          <div>
            <p className="text-2xl font-extrabold text-ink-900">{SYSTEM_INFO.name}</p>
            <p className="mt-1 text-sm font-bold text-ink-400">{SYSTEM_INFO.tagline}</p>
          </div>
          <Badge tone="brand">الإصدار {SYSTEM_INFO.version}</Badge>
        </div>
        <div className="space-y-3 p-5 text-sm">
          <Row label="اسم النظام" value={SYSTEM_INFO.name} />
          <Row label="الشركة المطوّرة للبرنامج" value={SYSTEM_INFO.developer} />
          <Row label="رقم الإصدار" value={SYSTEM_INFO.version} />
          <Row label="تاريخ الإصدار" value={SYSTEM_INFO.releaseDate} />
        </div>
      </Card>

      <div className="space-y-4">
        <Card>
          <CardHeader title="حول النظام" subtitle="معلومات البرنامج والمطوّر" icon={Info} />
          <div className="space-y-3 p-5 text-sm leading-7 text-ink-500">
            <p>
              <b className="text-ink-800">{SYSTEM_INFO.name}</b> هو {SYSTEM_INFO.tagline} الشامل:
              إدارة المخزون بالدفعات وتواريخ الصلاحية، نقطة البيع، المشتريات، المبيعات والمرتجعات،
              المصروفات، التقارير والأرباح، ودليل أدوية مرجعي — مع صلاحيات متعددة وسجل نشاط كامل.
            </p>
            <p>
              تم تطوير هذا النظام بواسطة <b className="text-ink-800">{SYSTEM_INFO.developer}</b>،
              وجميع الحقوق الفكرية وحقوق الملكية الخاصة بالبرنامج محفوظة لها.
            </p>
          </div>
        </Card>

        <Card>
          <CardHeader title="حقوق الملكية" icon={Copyright} />
          <div className="p-5">
            <div className="rounded-2xl bg-ink-950 px-5 py-4 text-center">
              <p className="text-sm font-extrabold text-white">{COPYRIGHT_TEXT}</p>
              <p className="mt-1 text-xs font-bold text-ink-400">
                {SYSTEM_INFO.name} · {SYSTEM_INFO.developer} · الإصدار {SYSTEM_INFO.version} — {SYSTEM_INFO.releaseDate}
              </p>
            </div>
            <p className="mt-3 text-center text-[11px] leading-6 text-ink-400">
              لا يجوز نسخ هذا البرنامج أو إعادة توزيعه أو تعديله دون إذن كتابي مسبق من الشركة المطوّرة.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================== سجل النشاط ================== */
function ActivityLog() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get('/settings/activity', { limit: 200 }).then((r) => setRows(r.data)).finally(() => setLoading(false)); }, []);

  const ACTIONS = {
    login: 'تسجيل دخول', create: 'إنشاء', update: 'تعديل', delete: 'حذف', cancel: 'إلغاء',
    return: 'مرتجع', adjust: 'تسوية', payment: 'دفعة', import: 'استيراد', dispose: 'إتلاف',
    change_password: 'تغيير كلمة مرور',
  };

  if (loading) return <Loading />;

  return (
    <Card>
      <CardHeader title="سجل النشاط" subtitle="آخر 200 عملية في النظام" icon={Activity} />
      <Table
        columns={['التاريخ', 'المستخدم', 'العملية', 'الجهة', 'التفاصيل']}
        rows={rows}
        empty={<EmptyState title="لا يوجد نشاط مسجل" icon={Activity} />}
        renderRow={(a) => (
          <tr key={a.id}>
            <td className="text-xs text-ink-500">{fmtDateTime(a.created_at)}</td>
            <td className="font-bold">{a.user_name || '—'}</td>
            <td><Badge tone="brand">{ACTIONS[a.action] || a.action}</Badge></td>
            <td className="text-xs text-ink-400">{a.entity || '—'}{a.entity_id ? `#${a.entity_id}` : ''}</td>
            <td className="max-w-[320px] truncate text-xs text-ink-500">{a.details || '—'}</td>
          </tr>
        )}
      />
    </Card>
  );
}

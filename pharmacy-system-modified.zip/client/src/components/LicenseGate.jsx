/**
 * بوابة تفعيل النظام (قفل الجهاز): تُعرض قبل أي شاشة عند عدم تفعيل النسخة.
 * تعرض «معرّف الجهاز» وتطلب مفتاح التفعيل المطابق له — وبعد النجاح تكمل
 * إلى النظام مباشرة. لا تغيّر أي منطق داخلي؛ مجرد بوابة على المدخل.
 */
import { useEffect, useState } from 'react';
import { Pill, KeyRound, Copy, Check, ShieldAlert, Loader2 } from 'lucide-react';
import api from '../api.js';
import { SYSTEM_INFO, COPYRIGHT_TEXT } from '../lib/system.js';

export default function LicenseGate({ children }) {
  const [state, setState] = useState('loading'); // loading | locked | open
  const [deviceId, setDeviceId] = useState('');
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    api.get('/license/status')
      .then((s) => {
        setDeviceId(s.device_id || '');
        setState(s.licensed ? 'open' : 'locked');
      })
      .catch(() => setState('locked'));
  }, []);

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(deviceId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* النسخ اليدوي متاح بتحديد النص */ }
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await api.post('/license/activate', { key: key.trim() });
      setState('open');
    } catch (err) {
      setError(err.message || 'مفتاح التفعيل غير صحيح');
    } finally {
      setBusy(false);
    }
  };

  if (state === 'open') return children;

  return (
    <div dir="rtl" className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink-950 p-6 text-white">
      <div className="absolute -left-20 -top-20 h-80 w-80 rounded-full bg-brand-600/20 blur-3xl" />
      <div className="absolute -bottom-24 -right-10 h-96 w-96 rounded-full bg-brand-500/10 blur-3xl" />

      <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-white/5 p-8 shadow-pop backdrop-blur">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="rounded-2xl bg-brand-600 p-3 text-white shadow-lg">
            <Pill className="h-8 w-8" />
          </div>
          <h1 className="mt-4 text-2xl font-black">{SYSTEM_INFO.name}</h1>
          <p className="mt-1 text-sm font-bold text-brand-300">{SYSTEM_INFO.tagline}</p>
        </div>

        {state === 'loading' ? (
          <div className="flex items-center justify-center gap-2 py-8 text-sm font-bold text-ink-200">
            <Loader2 className="h-5 w-5 animate-spin" /> جارٍ التحقق من ترخيص الجهاز…
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div className="flex items-start gap-2 rounded-2xl border border-amber-300/20 bg-amber-400/10 p-3 text-[13px] font-bold leading-6 text-amber-200">
              <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" />
              هذه النسخة غير مفعّلة على هذا الجهاز. أرسل «معرّف الجهاز» إلى {SYSTEM_INFO.developer} للحصول على مفتاح التفعيل.
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-extrabold text-ink-300">معرّف هذا الجهاز</label>
              <div className="flex items-center gap-2">
                <div dir="ltr" className="flex-1 select-all rounded-xl border border-white/10 bg-ink-900 px-4 py-3 text-center font-mono text-lg font-bold tracking-[0.2em] text-brand-300">
                  {deviceId || '—'}
                </div>
                <button type="button" onClick={copyId} className="rounded-xl border border-white/10 bg-white/5 p-3 text-ink-100 transition hover:bg-white/10" title="نسخ المعرّف">
                  {copied ? <Check className="h-5 w-5 text-brand-400" /> : <Copy className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-extrabold text-ink-300">مفتاح التفعيل</label>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-400" />
                <input
                  dir="ltr"
                  value={key}
                  onChange={(e) => setKey(e.target.value.toUpperCase())}
                  placeholder="XXXX-XXXX"
                  autoFocus
                  className="w-full rounded-xl border border-white/10 bg-ink-900 py-3 pl-4 pr-11 text-center font-mono text-lg font-bold tracking-[0.25em] text-white outline-none transition placeholder:text-ink-500 focus:border-brand-400"
                />
              </div>
            </div>

            {error && (
              <div className="rounded-xl bg-rose-500/15 px-4 py-3 text-sm font-bold text-rose-200">{error}</div>
            )}

            <button
              type="submit"
              disabled={busy || !key.trim()}
              className="w-full rounded-xl bg-brand-600 py-3 text-base font-black text-white transition hover:bg-brand-500 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {busy ? 'جارٍ التفعيل…' : 'تفعيل النظام'}
            </button>
          </form>
        )}

        <p className="mt-6 text-center text-[11px] font-bold text-ink-400">{COPYRIGHT_TEXT}</p>
      </div>
    </div>
  );
}

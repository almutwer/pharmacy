# تقرير مراجعة وإصلاح نظام إدارة الصيدلية
### Pharmacy System — Review, Fixes & Tests Report

تاريخ التسليم: 2026-10-23 — المراجعة على: `pharmacy-system-modified (8)`

---

## ملخّص للعميل (بالعربية)

راجعتُ النظام بالكامل — المبيعات، المرتجعات، المشتريات، المخزون، المصروفات، التقارير، النسخ الاحتياطي، الصلاحيات، واستيراد Excel — وأصلحتُ كل ما يسبب أرقاماً خاطئة أو فقدان بيانات، ودعمتُ ذلك بمجموعة اختبارات آلية (38 اختباراً) تثبت أن النتائج صحيحة وتبقى صحيحة مع أي تعديل مستقبلي.

**أهم ما كان يسبب أخطاء صامتة وتم إصلاحه:**

1. **فواتير بإجمالي أو ربح سالب:** كان بالإمكان حفظ فاتورة خصمها أكبر من قيمتها (إجمالي/ربح سالب). الآن يرفض النظام ذلك تماماً.
2. **الضريبة:** كانت تؤخذ كما تُرسل من الشاشة. الآن تُحسب رسمياً من إعداد النظام، مع دعم «السعر شامل الضريبة».
3. **المرتجعات والإلغاء:** كان المرتجع يرد مبلغاً أكبر مما دفعه العميل فعلاً عند وجود خصم على الفاتورة. الآن يُحسب الاسترداد بالضبط حسب ما دُفع (مع حصة الضريبة).
4. **التقارير لا تتطابق:** أصبحت لوحة المعلومات وتقرير الأرباح تعطيان نفس الأرقام، والفاتورة الملغاة تساوي صفراً، وأرباح التصنيفات تحترم الخصومات.
5. **الحماية من انقطاع الكهرباء:** ضبطتُ قاعدة البيانات لتكتب كل عملية على القرص فوراً (لا تضيع عند انقطاع الكهرباء)، وأضفتُ **نسخاً احتياطية تلقائية** (عند التشغيل، ودورياً، وعند الإغلاق)، وجعلتُ النسخة السريعة لقاعدة البيانات مكتملة دائماً.
6. **حماية إضافية:** منع إلغاء آخر مدير نظام (حتى لا يُغلق النظام على نفسه)، وضبط حدود فواتير الشراء.

النتيجة: نظام يحسب بأمانة، تقاريره متطابقة، ولا يفقد البيانات عند انقطاع الكهرباء — ومغطّى باختبارات تحميه مستقبلاً.

---

## How to run the tests

```bash
cd server
npm install        # once
npm test           # runs all suites (node:test, isolated temp DB per file)
```

**Result: 51 tests, all passing.** No external test dependencies — uses Node's built‑in test runner and the built‑in `node:sqlite` engine.

### Round 2 — fixes from the browser‑QA pass
A full 19‑case browser test was run against the live UI. It confirmed every money/validation number, and surfaced these issues, now fixed and regression‑tested:
- **Timezone (high):** default date ranges used **UTC** on the client while the server used local time, so "today / this month" lagged a day (the Reports/Sales screens showed 0 and didn't match the dashboard). All date defaults now use the **device's local date** (server + client) — correct in Saudi Arabia, Pakistan, or anywhere the PC clock is set.
- **Report scope mismatch:** the Sales list (completed only) didn't match the P&L (which counted cancelled invoices in gross and again as returns). Dashboard, P&L and the Sales list now use one definition — **completed invoices only, and only returns against them** — so gross, returns and invoice counts agree everywhere.
- **Cash purchases saved as unpaid** (showed as money owed to suppliers): non‑credit purchases now default to **paid in full**, like sales.
- **Editing a user without changing the password failed** with a generic error: an empty password now means "no change".
- **Sales list showed stale profit** on returned/cancelled invoices: each invoice now shows **net profit** (a cancelled invoice shows 0).
- **Login page advertised demo accounts** that don't exist and could land a returning user on a forbidden page: removed; login/logout now return to Home.

| Suite | Covers |
|---|---|
| `test/sales.test.js` | sale totals, item/invoice discounts, tax from settings, retail sub‑units, FEFO, insufficient‑stock, negative‑total rejection |
| `test/returns.test.js` | partial/full returns, over‑return rejection, proportional refund with invoice discount, cancellation = invoice total |
| `test/reports.test.js` | dashboard ↔ P&L reconciliation, cancelled = 0, partial return reduces net, tax netting, discount‑aware category |
| `test/safety.test.js` | transaction atomicity (power‑cut equivalent), backup → wipe → restore round‑trip, atomic backup files |
| `test/features.test.js` | Excel/CSV import by name, roles/permissions enforcement, purchase batch costing, expenses, inventory adjustments |
| `test/hardening.test.js` | last‑admin protection, purchase guards, tax‑inclusive pricing |
| `test/reconcile.test.js` | category profit sums to gross profit, items sum to subtotal, multi‑batch FEFO costing, retail‑unit return, free line, trend ↔ KPI, allow‑negative mode |

---

## Findings & fixes (technical)

### A. Money correctness (sales) — `server/src/routes/sales.js`

| # | Problem (before) | Fix (after) |
|---|---|---|
| A1 | Invoice discount had no upper bound → an invoice could be saved with a **negative total and negative profit**; the POS screen clamped the display to 0 while the DB stored the negative value. | Reject any invoice discount greater than the items subtotal (400 error). |
| A2 | A single line's discount could exceed the line value → **negative line**. | Reject item discount greater than the line's gross value. |
| A3 | `tax` was taken from the request body (client‑supplied, spoofable, could diverge from the displayed amount). | Tax is computed **authoritatively** from the `tax_rate` setting on the discounted base; supports `tax_included` (extracts tax from the price). Profit excludes tax. |

### B. Returns & cancellation — `server/src/routes/sales.js`, `schema.js`

| # | Problem (before) | Fix (after) |
|---|---|---|
| B1 | Refunds used the gross line price, **ignoring any invoice‑level discount and tax** → the customer was refunded *more than they paid*. | Refund = the amount actually paid: line share × invoice factor (`total/subtotal`), with the tax share tracked in a new `sale_returns.tax_total` column. |
| B2 | A full cancellation recorded a return equal to the pre‑discount subtotal, not the invoice total → reports didn't net to zero. | Cancellation refund now equals the invoice total exactly (tested). |

### C. Report reconciliation — `server/src/routes/reports.js`

| # | Problem (before) | Fix (after) |
|---|---|---|
| C1 | Dashboard KPIs and the P&L used slightly different rules; figures didn't always tie out. | Both now use one net definition: `Σ invoice totals − Σ returns`. Dashboard ↔ P&L ↔ raw DB all match (tested). |
| C2 | Returned tax wasn't netted → gross profit was wrong when tax was enabled. | Tax share of returns (`tax_total`) is netted in both dashboard and P&L. |
| C3 | Category and top‑product revenue/profit used the gross price, **ignoring discounts**, so they overstated and didn't match booked profit. | Now based on the stored line total, net of returns, after invoice discount, ex‑tax. |
| C4 | Cancelled invoices were counted in the P&L invoice count. | Invoice count excludes cancelled. |
| C5 | The dashboard 14‑day trend showed gross completed sales (ignored returns) → didn't match the net KPI above it. | Trend now uses the same net definition (sales − returns); chart matches the headline numbers. |
| C6 | `today()` returned the **UTC** date while the rest of the app used local time → a late‑night sale could be recorded on the wrong business day, skewing daily reports. | `today()` now returns the **local** date, consistent everywhere. |

### D. Power‑cut safety & backups — `db.js`, `backup.js`, `auto-backup.js`, `electron/main.cjs`

| # | Problem (before) | Fix (after) |
|---|---|---|
| D1 | Durability relied on defaults; `synchronous`/`busy_timeout` not set explicitly. | `PRAGMA synchronous = FULL` (every committed sale is on disk before it's reported done), `busy_timeout`, `wal_autocheckpoint`. |
| D2 | Backup JSON was written in place → a power cut mid‑write could leave a truncated backup. | Atomic write: temp file + rename. |
| D3 | The Electron "quick DB backup" copied only `pharmacy.db`, so recent sales still in the WAL file could be **missing** from the copy. | Checkpoint the WAL first, and also copy `-wal`/`-shm`, so the copy is always complete. |
| D4 | No automatic backups existed. | Automatic backups on **startup**, **every N hours** (setting `auto_backup_interval_hours`, default 12), and on **graceful shutdown**; keeps the last 20. |

### E. Hardening — `users.js`, `purchases.js`, `db.js`, `POS.jsx`

| # | Problem (before) | Fix (after) |
|---|---|---|
| E1 | The last admin could be demoted/deactivated/deleted → total lockout from admin functions. | Blocked: cannot remove the last active admin. |
| E2 | Purchases had the same negative‑total gap, and `paid` could exceed the total. | Same discount guards as sales; `paid` capped at the invoice total. |
| E3 | `tax_included` setting existed but did nothing. | Implemented end‑to‑end (server + POS display). |
| E4 | Write transactions used `BEGIN` (deferred) → on a shared/LAN database two devices could race. | `BEGIN IMMEDIATE` + `busy_timeout` → writers wait their turn instead of racing or failing. |

---

## Features verified working (by test)

- **Excel/CSV import** — new items created with opening balance; re‑import **matches by name** and updates in place (no duplicates).
- **Roles & permissions** — cashier blocked from users/reports; sales amounts shown but profit hidden for cashier; both hidden for assistant.
- **Purchases** — batch effective cost correctly includes bonus quantity and discount; stock increased; prices updated.
- **Inventory adjustments** — damage/out reduces stock and is recorded as a loss.
- **Expenses** — add and totals.
- **Backup / restore** — full round‑trip restores data exactly.

---

## Notes & scope

- **Security** was intentionally out of scope per the client's instruction (the system runs locally on the pharmacy's own devices). The only lockout‑risk item that affects local use — last‑admin protection — was still fixed.
- No database migration is needed for existing installs: the new `sale_returns.tax_total` column and settings are added automatically on first run.
- All changes are server/desktop‑side and backward‑compatible with existing data.

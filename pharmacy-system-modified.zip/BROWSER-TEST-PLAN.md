# Browser Test Plan — Pharmacy System (نظام إدارة الصيدلية)

**Target:** http://localhost:4000  (same app the desktop `.exe` runs)
**Login:** username `admin` · password `admin123`
**UI language:** Arabic, right‑to‑left. Element labels below are given in Arabic exactly as they appear on screen.

## Instructions for the agent
- Execute each test case (TC) in order. Record for each: **PASS / FAIL**, the **actual on‑screen value**, and a **screenshot**.
- Where a test expects a specific number, compare to the **Expected** value exactly (currency shows 2 decimals; ignore the currency symbol).
- If a step can't be performed (element not found), mark **BLOCKED** and describe what you saw.
- Do **not** stop on the first failure — continue and report everything.
- A red popup (toast) in the top corner = an error/validation message. A green toast = success.
- Create the test data in TC‑02 first; later tests depend on it.
- Run the **destructive** suite (TC‑18) **last**.

Report back using the template at the bottom.

---

## TC‑01 — Login & navigation smoke
1. Open http://localhost:4000. 
2. Enter `admin` / `admin123`, submit (button **«تسجيل الدخول»**).
3. Confirm the dashboard (**«لوحة المعلومات»**) loads with KPI cards and a 14‑day chart.
4. Click each sidebar item once: **لوحة المعلومات، نقطة البيع، فواتير المبيعات، المشتريات، المخزون، دليل الأدوية، المصروفات، التقارير والأرباح، الموردون، العملاء، الإعدادات**.
- **Expected:** every page loads with no blank screen and no error popup. Record any page that errors.

## TC‑02 — Create a known test product (data setup)
1. Go to **المخزون** (Inventory) → click **«إضافة صنف جديد للمخزون»** (or **«صنف جديد»**).
2. Fill: name **`اختبار-A`**, سعر الشراء (purchase) = **10**, سعر البيع (sale) = **20**, حد إعادة الطلب (reorder) = **15**, رصيد افتتاحي (opening qty) = **50**. Save (**«حفظ»**).
- **Expected:** product appears in the inventory list with stock **50 علبة** and sale price **20**.

## TC‑03 — POS basic sale math
1. Go to **نقطة البيع** (POS).
2. In the search box, type `اختبار-A`; click the result's add button (shows `علبة · 20`).
3. In the cart, set quantity to **3** (use the `+` button or type 3).
4. Observe the line total and the right‑side summary.
- **Expected:** line total **60.00**; **«الإجمالي قبل الخصم» = 60.00**; **«الإجمالي المستحق» = 60.00** (tax rate is 0).
5. Click **«تأكيد البيع وطباعة الفاتورة»**. A success modal **«تمت عملية البيع بنجاح»** appears with a receipt.
- **Expected:** receipt shows total **60.00**. Close the modal.
6. Go back to **المخزون** → open `اختبار-A`.
- **Expected:** remaining stock = **47 علبة**.

## TC‑04 — Invoice discount (valid)
1. POS → add `اختبار-A`, qty **2** (line 40).
2. In **«خصم على الفاتورة»** enter **10**.
- **Expected:** **«الإجمالي المستحق» = 30.00**.
3. Confirm the sale. Receipt total **30.00**.

## TC‑05 — ❗ Negative‑total rejection (key fix)
1. POS → add `اختبار-A`, qty **2** (line 40).
2. In **«خصم على الفاتورة»** enter **999**.
3. Click **«تأكيد البيع وطباعة الفاتورة»**.
- **Expected:** a **red error** appears, text similar to **«خصم الفاتورة (999) أكبر من إجمالي الأصناف (40)»**, and **NO** sale is created (no success modal). 
4. Go to **فواتير المبيعات** and confirm there is **no** new invoice with a negative/zero total from this attempt.

## TC‑06 — ❗ Line discount larger than the line (key fix)
1. POS → add `اختبار-A`, qty **1** (line 20).
2. In the cart line's discount field enter **50**.
3. Confirm.
- **Expected:** red error like **«خصم البند للصنف اختبار-A (50) أكبر من قيمته (20)»**; no sale created.

## TC‑07 — Free line allowed (discount = exact line value)
1. POS → add `اختبار-A`, qty **1** (line 20), line discount **20**.
- **Expected:** line total **0.00**, **«الإجمالي المستحق» = 0.00**; the sale **can** be confirmed (this is a legitimate free item). Confirm and verify success.

## TC‑08 — Retail (sub‑unit) selling
1. Inventory → create a retail product: name **`اختبار-شريط`**, purchase **10**, sale **20**, **عدد الوحدات بالعبوة = 10**, **الوحدة الصغرى = قرص**, enable **بيع بالتجزئة** (yes), opening qty **10**. Save.
2. POS → search `اختبار-شريط`. You should see **two** add buttons: `علبة · 20` and `قرص · 2`.
3. Click the **قرص** button; set quantity **5**.
- **Expected:** line total **10.00** (5 tablets × 2). Confirm the sale.
4. Inventory → open `اختبار-شريط`.
- **Expected:** remaining stock shows **9 علبة و5 قرص** (i.e. 9.5 boxes).

## TC‑09 — Tax (exclusive) from settings
1. Go to **الإعدادات** → find the tax rate field (**«نسبة الضريبة»** / `tax_rate`), set to **15**, save.
2. POS → add `اختبار-A`, qty **1** (line 20), no discount.
- **Expected:** summary shows a **«الضريبة (15%)»** line = **3.00**, **«الإجمالي المستحق» = 23.00**. Confirm; receipt total **23.00**.
3. **Reset:** set tax rate back to **0** and save.

## TC‑10 — Tax inclusive (optional)
1. Settings → set tax rate **15** AND enable **«السعر شامل الضريبة»** (`tax_included`), save.
2. POS → add `اختبار-A`, qty 1 (price 20).
- **Expected:** **«الإجمالي المستحق» = 20.00** (unchanged — tax is inside), and the tax line shows ≈ **2.61** (= 20 − 20/1.15). 
3. **Reset:** disable tax‑inclusive and set tax rate back to **0**.

## TC‑11 — Partial return with proportional refund (key fix)
1. POS → sell `اختبار-A`: qty **2** at price **50** (change the unit price in the cart line to 50), **«خصم على الفاتورة» = 20**.
- **Expected before confirm:** total **80.00**. Confirm the sale.
2. Go to **فواتير المبيعات**, open that invoice, click **«مرتجع»** / **«إرجاع»**.
3. Return **1** unit of the item; confirm (**«تأكيد المرتجع»**).
- **Expected:** the refund amount shown = **40.00** (half of the 80 actually paid — **not** 50). Record the exact figure.

## TC‑12 — Full cancellation
1. **فواتير المبيعات** → open any completed invoice → **«إلغاء الفاتورة»**, confirm.
- **Expected:** invoice status becomes **ملغاة/cancelled**; the sold quantity is returned to stock (check the product's stock increased accordingly).

## TC‑13 — Reports reconciliation (key fix)
1. Open **التقارير والأرباح** (P&L). Note **«صافي المبيعات» (net sales)** and **«إجمالي الربح» (gross profit)** for *today / this month*.
2. Open **لوحة المعلومات** (Dashboard). Note the month **sales** KPI and the net‑profit figures.
- **Expected:** the Dashboard month **sales** equals the P&L **net sales** (same number). The 14‑day chart's visible total should be consistent with these (cancelled invoices contribute 0).
3. In the P&L, check the **«الأرباح حسب التصنيف»** (profit by category) table.
- **Expected:** the category profit figures reflect discounts (not gross price). Their sum should equal the gross profit shown in the summary **within ~0.01** (one‑cent rounding is acceptable).

## TC‑14 — Excel / CSV import by name (client‑requested feature)
1. Create a plain‑text file `import-test.csv` with UTF‑8 content:
   ```
   اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,بيع بالتجزئة
   دواء-استيراد,8,12,30,12,نعم
   ```
2. Inventory → use the **استيراد** (import) button, upload the CSV.
- **Expected:** result says **1 created** (1 جديد); `دواء-استيراد` appears with stock **30** and sale price **12**.
3. Re‑upload the same file but change the sale price to `15` on the data row.
- **Expected:** result says **1 updated** (1 محدّث), **0 created**, and there is still only **one** `دواء-استيراد` (no duplicate) with price now **15**.

## TC‑15 — Purchases
1. Go to **المشتريات** → new purchase. Add item `اختبار-A`, qty **10**, bonus (كمية مجانية) **2**, unit cost **10**, discount **20**. Save.
- **Expected:** invoice total **80.00**; `اختبار-A` stock increases by **12** (10 + 2 bonus). Open the product to confirm stock went up by 12.

## TC‑16 — Roles & permissions (client‑requested)
1. Settings → Users → **«إضافة مستخدم»**: username `cashier1`, password `pass1234`, role **كاشير (cashier)**. Save.
2. Log out (**«تسجيل الخروج»**), log in as `cashier1` / `pass1234`.
- **Expected sidebar:** shows Dashboard, نقطة البيع, فواتير المبيعات, المخزون, دليل الأدوية, العملاء — but **NOT** التقارير والأرباح, المشتريات, المصروفات, الموردون, الإعدادات.
3. Open **فواتير المبيعات** as cashier.
- **Expected:** invoice **amounts/totals are visible**, but **profit/cost columns are hidden** (shown as «—» or absent).
4. Try to open reports by URL `http://localhost:4000/reports`.
- **Expected:** a **«لا تملك صلاحية الوصول لهذه الصفحة»** message (no data).
5. Log back in as `admin`.

## TC‑17 — Last‑admin protection (key fix)
1. As admin, Settings → Users → edit the **admin** user and try to change its role to **كاشير**, save.
- **Expected:** **red error** preventing it, text like **«لا يمكن إزالة آخر مدير نظام نشط…»**, and admin stays admin.

## TC‑18 — Backup / Restore / Wipe (DESTRUCTIVE — run last)
1. Settings → Maintenance (**الصيانة**): click **«حفظ نسخة على الجهاز»** (create a local backup).
- **Expected:** success; a backup entry appears in the list.
2. Click **«مسح البيانات»** → scope **«الحركات فقط»** (transactions only) → type **مسح** in the confirm box → enter password `admin123` → confirm.
- **Expected:** success; sales/returns/purchases are cleared, inventory items remain. (A safety backup is auto‑created.)
3. Click **«استعادة»** → upload the backup from step 1 → enter password `admin123` → confirm.
- **Expected:** success; the previously cleared sales/returns reappear (data restored).

## TC‑19 — Alerts
1. Inventory / Dashboard: confirm low‑stock and expiry alert counters render. (Create a product with opening qty **1** and reorder level **15** → it should appear under **منخفض/low stock**. Create a batch with a past expiry via a purchase if possible → appears under **منتهي/expiring**.)
- **Expected:** counters/lists populate without error.

---

## How to report back
Return a table plus notes:

| TC | Title | Result (PASS/FAIL/BLOCKED) | Expected | Actual (on screen) | Screenshot | Notes |
|----|-------|---------------------------|----------|--------------------|-----------|-------|
| 01 | Login & nav | | all pages load | | | |
| … | | | | | | |

Then add:
- **Summary:** X passed / Y failed / Z blocked.
- **Any red error popups** seen (copy the exact Arabic text).
- **Any wrong number** (state the invoice/screen, expected vs actual).
- **Any screen that failed to load or looked broken** (with screenshot).
- Browser console errors, if the agent can read them (F12 → Console).

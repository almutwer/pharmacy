/**
 * اختبارات إصلاحين لاحقين (ملف إضافي — لا يعدّل اختبارات المراجعة الأصلية):
 * 1) تفعيل البيع بالتجزئة تلقائياً عند وجود وحدة بيع صغرى في ملف الاستيراد.
 * 2) ثبات ترخيص الجهاز: المفتاح المحسوب لأي بصمة مرشحة لنفس الجهاز يبقى صالحاً.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { boot } from './helpers/api.js';

// مجلد مستخدم وهمي + تمكين النسخ الاحتياطية للترخيص داخل هذه الاختبارات فقط،
// حتى لا تتأثر أي اختبارات أخرى (ولا تُكتب أي ملفات في مجلد المستخدم الحقيقي).
const FAKE_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'shifaa-test-home-'));
process.env.HOME = FAKE_HOME;
process.env.SHIFAA_LICENSE_STORES = 'all';

let ctx;
let LIC;
before(async () => {
  ctx = await boot();         // يضبط DATA_DIR المؤقت قبل تحميل وحدة الترخيص
  await ctx.login();
  LIC = await import('../src/lib/license.js');
});
after(async () => {
  await ctx.close();
  try { fs.rmSync(FAKE_HOME, { recursive: true, force: true }); } catch { /* ignore */ }
});

const toB64 = (text) => Buffer.from(text, 'utf8').toString('base64');
async function importCsv(csv) {
  const res = await ctx.request('POST', '/api/products/import-file', {
    body: { file: toB64(csv), filename: 'd.csv', mode: 'upsert' },
  });
  assert.equal(res.status, 200, JSON.stringify(res.data));
  return res.data;
}

test('استيراد: وجود «الوحدة الصغرى» يفعّل البيع بالتجزئة تلقائياً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,الوحدة الصغرى\nدواء تجزئة أ,8,12,20,10,شريط');
  const p = db.get("SELECT allow_sub_unit, sub_unit FROM products WHERE name = 'دواء تجزئة أ'");
  assert.equal(p.sub_unit, 'شريط');
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: وجود «سعر الوحدة الصغرى» وحده يفعّل البيع بالتجزئة أيضاً', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي,عدد الوحدات بالعبوة,سعر الوحدة الصغرى\nدواء تجزئة ب,8,12,20,10,1.5');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء تجزئة ب'");
  assert.equal(p.allow_sub_unit, 1);
});

test('استيراد: غياب الوحدة الصغرى يُبقي البيع بالتجزئة كما هو (غير مفعّل)', async () => {
  const { db } = ctx;
  await importCsv('اسم الصنف,سعر الشراء,سعر البيع,رصيد افتتاحي\nدواء عادي,8,12,20');
  const p = db.get("SELECT allow_sub_unit FROM products WHERE name = 'دواء عادي'");
  assert.equal(p.allow_sub_unit, 0);
});

const licensePaths = () => [
  path.join(ctx.dir, 'license.json'),
  path.join(FAKE_HOME, '.shifaa', 'license.json'),
];
const resetLicenseFiles = () => {
  for (const f of licensePaths()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
  LIC.clearLicenseCache();
};

test('الترخيص: مفتاح جهاز آخر مرفوض', async () => {
  resetLicenseFiles();
  assert.equal(LIC.activate(LIC.expectedKey('ZZZZ-ZZZZ-ZZZZ')), false);
  assert.equal(LIC.isLicensed(), false);
});

test('الترخيص: التفعيل ينجح ويُحفظ في أكثر من موضع مستقل', async () => {
  const ids = LIC.candidateDeviceIds();
  assert.ok(ids.length >= 1);
  assert.equal(LIC.getDeviceId(), ids[0]);
  assert.equal(LIC.activate(LIC.expectedKey(ids[0])), true);
  assert.equal(LIC.isLicensed(), true);
  for (const f of licensePaths()) assert.ok(fs.existsSync(f), `لم يُحفظ الترخيص في ${f}`);
  const rec = JSON.parse(fs.readFileSync(licensePaths()[0], 'utf8'));
  assert.equal(rec.version, 2, 'يجب أن يُحفظ سجل موقّع من الإصدار الثاني');
  assert.ok(rec.sig && rec.env && rec.env.host);
});

test('الترخيص: حذف ملف مجلد البيانات لا يقفل النظام (بقاء نسخة احتياطية)', async () => {
  const ids = LIC.candidateDeviceIds();
  LIC.activate(LIC.expectedKey(ids[0]));
  fs.rmSync(licensePaths()[0], { force: true });
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), true, 'قُفل النظام رغم وجود نسخة ترخيص أخرى سليمة');
  // ويُعاد إنشاء النسخة المفقودة تلقائياً
  assert.ok(fs.existsSync(licensePaths()[0]), 'لم تُستعد نسخة مجلد البيانات');
});

test('الترخيص: سجل قديم (بدون توقيع) يُقبل ويُرقّى تلقائياً إلى الإصدار الثاني', async () => {
  resetLicenseFiles();
  const ids = LIC.candidateDeviceIds();
  fs.writeFileSync(licensePaths()[0], JSON.stringify({
    key: LIC.expectedKey(ids[0]), device_id: ids[0], activated_at: new Date().toISOString(),
  }));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), true);
  const rec = JSON.parse(fs.readFileSync(licensePaths()[0], 'utf8'));
  assert.equal(rec.version, 2);
});

test('الترخيص: ملف ترخيص معدّل يدوياً غير مقبول', async () => {
  resetLicenseFiles();
  fs.writeFileSync(licensePaths()[0], JSON.stringify({
    key: LIC.expectedKey('ZZZZ-ZZZZ-ZZZZ'), device_id: 'ZZZZ-ZZZZ-ZZZZ',
  }));
  LIC.clearLicenseCache();
  assert.equal(LIC.isLicensed(), false);
});

test('الترخيص: مطابقة البيئة تميّز نفس الجهاز عن جهاز غريب', async () => {
  const env = LIC.currentEnvironment();
  assert.ok(LIC.environmentMatchScore(env) >= 3, 'بصمة الجهاز الحالي يجب أن تطابق نفسها');
  const alien = { host: 'OTHER-PC', cpu: 'Alien CPU', platform: 'plan9', arch: 'mips', machine: 'x:y', macs: ['00:11:22:33:44:55'], user: 'nobodyelse' };
  assert.equal(LIC.environmentMatchScore(alien), 0);
});

test('الترخيص: مفتاح أي بصمة مرشحة لنفس الجهاز صالح (ثبات عند تبدّل كرت الشبكة)', async () => {
  resetLicenseFiles();
  const ids = LIC.candidateDeviceIds();
  assert.equal(LIC.activate(LIC.expectedKey(ids[ids.length - 1])), true);
  assert.equal(LIC.isLicensed(), true);
});
